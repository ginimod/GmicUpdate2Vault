---
tags: [gmic, filter]
command: afre_vigrect
---

# Filtre G'MIC : afre_vigrect

## Structure de la commande
```text
afre_vigrect:
    size = $1
    strength = $2
    blur = $3
    left_right = $4
    up_down = $5
```
## Définition des variables
(Note) : <strong>Add rectangular vignette.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2017-2019.</strong>
<hr /> <strong>Instructions:</strong>

 * Negative strength brightens the periphery.


* **`Size` ($1)** (int) : défaut = **50**  (1,100)
* **`Strength` ($2)** (int) : défaut = **75**  (-500,500)
* **`Blur` ($3)** (int) : défaut = **10**  (1,50)
* **`Left-Right` ($4)** (int) : défaut = **50**  (0,100)
* **`Up-Down` ($5)** (int) : défaut = **50**  (0,100)
