---
tags: [gmic, filter]
command: fx_quick_copyright
---

# Filtre G'MIC : fx_quick_copyright

## Structure de la commande
```text
fx_quick_copyright:
    font = $2
    size = $3
    bold_face = $4
    opacity = $8
    outline = $9
    position = $13
    x_offset = $14
    y_offset = $15
    orientation_deg = $16
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds a quick copyright text overlay. 
* **`Font` ($1)** (choice) : choix possibles => Acme, Arial, Arial Black, Black Ops One, Black Chancery, Cabin Sketch, Caprasimo, Carnevalee Freakshow, Cheese Burger, Cheque, Cheque Black, Chlorinar, Comic Sans MS, Courier New, Creepster, Georgia, Hidayatullah, Impact, Jaro, Lobster, Luckiest Guy, Macondo, Medieval Sharp, Odin Rounded, Oswald, Palatino Linotype, Playfair Display, Roboto, Satisfy, Sofia, Sunday Milk, Tex Gyre Adventor, Times New Roman, Titan One, Typewriter, Verdana
* **`Size (%)` ($2)** (float) : défaut = **10**  (0,50)
* **`Bold Face` ($3)** (bool) : par défaut = Faux (0)
* **`Color` ($4)** (color) : défaut = 255,255,255
* **`Opacity (%)` ($5)** (float) : défaut = **90**  (0,100)
* **`Outline (%)` ($6)** (float) : défaut = **3**  (0,20)
* **`Outline Color` ($7)** (color) : défaut = 0,0,0
* **`Position` ($8)** (choice) : choix possibles => Up-Left, Up-Right, Center, Bottom-Left, Bottom-Right, Corners, Everywhere
* **`X-Offset (%)` ($9)** (float) : défaut = **1**  (0,50)
* **`Y-Offset (%)` ($10)** (float) : défaut = **1**  (0,50)
* **`Orientation (deg.)` ($11)** (float) : défaut = **-180**  (0,180)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2024/02/21.
