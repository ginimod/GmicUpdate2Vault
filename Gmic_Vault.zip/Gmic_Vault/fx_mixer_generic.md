---
tags: [gmic, filter]
command: fx_mixer_generic
---

# Filtre G'MIC : fx_mixer_generic

## Structure de la commande
```text
fx_mixer_generic:
    color_space = $1
    multiplier = $2
    offset = $3
    gamma = $4
    smoothness = $5
    multiplier = $6
    offset = $7
    gamma = $8
    smoothness = $9
    multiplier = $10
    offset = $11
    gamma = $12
    smoothness = $13
    multiplier = $14
    offset = $15
    gamma = $16
    smoothness = $17
    preview_type = $18
    preview_split_x = $19
    preview_split_y = $20
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> A generic matrix mixer for color channels. 
* **`Color Space` ($1)** (choice) : choix possibles => CMY, CMYK, HCY, HSI, HSL, HSV, Jzazbz, Lab, Lch, OKlab, RGB, RYB, XYZ, YCbCr, YIQ, YUV
(Note) : <span color="#EE5500">Channel #0:</span>
* **`Multiplier` ($2)** (float) : défaut = **1**  (0,5)
* **`Offset (%)` ($3)** (float) : défaut = **0**  (-100,100)
* **`Gamma` ($4)** (float) : défaut = **0**  (-3,3)
* **`Smoothness` ($5)** (float) : défaut = **0**  (0,10)
(Note) : <span color="#EE5500">Channel #1:</span>
* **`Multiplier` ($6)** (float) : défaut = **1**  (0,5)
* **`Offset (%)` ($7)** (float) : défaut = **0**  (-100,100)
* **`Gamma` ($8)** (float) : défaut = **0**  (-3,3)
* **`Smoothness` ($9)** (float) : défaut = **0**  (0,10)
(Note) : <span color="#EE5500">Channel #2:</span>
* **`Multiplier` ($10)** (float) : défaut = **1**  (0,5)
* **`Offset (%)` ($11)** (float) : défaut = **0**  (-100,100)
* **`Gamma` ($12)** (float) : défaut = **0**  (-3,3)
* **`Smoothness` ($13)** (float) : défaut = **0**  (0,10)
(Note) : <span color="#EE5500">Channel #3:</span>
* **`Multiplier` ($14)** (float) : défaut = **1**  (0,5)
* **`Offset (%)` ($15)** (float) : défaut = **0**  (-100,100)
* **`Gamma` ($16)** (float) : défaut = **0**  (-3,3)
* **`Smoothness` ($17)** (float) : défaut = **0**  (0,10)
* **`Preview Type` ($18)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($19)** (point) : position = 0,0
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2023/04/29.
