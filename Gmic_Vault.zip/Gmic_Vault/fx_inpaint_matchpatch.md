---
tags: [gmic, filter]
command: fx_inpaint_matchpatch
---

# Filtre G'MIC : fx_inpaint_matchpatch

## Structure de la commande
```text
fx_inpaint_matchpatch:
    number_of_scales = $1
    patch_size = $2
    number_of_iterations_per_scale = $3
    blend_size = $4
    allow_outer_blending = $5
    mask_dilation = $10
    preview_progression_while_running = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Inpaints mask content using a patch-based multi-scale algorithm. 
* **`Number of Scales` ($1)** (int) : défaut = **0**  (0,16)
(Note) : (Set Number of scales to 0 for automatic scale detection)
* **`Patch Size` ($2)** (int) : défaut = **9**  (1,64)
* **`Number of Iterations per Scale` ($3)** (int) : défaut = **10**  (1,100)
* **`Blend Size` ($4)** (int) : défaut = **5**  (0,32)
* **`Allow Outer Blending` ($5)** (bool) : par défaut = Faux (0)
* **`Mask Color` ($6)** (color) : défaut = 255,0,0,255
* **`Mask Dilation` ($7)** (int) : défaut = **0**  (0,32)
* **`Preview Progression While Running` ($8)** (bool) : par défaut = Faux (0)
(Note) : Note: Preview and final result may strongly differ.
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/11/25.
