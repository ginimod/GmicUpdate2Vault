---
tags: [gmic, filter]
command: fx_mesh3d
---

# Filtre G'MIC : fx_mesh3d

## Structure de la commande
```text
fx_mesh3d:
    x_axis_x = $3
    x_axis_y = $4
    y_axis_x = $5
    y_axis_y = $6
    scale_x = $7
    scale_y = $8
    center_x = $9
    center_y = $10
    pre_rotate_x = $13
    pre_rotate_y = $14
    pre_rotate_z = $15
    rendering_mode = $16
    face_orientation = $17
    materials = $18
    focal = $22
    anti_aliasing = $23
    custom_light_x = $24
    custom_light_y = $25
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Overlay a rendering of a 3D mesh over the image. 
(Note) : (supported file formats are: .obj, .off and .gmz).
* **`X-Axis` ($1)** (point) : position = 0,0
* **`Y-Axis` ($2)** (point) : position = 0,0
* **`Scale` ($3)** (point) : position = 0,0
* **`Center` ($4)** (point) : position = 0,0
* **`Pre-Rotate / X` ($5)** (choice) : choix possibles => 0 Deg., 45 Deg., 90 Deg., 135 Deg., 180 Deg., 225 Deg., 270 Deg., 315 Deg.
* **`Pre-Rotate / Y` ($6)** (choice) : choix possibles => 0 Deg., 45 Deg., 90 Deg., 135 Deg., 180 Deg., 225 Deg., 270 Deg., 315 Deg.
* **`Pre-Rotate / Z` ($7)** (choice) : choix possibles => 0 Deg., 45 Deg., 90 Deg., 135 Deg., 180 Deg., 225 Deg., 270 Deg., 315 Deg.
* **`Rendering Mode` ($8)** (choice) : choix possibles => Bounding Box, Dots, Wireframe, Flat, Flat Shaded, Gouraud Shaded, Phong Shaded
* **`Face Orientation` ($9)** (choice) : choix possibles => Normal, Reverted, Double-Sided
* **`Materials` ($10)** (choice) : choix possibles => Discard Colors, Discard Textures, Keep Textures
* **`Recovery Color` ($11)** (color) : défaut = 200,200,200
* **`Focal (%)` ($12)** (float) : défaut = **100**  (0,500)
* **`Anti-Aliasing` ($13)** (choice) : choix possibles => None, X1.5, X2, X3, X4
* **`Custom Light` ($14)** (point) : position = 0,0
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>       Latest Update: 2022/06/21.
