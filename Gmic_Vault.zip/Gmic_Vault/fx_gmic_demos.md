---
tags: [gmic, filter]
command: fx_gmic_demos
---

# Filtre G'MIC : fx_gmic_demos

## Structure de la commande
```text
fx_gmic_demos:
    selection = $1
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Launches interactive G'MIC demos and mini-games. 
* **`Selection` ($1)** (choice) : choix possibles => Blobs Editor, Bouncing Balls, Connect-Four, Fire Effect, Fireworks, Fish-Eye Effect, Fourier Filtering, Hanoi Tower, Histogram, Hough Transform, Jawbreaker, Virtual Landscape, The Game of Life, Light Effect, Mandelbrot Explorer, 3D Metaballs, Minesweeper, Minimal Path, Pacman, Paint, Plasma Effect, RGB Quantization, 3D Reflection, 3D Rubber Object, Shadebobs, Spline Editor, 3D Starfield, Tetris, Tic-Tac-Toe, 3D Waves, Fractal Whirl
(Note) : Note: This filter proposes a showcase of some interactive demos, all written as G'MIC scripts.
(Note) : On most demos, you can use the keyboard shortcut CTRL+D to double the window size (and CTRL+C to go back to the original size). Also, feel free to use the mouse buttons, as they are often used to perform an action. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2014/09/10.
