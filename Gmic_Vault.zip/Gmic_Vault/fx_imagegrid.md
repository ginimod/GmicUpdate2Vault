---
tags: [gmic, filter]
command: fx_imagegrid
---

# Filtre G'MIC : fx_imagegrid

## Structure de la commande
```text
fx_imagegrid:
    x_size = $1
    y_size = $2
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Converts the image into a pixelated square grid. 
* **`X-Size` ($1)** (int) : défaut = **10**  (2,512)
* **`Y-Size` ($2)** (int) : défaut = **10**  (2,512)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
