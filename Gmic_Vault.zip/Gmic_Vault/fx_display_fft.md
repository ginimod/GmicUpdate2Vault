---
tags: [gmic, filter]
command: fx_display_fft
---

# Filtre G'MIC : fx_display_fft

## Structure de la commande
```text
fx_display_fft:
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Displays the Fourier magnitude. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
