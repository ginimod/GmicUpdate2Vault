---
tags: [gmic, filter]
command: fx_mix_lab
---

# Filtre G'MIC : fx_mix_lab

## Structure de la commande
```text
fx_mix_lab:
    lightness_factor = $1
    lightness_shift = $2
    lightness_smoothness = $3
    a_color_factor = $4
    a_color_shift = $5
    a_color_smoothness = $6
    b_color_factor = $7
    b_color_shift = $8
    b_color_smoothness = $9
    tones_range = $10
    tones_smoothness = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Mixes channels using the Lab color model. 
* **`Lightness Factor` ($1)** (float) : défaut = **1**  (0.5,1.5)
* **`Lightness Shift` ($2)** (float) : défaut = **0**  (-50,50)
* **`Lightness Smoothness` ($3)** (float) : défaut = **0**  (0,10)
* **`A-Color Factor` ($4)** (float) : défaut = **1**  (0,4)
* **`A-Color Shift` ($5)** (float) : défaut = **0**  (-20,20)
* **`A-Color Smoothness` ($6)** (float) : défaut = **0**  (0,10)
* **`B-Color Factor` ($7)** (float) : défaut = **1**  (0,4)
* **`B-Color Shift` ($8)** (float) : défaut = **0**  (-20,20)
* **`B-Color Smoothness` ($9)** (float) : défaut = **0**  (0,10)
* **`Tones Range` ($10)** (choice) : choix possibles => All Tones, Shadows, Mid-Tones, Highlights
* **`Tones Smoothness` ($11)** (float) : défaut = **2**  (0,10)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/06/20.
