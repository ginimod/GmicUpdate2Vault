---
tags: [gmic, filter]
command: fx_cutout
---

# Filtre G'MIC : fx_cutout

## Structure de la commande
```text
fx_cutout:
    number_of_levels = $1
    edge_simplicity = $2
    edge_fidelity = $3
    normalize = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Reduces the number of colors to create a paper cutout effect. 
* **`Number of Levels` ($1)** (int) : défaut = **4**  (2,32)
* **`Edge Simplicity` ($2)** (float) : défaut = **0.5**  (0,3)
* **`Edge Fidelity` ($3)** (int) : défaut = **4**  (0,10)
* **`Normalize` ($4)** (bool) : par défaut = Faux (0)
(Note) : Authors: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a> and Garagecoder       Latest Update: 2014/06/03.
