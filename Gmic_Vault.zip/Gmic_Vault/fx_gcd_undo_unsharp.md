---
tags: [gmic, filter]
command: fx_gcd_undo_unsharp
---

# Filtre G'MIC : fx_gcd_undo_unsharp

## Structure de la commande
```text
fx_gcd_undo_unsharp:
    radius = $1
    amount = $2
    type = $3
    preview_type = $4
    preview_split_x = $5
    preview_split_y = $6
```
## Définition des variables
(Note) : Reverse the effect of an unsharp mask
* **`Radius` ($1)** (float) : défaut = **3**  (0,30)
* **`Amount` ($2)** (float) : défaut = **0.5**  (0,5)
* **`Type` ($3)** (choice) : choix possibles => Box, Gaussian
* **`Preview Type` ($4)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($5)** (point) : position = 0,0
(Note) : Author : Garagecoder.      Latest update : 2021/12/19.
(Note) : 
<u>Notes</u>
(Note) : Useful for fixing halos due to excessive unsharp mask application.
(Note) : For best results, settings should match the original unsharp filter.
(Note) : This obviously requires estimation if the settings are unknown.
