---
tags: [gmic, filter]
command: fx_jpeg_preview
---

# Filtre G'MIC : fx_jpeg_preview

## Structure de la commande
```text
fx_jpeg_preview:
    1_quality = $1
    2_colour_space = $2
    3_channel_1_block_width = $3
    4_channel_1_block_height = $4
    5_channel_2_block_width = $5
    6_channel_2_block_height = $6
    7_channel_3_block_width = $7
    8_channel_3_block_height = $8
    toggle_block_offsets = $9
    9_channel_1_block_x_offset = $10
    10_channel_1_block_y_offset = $11
    11_channel_2_block_x_offset = $12
    12_channel_2_block_y_offset = $13
    13_channel_3_block_x_offset = $14
    14_channel_3_block_y_offset = $15
```
## Définition des variables
* **`1. Quality` ($1)** (float) : défaut = **80**  (0,100)
* **`2. Colour Space` ($2)** (choice) : choix possibles => RGB, SRGB, CMY, RYB, Ohta8, Ohta, YES8, YES, Kodak 1-8, Kodak1, Lab8, Lab, Oklab, LUV, Jzazbz, YIQ8, YIQ, YUV8, YUV, YCbCr, YCbCrGLIC, YCbCrJPEG, YDbDr, XYZ8, XYZ, HSV8, HSV, HSL8, HSL, HSI8, HSI, LCH8, LCH, JzCzHz, HCY
* **`3. Channel 1 Block Width` ($3)** (int) : défaut = **8**  (2,32)
* **`4. Channel 1 Block Height` ($4)** (int) : défaut = **8**  (2,32)
* **`5. Channel 2 Block Width` ($5)** (int) : défaut = **16**  (2,32)
* **`6. Channel 2 Block Height` ($6)** (int) : défaut = **16**  (2,32)
* **`7. Channel 3 Block Width` ($7)** (int) : défaut = **16**  (2,32)
* **`8. Channel 3 Block Height` ($8)** (int) : défaut = **16**  (2,32)
* **`Toggle Block Offsets` ($9)** (bool) : par défaut = Faux (0)
* **`9. Channel 1 Block X Offset` ($10)** (int) : défaut = **0**  (-32,32)
* **`10. Channel 1 Block Y Offset` ($11)** (int) : défaut = **0**  (-32,32)
* **`11. Channel 2 Block X Offset` ($12)** (int) : défaut = **0**  (-32,32)
* **`12. Channel 2 Block Y Offset` ($13)** (int) : défaut = **0**  (-32,32)
* **`13. Channel 3 Block X Offset` ($14)** (int) : défaut = **0**  (-32,32)
* **`14. Channel 3 Block Y Offset` ($15)** (int) : défaut = **0**  (-32,32)
