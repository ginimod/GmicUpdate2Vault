---
tags: [gmic, filter]
command: fx_dreamy_watercolour
---

# Filtre G'MIC : fx_dreamy_watercolour

## Structure de la commande
```text
fx_dreamy_watercolour:
    1_smoothness = $1
    2_linearity = $2
    3_min_threshold = $3
    4_max_threshold = $4
    5_negative = $5
    6_opacity = $6
    7_amplitude = $7
    8_edge_threshold = $8
    9_smoothness = $9
    10_edge_threshold = $10
    11_smoothness = $11
    12_blend_mode = $12
    13_opacity = $13
    14_noise_amplitude = $14
    15_noise_type = $15
    16_noise_channel_s = $16
    17_blend_mode = $17
    18_opacity = $18
    19_blur_strength = $19
    20_sharpen_radius_factor = $20
    21_amount_factor = $21
    22_threshold = $22
    23_constraint_radius_factor = $23
    24_overshoot_factor = $24
    25_sharpen_channel_s = $25
    26_value_action = $26
    27_antialias = $27
    28_amplitude = $28
    29_interpolation = $29
    30_matrix_density = $30
    31_matrix_interpolation = $31
    32_mode = $32
    33_character = $33
    34_boundary = $34
    35_alpha = $35
    36_beta = $36
    37_scale = $37
    38_randomize = $38
    39_transparency = $39
    43_fix_edges = $43
    44_enable = $44
    45_regularization = $45
    46_preserve_luminance = $46
    47_precision = $47
    48_reference_colors = $48
    49_add_user_defined_constraints_interactive = $49
    50_blend_mode = $50
    51_opacity = $51
    52_reverse_order = $52
    53_amplitude = $53
    54_radius = $54
    55_neighborhood_smoothness = $55
    56_average_smoothness = $56
    57_constrain_values = $57
    58_channel_s = $58
    59_power = $59
    60_noise_type = $60
    61_channel_s = $61
    62_value_action = $62
    63_blend_mode = $63
    64_opacity = $64
```
## Définition des variables
(Note) : Creates abstract watercolour images.
(Note) : Gradient norm
* **`1. Smoothness` ($1)** (float) : défaut = **0**  (0,10)
* **`2. Linearity` ($2)** (float) : défaut = **0.3**  (0,2)
* **`3. Min Threshold` ($3)** (float) : défaut = **40**  (0,100)
* **`4. Max Threshold` ($4)** (float) : défaut = **60**  (0,100)
* **`5. Negative` ($5)** (bool) : par défaut = Faux (0)
* **`6. Opacity` ($6)** (float) : défaut = **1**  (0,1)
(Note) : Antialias
* **`7. Amplitude` ($7)** (float) : défaut = **50**  (0,200)
* **`8. Edge Threshold (%)` ($8)** (float) : défaut = **0**  (0,100)
* **`9. Smoothness` ($9)** (float) : défaut = **10**  (0,20)
(Note) : Dreamy abstraction
(Note) : Segmentation
* **`10. Edge Threshold` ($10)** (float) : défaut = **2**  (0,30)
* **`11. Smoothness` ($11)** (float) : défaut = **1**  (0,10)
* **`12. Blend Mode` ($12)** (choice) : choix possibles => Add, Alpha, And, Average, Blue, Burn, Darken, Difference, Divide, Dodge, Exclusion, Freeze, Grainextract, Grainmerge, Green, Hardlight, Hardmix, Hue, Interpolation, Lighten, Lightness, Linearburn, Linearlight, Luminance, Multiply, Negation, Or, Overlay, Pinlight, Red, Reflect, Saturation, Screen, Shapeaverage, Softburn, Softdodge, Softlight, Stamp, Subtract, Value, Vividlight, Xor
* **`13. Opacity` ($13)** (float) : défaut = **0.5**  (0,1)
(Note) : Noise
* **`14. Noise Amplitude` ($14)** (float) : défaut = **10**  (0,100)
* **`15. Noise Type` ($15)** (choice) : choix possibles => Gaussian, Uniform, Salt and Pepper, Poisson, Rice, Spread
* **`16. Noise Channel(s)` ($16)** (choice) : choix possibles => All, RGBA [all], RGB [all], RGB [red], RGB [green], RGB [blue], RGBA [alpha], Linear RGB [all], Linear RGB [red], Linear RGB [green], Linear RGB [blue], YCbCr [luminance], YCbCr [blue-Red Chrominances], YCbCr [blue Chrominance], YCbCr [red Chrominance], YCbCr [green Chrominance], Lab [lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [hue], HSV [saturation], HSV [value], HSI [intensity], HSL [lightness], CMYK [cyan], CMYK [magenta], CMYK [yellow], CMYK [key], YIQ [luma], YIQ [chromas]
* **`17. Blend Mode` ($17)** (choice) : choix possibles => Add, Alpha, And, Average, Blue, Burn, Darken, Difference, Divide, Dodge, Exclusion, Freeze, Grainextract, Grainmerge, Green, Hardlight, Hardmix, Hue, Interpolation, Lighten, Lightness, Linearburn, Linearlight, Luminance, Multiply, Negation, Or, Overlay, Pinlight, Red, Reflect, Saturation, Screen, Shapeaverage, Softburn, Softdodge, Softlight, Stamp, Subtract, Value, Vividlight, Xor
* **`18. Opacity` ($18)** (float) : défaut = **1**  (0,1)
(Note) : Blur & Constrained Sharpen
* **`19. Blur Strength` ($19)** (float) : défaut = **3**  (0,20)
* **`20. Sharpen Radius Factor` ($20)** (float) : défaut = **1**  (0,5)
* **`21. Amount Factor` ($21)** (float) : défaut = **1**  (0,5)
* **`22. Threshold` ($22)** (float) : défaut = **1**  (0,5)
* **`23. Constraint Radius Factor` ($23)** (float) : défaut = **1**  (0,5)
* **`24. Overshoot Factor` ($24)** (float) : défaut = **1**  (0,20)
* **`25. Sharpen Channel(s)` ($25)** (choice) : choix possibles => All, RGBA [all], RGB [all], RGB [red], RGB [green], RGB [blue], RGBA [alpha], Linear RGB [all], Linear RGB [red], Linear RGB [green], Linear RGB [blue], YCbCr [luminance], YCbCr [blue-Red Chrominances], YCbCr [blue Chrominance], YCbCr [red Chrominance], YCbCr [green Chrominance], Lab [lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [hue], HSV [saturation], HSV [value], HSI [intensity], HSL [lightness], CMYK [cyan], CMYK [magenta], CMYK [yellow], CMYK [key]
* **`26. Value Action` ($26)** (choice) : choix possibles => None, Cut, Normalize
* **`27. Antialias` ($27)** (float) : défaut = **25**  (0,100)
(Note) : Deform colour layer
* **`28. Amplitude` ($28)** (float) : défaut = **5**  (0,50)
* **`29. Interpolation` ($29)** (choice) : choix possibles => None, Linear, Bicubic
* **`30. Matrix Density` ($30)** (float) : défaut = **10**  (1,100)
* **`31. Matrix Interpolation` ($31)** (choice) : choix possibles => Linear, Bicubic
* **`32. Mode` ($32)** (choice) : choix possibles => Noise, Spread Noise
* **`33. Character` ($33)** (float) : défaut = **0**  (-100,100)
* **`34. Boundary` ($34)** (choice) : choix possibles => Dirichlet, Neumann, Periodic, Mirror
(Note) : Plasma
* **`35. Alpha` ($35)** (float) : défaut = **0.5**  (0,5)
* **`36. Beta` ($36)** (float) : défaut = **0**  (0,100)
* **`37. Scale` ($37)** (float) : défaut = **8**  (1,20)
* **`38. Randomize` ($38)** (bool) : par défaut = Faux (0)
* **`39. Transparency` ($39)** (bool) : par défaut = Faux (0)
* **`40-42. Color Balance` ($40)** (color) : défaut = 128,128,128
* **`43. Fix Edges` ($41)** (float) : défaut = **0.5**  (0,1)
(Note) : Transfer colours
* **`44. Enable` ($42)** (bool) : par défaut = Faux (0)
* **`45. Regularization` ($43)** (int) : défaut = **8**  (0,32)
* **`46. Preserve Luminance` ($44)** (float) : défaut = **0.2**  (0,1)
* **`47. Precision` ($45)** (choice) : choix possibles => Low, Normal, High, Very High
* **`48. Reference Colors` ($46)** (choice) : choix possibles => Plasma, Painting
* **`49. Add User-Defined Constraints (Interactive)` ($47)** (bool) : par défaut = Faux (0)
* **`50. Blend Mode` ($48)** (choice) : choix possibles => Add, Alpha, And, Average, Blue, Burn, Darken, Difference, Divide, Dodge, Exclusion, Freeze, Grainextract, Grainmerge, Green, Hardlight, Hardmix, Hue, Interpolation, Lighten, Lightness, Linearburn, Linearlight, Luminance, Multiply, Negation, Or, Overlay, Pinlight, Red, Reflect, Saturation, Screen, Shapeaverage, Softburn, Softdodge, Softlight, Stamp, Subtract, Value, Vividlight, Xor
* **`51. Opacity` ($49)** (float) : défaut = **0.75**  (0,1)
* **`52. Reverse Order` ($50)** (bool) : par défaut = Faux (0)
(Note) : Local normalisation
* **`53. Amplitude` ($51)** (float) : défaut = **1**  (0,80)
* **`54. Radius` ($52)** (int) : défaut = **20**  (1,96)
* **`55. Neighborhood Smoothness` ($53)** (float) : défaut = **40**  (0,60)
* **`56. Average Smoothness` ($54)** (float) : défaut = **40**  (0,60)
* **`57. Constrain Values` ($55)** (bool) : par défaut = Faux (0)
* **`58. Channel(s)` ($56)** (choice) : choix possibles => All, RGBA [all], RGB [all], RGB [red], RGB [green], RGB [blue], RGBA [alpha], Linear RGB [all], Linear RGB [red], Linear RGB [green], Linear RGB [blue], YCbCr [luminance], YCbCr [blue-Red Chrominances], YCbCr [blue Chrominance], YCbCr [red Chrominance], YCbCr [green Chrominance], Lab [lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [hue], HSV [saturation], HSV [value], HSI [intensity], HSL [lightness], CMYK [cyan], CMYK [magenta], CMYK [yellow], CMYK [key], YIQ [luma], YIQ [chromas]
(Note) : Noise
* **`59. Power` ($57)** (float) : défaut = **1.25**  (0,5)
* **`60. Noise Type` ($58)** (choice) : choix possibles => Gaussian, Uniform, Salt and Pepper, Poisson, Rice
* **`61. Channel(s)` ($59)** (choice) : choix possibles => All, RGBA [all], RGB [all], RGB [red], RGB [green], RGB [blue], RGBA [alpha], Linear RGB [all], Linear RGB [red], Linear RGB [green], Linear RGB [blue], YCbCr [luminance], YCbCr [blue-Red Chrominances], YCbCr [blue Chrominance], YCbCr [red Chrominance], YCbCr [green Chrominance], Lab [lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [hue], HSV [saturation], HSV [value], HSI [intensity], HSL [lightness], CMYK [cyan], CMYK [magenta], CMYK [yellow], CMYK [key], YIQ [luma], YIQ [chromas]
* **`62. Value Action` ($60)** (choice) : choix possibles => None, Cut, Normalize
* **`63. Blend Mode` ($61)** (choice) : choix possibles => Add, Alpha, And, Average, Blue, Burn, Darken, Difference, Divide, Dodge, Exclusion, Freeze, Grainextract, Grainmerge, Green, Hardlight, Hardmix, Hue, Interpolation, Lighten, Lightness, Linearburn, Linearlight, Luminance, Multiply, Negation, Or, Overlay, Pinlight, Red, Reflect, Saturation, Screen, Shapeaverage, Softburn, Softdodge, Softlight, Stamp, Subtract, Value, Vividlight, Xor
* **`64. Opacity` ($62)** (float) : défaut = **1**  (0,1)
