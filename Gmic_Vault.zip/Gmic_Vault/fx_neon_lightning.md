---
tags: [gmic, filter]
command: fx_neon_lightning
---

# Filtre G'MIC : fx_neon_lightning

## Structure de la commande
```text
fx_neon_lightning:
    source_x = $1
    source_y = $2
    r0 = $3
    destination_x = $4
    destination_y = $5
    r1 = $6
    density = $7
    glow = $8
    thickness = $9
    color_dispersion = $13
    transparency = $14
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates neon-colored glowing lightning. 
* **`Source (%)` ($1)** (point) : position = 0,0
* **`R0` ($2)** (float) : défaut = **0**  (0,100)
* **`Destination (%)` ($3)** (point) : position = 0,0
* **`R1` ($4)** (float) : défaut = **100**  (0,100)
* **`Density` ($5)** (int) : défaut = **50**  (1,512)
* **`Glow` ($6)** (float) : défaut = **0.7**  (0,5)
* **`Thickness` ($7)** (float) : défaut = **3**  (0,20)
* **`Color` ($8)** (color) : défaut = 130,80,50
* **`Color Dispersion` ($9)** (float) : défaut = **0.25**  (0,1)
* **`Transparency` ($10)** (float) : défaut = **0**  (0,1)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/06/30.
