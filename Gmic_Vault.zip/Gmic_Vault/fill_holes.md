---
tags: [gmic, filter]
command: fill_holes
---

# Filtre G'MIC : fill_holes

## Structure de la commande
```text
fill_holes:
    morph_radius = $1
    edge_radius = $2
    close_radius = $3
    channel_s = $4
    fill_light_colours = $5
    fast = $6
```
## Définition des variables
* **`Morph Radius` ($1)** (int) : défaut = **11**  (3,50)
* **`Edge Radius` ($2)** (int) : défaut = **21**  (0,50)
* **`Close Radius` ($3)** (int) : défaut = **5**  (0,10)
* **`Channel(s)` ($4)** (choice) : choix possibles => All, RGBA [all], RGB [all], RGB [red], RGB [green], RGB [blue], RGBA [alpha], YCbCr [luminance], YCbCr [blue-Red Chrominances], YCbCr [blue Chrominance], YCbCr [red Chrominance], YCbCr [green Chrominance], Lab [lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [hue], HSV [saturation], HSV [value], HSI [intensity], HSL [lightness], CMYK [cyan], CMYK [magenta], CMYK [yellow], CMYK [key]
* **`Fill Light Colours` ($5)** (bool) : par défaut = Faux (0)
* **`Fast` ($6)** (bool) : par défaut = Faux (0)
(Note) : Set Morph radius to close holes, set Edge radius to restore edges, set Close radius to fill small holes near the edge
(Note) : Author : Iain Fergusson.      Latest update : 28 August 2012 - added 'fast' option
