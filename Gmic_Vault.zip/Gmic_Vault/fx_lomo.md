---
tags: [gmic, filter]
command: fx_lomo
---

# Filtre G'MIC : fx_lomo

## Structure de la commande
```text
fx_lomo:
    vignette_size = $1
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates the high-contrast, vignetted look of Lomo cameras. 
* **`Vignette Size` ($1)** (float) : défaut = **20**  (0,100)
(Note) : Authors: Jérome Boulanger and <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.       Latest Update: 2012/06/06.
