---
tags: [gmic, filter]
command: fx_jfif
---

# Filtre G'MIC : fx_jfif

## Structure de la commande
```text
fx_jfif:
    1_quality = $1
    2_encoding = $2
    3_power = $3
    4_colour_distortion = $4
    5_max_glitch_length = $5
    6_max_value_errors_per_tile = $6
    7_error_strength = $7
    8_persistent_value_errors_power = $8
    9_error_bias = $9
    10_tile_shift_power = $10
    11_mirror = $11
    12_rotate = $12
    13_enable = $13
    14_mesh_x = $14
    15_mesh_y = $15
    16_mesh_smoothness = $16
    17_contrast_scheme = $17
    18_mesh_contrast = $18
    19_scale_x = $19
    20_scale_y = $20
    21_interpolation = $21
    22_normalise = $22
    23_output_mesh = $23
    preview_type = $24
    preview_split_x = $25
    preview_split_y = $26
```
## Définition des variables
(Note) : A poorly-implemented JFIF encoder with extras, all designed to screw with images. Quite slow and very aggressive.
* **`1. Quality (%)` ($1)** (int) : défaut = **50**  (1,100)
* **`2. Encoding` ($2)** (choice) : choix possibles => 444, 442, 424, 422
(Note) : Fake Glitch
* **`3. Power` ($3)** (float) : défaut = **0**  (0,10)
* **`4. Colour Distortion` ($4)** (float) : défaut = **1**  (0,2)
* **`5. Max Glitch Length` ($5)** (int) : défaut = **5**  (2,10)
* **`6. Max Value Errors Per Tile` ($6)** (int) : défaut = **5**  (0,10)
* **`7. Error Strength` ($7)** (float) : défaut = **3**  (0,8)
* **`8. Persistent Value Errors Power` ($8)** (float) : défaut = **0.25**  (0,1)
* **`9. Error Bias` ($9)** (float) : défaut = **0.5**  (0,1)
* **`10. Tile Shift Power` ($10)** (float) : défaut = **0.25**  (0,1)
* **`11. Mirror` ($11)** (choice) : choix possibles => None, X, Y, XY
* **`12. Rotate` ($12)** (choice) : choix possibles => None, 90 Clockwise, 180, 90 Anticlockwise
(Note) : Self-Bomb
* **`13. Enable` ($13)** (bool) : par défaut = Faux (0)
* **`14. Mesh X` ($14)** (int) : défaut = **16**  (1,256)
* **`15. Mesh Y` ($15)** (int) : défaut = **16**  (1,256)
* **`16. Mesh Smoothness` ($16)** (float) : défaut = **0.5**  (0,10)
* **`17. Contrast Scheme` ($17)** (choice) : choix possibles => Arctan, Clip, Power
* **`18. Mesh Contrast` ($18)** (float) : défaut = **75**  (0,100)
* **`19. Scale X` ($19)** (float) : défaut = **1**  (0.05,16)
* **`20. Scale Y` ($20)** (float) : défaut = **1**  (0.05,16)
* **`21. Interpolation` ($21)** (choice) : choix possibles => None, Nearest, Average, Bilinear, Grid, Bicubic
* **`22. Normalise` ($22)** (bool) : par défaut = Faux (0)
* **`23. Output Mesh` ($23)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($24)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($25)** (point) : position = 0,0
(Note) : Author: Joan Rake, 'borrowed' from <a href="https://goo.gl/Ryf7Cv">David Tschumperlé</a>.      Latest Update: 2017/05/07.
