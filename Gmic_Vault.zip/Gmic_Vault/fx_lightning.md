---
tags: [gmic, filter]
command: fx_lightning
---

# Filtre G'MIC : fx_lightning

## Structure de la commande
```text
fx_lightning:
    number_of_streaks = $1
    size = $2
    resolution = $3
    randomness = $4
    smoothness = $5
    balance = $6
    seed = $11
    xy_coordinates_x = $12
    xy_coordinates_y = $13
    angle_deg = $14
    thickness_px = $15
    blur = $16
    min_offset = $17
    max_offset = $18
    min_length = $19
    max_length = $20
    min_angle_deviation_deg = $21
    max_angle_deviation_deg = $22
    thickness_factor = $23
    blur_factor = $24
    opacity_factor = $25
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates procedural lightning bolts. 
(Note) : Global parameters:
* **`Number of Streaks` ($1)** (int) : défaut = **20**  (1,1024)
* **`Size (%)` ($2)** (float) : défaut = **90**  (0,150)
* **`Resolution` ($3)** (int) : défaut = **256**  (2,4096)
* **`Randomness` ($4)** (float) : défaut = **3**  (0,16)
* **`Smoothness` ($5)** (float) : défaut = **1.5**  (0,10)
* **`Balance` ($6)** (float) : défaut = **0.75**  (0,1)
* **`Color` ($7)** (color) : défaut = 255,255,255,255
* **`Seed` ($8)** (int) : défaut = **0**  (0,65535)
(Note) : Initial streak:
* **`XY-Coordinates (%)` ($9)** (point) : position = 0,0
* **`Angle (deg)` ($10)** (float) : défaut = **0**  (-180,180)
* **`Thickness (px)` ($11)** (int) : défaut = **6**  (1,64)
* **`Blur` ($12)** (float) : défaut = **0.2**  (0,3)
(Note) : Auxiliary streaks:
* **`Min Offset (%)` ($13)** (float) : défaut = **25**  (0,100)
* **`Max Offset (%)` ($14)** (float) : défaut = **60**  (0,100)
* **`Min Length (%)` ($15)** (float) : défaut = **95**  (0,200)
* **`Max Length (%)` ($16)** (float) : défaut = **100**  (0,200)
* **`Min Angle Deviation (deg)` ($17)** (float) : défaut = **30**  (0,180)
* **`Max Angle Deviation (deg)` ($18)** (float) : défaut = **40**  (0,180)
* **`Thickness Factor` ($19)** (float) : défaut = **-0.25**  (-1,1)
* **`Blur Factor` ($20)** (float) : défaut = **-0.1**  (-1,1)
* **`Opacity Factor` ($21)** (float) : défaut = **-0.20**  (-1,1)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2014/11/27.
