---
tags: [gmic, filter]
command: fx_gb_lb
---

# Filtre G'MIC : fx_gb_lb

## Structure de la commande
```text
fx_gb_lb:
    amplitude = $1
    bokeh = $2
    preview_type = $3
```
## Définition des variables
(Note) : 
Usage Notes:  Set Output mode to 'New image' or 'in place' to simply reverse the frames in this image.  Set mode to 'New layers' to add the reversing effect to your current image.
* **`Amplitude` ($1)** (float) : défaut = **10**  (5,20)
* **`Bokeh` ($2)** (float) : défaut = **7**  (0,20)
* **`Preview Type` ($3)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
