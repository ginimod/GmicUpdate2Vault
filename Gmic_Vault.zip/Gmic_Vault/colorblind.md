---
tags: [gmic, filter]
command: colorblind
---

# Filtre G'MIC : colorblind

## Structure de la commande
```text
colorblind:
    blindness_type = $1
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates various types of color blindness. 
* **`Blindness Type` ($1)** (choice) : choix possibles => Protanopia, Protanomaly, Deuteranopia, Deuteranomaly, Tritanopia, Tritanomaly, Achromatopsia, Achromatomaly
(Note) : Note: This filter simulates different types of colorblindness vision. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/04/20.
