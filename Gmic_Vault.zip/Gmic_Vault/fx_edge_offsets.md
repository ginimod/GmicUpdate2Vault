---
tags: [gmic, filter]
command: fx_edge_offsets
---

# Filtre G'MIC : fx_edge_offsets

## Structure de la commande
```text
fx_edge_offsets:
    smoothness = $1
    threshold = $2
    scale = $3
    thickness = $4
    negative_colors = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Detects edges and computes their offset. 
* **`Smoothness` ($1)** (float) : défaut = **0**  (0,10)
* **`Threshold` ($2)** (float) : défaut = **15**  (0,50)
* **`Scale` ($3)** (int) : défaut = **4**  (0,32)
* **`Thickness` ($4)** (int) : défaut = **1**  (0,16)
* **`Negative Colors` ($5)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
