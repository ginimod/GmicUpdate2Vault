---
tags: [gmic, filter]
command: fx_blur_gaussian
---

# Filtre G'MIC : fx_blur_gaussian

## Structure de la commande
```text
fx_blur_gaussian:
    xy_amplitude = $1
    x_amplitude = $2
    y_amplitude = $3
    boundary = $4
    channel_s = $5
    value_action = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Applies a standard Gaussian blur. 
* **`XY-Amplitude (%)` ($1)** (float) : défaut = **3**  (0,50)
* **`X-Amplitude (%)` ($2)** (float) : défaut = **0**  (0,50)
* **`Y-Amplitude (%)` ($3)** (float) : défaut = **0**  (0,50)
* **`Boundary` ($4)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
* **`Channel(s)` ($5)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
* **`Value Action` ($6)** (choice) : choix possibles => None, Cut, Normalize
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
