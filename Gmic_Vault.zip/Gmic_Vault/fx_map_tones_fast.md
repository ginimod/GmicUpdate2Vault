---
tags: [gmic, filter]
command: fx_map_tones_fast
---

# Filtre G'MIC : fx_map_tones_fast

## Structure de la commande
```text
fx_map_tones_fast:
    radius = $1
    power = $2
    channel_s = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> A faster implementation of tone mapping. 
* **`Radius` ($1)** (float) : défaut = **3**  (0,20)
* **`Power` ($2)** (float) : défaut = **0.5**  (0,1)
* **`Channel(s)` ($3)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Authors: Paul Nasca and <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.       Latest Update: 2011/10/06.
