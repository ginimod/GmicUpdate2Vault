---
tags: [gmic, filter]
command: fx_corner_gradient
---

# Filtre G'MIC : fx_corner_gradient

## Structure de la commande
```text
fx_corner_gradient:
    quantization = $17
    color_space = $18
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a gradient from defined corner colors. 
* **`Color 1 (Up/Left Corner)` ($1)** (color) : défaut = 255,255,255,128
* **`Color 2 (Up/Right Corner)` ($2)** (color) : défaut = 255,0,0,255
* **`Color 3 (Bottom/Left Corner)` ($3)** (color) : défaut = 0,255,0,255
* **`Color 4 (Bottom/Right Corner)` ($4)** (color) : défaut = 0,0,255,255
* **`Quantization` ($5)** (int) : défaut = **0**  (0,64)
* **`Color Space` ($6)** (choice) : choix possibles => SRGB, Linear RGB, Lab
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2025/10/20.
