---
tags: [gmic, filter]
command: fx_ditheredbw
---

# Filtre G'MIC : fx_ditheredbw

## Structure de la commande
```text
fx_ditheredbw:
    brightness = $1
    contrast = $2
    gamma = $3
    hue = $4
    saturation = $5
    smoothness = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Converts to 1-bit B&W using dithering algorithm. 
* **`Brightness (%)` ($1)** (float) : défaut = **0**  (-100,100)
* **`Contrast (%)` ($2)** (float) : défaut = **0**  (-100,100)
* **`Gamma (%)` ($3)** (float) : défaut = **0**  (-100,100)
* **`Hue` ($4)** (float) : défaut = **0**  (0,360)
* **`Saturation (%)` ($5)** (float) : défaut = **0**  (0,100)
* **`Smoothness` ($6)** (float) : défaut = **0**  (0,10)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
