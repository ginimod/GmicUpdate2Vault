---
tags: [gmic, filter]
command: fx_colorstamp
---

# Filtre G'MIC : fx_colorstamp

## Structure de la commande
```text
fx_colorstamp:
    auto_threshold = $1
    threshold = $2
    activate_color_module = $3
    quantize_colors = $4
    color_smoothness = $5
    preview_type = $6
```
## Définition des variables
(Note) : BW module,analog to Stamp filter
* **`Auto-Threshold` ($1)** (bool) : par défaut = Faux (0)
* **`Threshold` ($2)** (int) : défaut = **50**  (0,100)
(Note) : Color module
* **`Activate Color Module` ($3)** (bool) : par défaut = Faux (0)
* **`Quantize Colors` ($4)** (int) : défaut = **20**  (2,255)
* **`Color Smoothness` ($5)** (float) : défaut = **2**  (0,20)
* **`Preview Type` ($6)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Authors: PhotoComiX , Antaron, Mahvin, David Tschumperlé.             Latest update : 2011/17/05.
