---
tags: [gmic, filter]
command: engrave_modifie
---

# Filtre G'MIC : engrave_modifie

## Structure de la commande
```text
engrave_modifie:
    exemples_examples = $1
    radius = $2
    densite_a = $3
    edges = $4
    coherence = $5
    threshold = $6
    minimal_area = $7
    repetition = $8
    anti_aliasing = $9
```
## Définition des variables
(Note) : Aussi pour obtenir des contours
* **`Exemples / Examples` ($1)** (choice) : choix possibles => Non / None, A, B, C, D ***, E, F, G
(Note) : Black & White foreground:
* **`Radius` ($2)** (float) : défaut = **0.5**  (0,2)
* **`Densité A` ($3)** (float) : défaut = **4**  (0,10)
* **`Edges` ($4)** (float) : défaut = **0**  (0,10)
* **`Cohérence` ($5)** (float) : défaut = **8**  (0,40)
* **`Threshold (%)` ($6)** (float) : défaut = **40**  (0,100)
* **`Minimal Area` ($7)** (int) : défaut = **0**  (-256,256)
* **`Répétition` ($8)** (int) : défaut = **25**  (0,50)
* **`Anti-Aliasing` ($9)** (choice) : choix possibles => Disabled, X1.5, X2, X3
(Note) : Authors: Lyle Kroll and <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest update: samj 2015/03/20.
