---
tags: [gmic, filter]
command: fx_canvas
---

# Filtre G'MIC : fx_canvas

## Structure de la commande
```text
fx_canvas:
    amplitude = $1
    angle = $2
    sharpness = $3
    enable_second_direction = $4
    amplitude = $5
    angle = $6
    sharpness = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Applies a canvas relief texture. 
(Note) : First direction :
* **`Amplitude` ($1)** (float) : défaut = **70**  (0,300)
* **`Angle` ($2)** (float) : défaut = **45**  (0,180)
* **`Sharpness` ($3)** (float) : défaut = **400**  (0,2000)
(Note) : 
Second direction : 
* **`Enable Second Direction` ($4)** (bool) : par défaut = Faux (0)
* **`Amplitude` ($5)** (float) : défaut = **70**  (0,300)
* **`Angle` ($6)** (float) : défaut = **135**  (0,180)
* **`Sharpness` ($7)** (float) : défaut = **400**  (0,2000)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
