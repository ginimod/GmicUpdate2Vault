---
tags: [gmic, filter]
command: fx_gcd_adjust_aspect
---

# Filtre G'MIC : fx_gcd_adjust_aspect

## Structure de la commande
```text
fx_gcd_adjust_aspect:
    aspect = $1
    source = $2
    inpaint = $3
```
## Définition des variables
(Note) : Set or expand to aspect ratio
* **`Aspect` ($1)** (choice) : choix possibles => Original, 2:3, 3:4, 1:1, 4:3, 5:4, 16:9, 16:10, 2.35:1, 1.85:1
* **`Source` ($2)** (choice) : choix possibles => Fixed, Dimensions, 2:3, 3:4, 1:1, 4:3, 5:4, 16:9, 16:10, 2.35:1, 1.85:1
* **`Inpaint` ($3)** (choice) : choix possibles => None, Flat, Blur, Pyramid
(Note) : Author : Garagecoder.      Latest update : 2024/05/01.
(Note) : 
<u>Notes</u>
(Note) : Use fixed source for border expansion
(Note) : Dimensions source assumes aspect is width:height
(Note) : Transparent regions will be inpainted
