---
tags: [gmic, filter]
command: fx_noise_gradient
---

# Filtre G'MIC : fx_noise_gradient

## Structure de la commande
```text
fx_noise_gradient:
    strength = $1
    smoothness = $2
    noise_type = $3
    channel_s = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds noise on image gradients. 
* **`Strength` ($1)** (float) : défaut = **100**  (0,255)
* **`Smoothness[%]` ($2)** (float) : défaut = **0**  (0,100)
* **`Noise Type` ($3)** (choice) : choix possibles => Gaussian, Uniform
* **`Channel(s)` ($4)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2023/12/06.
