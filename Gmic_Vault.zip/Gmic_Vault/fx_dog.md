---
tags: [gmic, filter]
command: fx_dog
---

# Filtre G'MIC : fx_dog

## Structure de la commande
```text
fx_dog:
    1st_variance = $1
    2nd_variance = $2
    threshold = $3
    negative_colors = $4
    monochrome = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Highlights edges using the Difference of Gaussians method. 
* **`1st Variance` ($1)** (float) : défaut = **1.4**  (0,5)
* **`2nd Variance` ($2)** (float) : défaut = **1.5**  (0,5)
* **`Threshold` ($3)** (float) : défaut = **0**  (0,49)
* **`Negative Colors` ($4)** (bool) : par défaut = Faux (0)
* **`Monochrome` ($5)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
