---
tags: [gmic, filter]
command: fx_frame_cube
---

# Filtre G'MIC : fx_frame_cube

## Structure de la commande
```text
fx_frame_cube:
    depth = $1
    center_x = $2
    center_y = $3
    left_side_orientation = $4
    right_side_orientation = $5
    upper_side_orientation = $6
    lower_side_orientation = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Maps the image onto the inside faces of a 3D cube. 
* **`Depth` ($1)** (float) : défaut = **3**  (0,30)
* **`Center` ($2)** (point) : position = 0,0
* **`Left Side Orientation` ($3)** (choice) : choix possibles => Normal, Mirror-X, Mirror-Y, Mirror-XY
* **`Right Side Orientation` ($4)** (choice) : choix possibles => Normal, Mirror-X, Mirror-Y, Mirror-XY
* **`Upper Side Orientation` ($5)** (choice) : choix possibles => Normal, Mirror-X, Mirror-Y, Mirror-XY
* **`Lower Side Orientation` ($6)** (choice) : choix possibles => Normal, Mirror-X, Mirror-Y, Mirror-XY
(Note) : Author: David Tschumperlé, Angelo Lama.       Latest Update: 2012/01/29.
