---
tags: [gmic, filter]
command: fx_gca
---

# Filtre G'MIC : fx_gca

## Structure de la commande
```text
fx_gca:
    amplitude = $4
    max_value = $5
    channel = $6
    preview_type = $7
```
## Définition des variables
* **`Reference Color` ($1)** (color) : défaut = 255,255,255
* **`Amplitude` ($2)** (float) : défaut = **1**  (0,5)
* **`Max Value` ($3)** (choice) : choix possibles => From Input, From Reference Color, Maximum Allowed
* **`Channel` ($4)** (choice) : choix possibles => Saturation, Lightness
* **`Preview Type` ($5)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest update: 2015/15/07.
