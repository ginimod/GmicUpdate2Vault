---
tags: [gmic, filter]
command: fx_apply_haldclut
---

# Filtre G'MIC : fx_apply_haldclut

## Structure de la commande
```text
fx_apply_haldclut:
    specify_haldclut_as = $1
    pre_normalize_clut = $3
    strength = $4
    brightness = $5
    contrast = $6
    gamma = $7
    hue = $8
    saturation = $9
    normalize_colors = $10
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Applies an external HaldCLUT (Color Look-Up Table) file. 
* **`Specify HaldCLUT As` ($1)** (choice) : choix possibles => Top Layer, Bottom Layer, Filename
(Note) : Note: Do not forget to set the Input layers option if you select Top layer or Bottom layer.
* **`Pre-Normalize CLUT` ($2)** (bool) : par défaut = Faux (0)
* **`Strength (%)` ($3)** (float) : défaut = **100**  (0,100)
* **`Brightness (%)` ($4)** (float) : défaut = **0**  (-100,100)
* **`Contrast (%)` ($5)** (float) : défaut = **0**  (-100,100)
* **`Gamma (%)` ($6)** (float) : défaut = **0**  (-100,100)
* **`Hue (%)` ($7)** (float) : défaut = **0**  (-100,100)
* **`Saturation (%)` ($8)** (float) : défaut = **0**  (-100,100)
* **`Normalize Colors` ($9)** (choice) : choix possibles => None, Pre-Normalize, Post-Normalize, Both
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2025/05/28.
