---
tags: [gmic, filter]
command: fx_otsu_hessian_blend
---

# Filtre G'MIC : fx_otsu_hessian_blend

## Structure de la commande
```text
fx_otsu_hessian_blend:
    otsu_levels = $1
    norm_1 = $2
    norm_2 = $3
    merging_option = $4
    opacity = $5
    reverse_order = $6
```
## Définition des variables
(Note) : Expansion of <a href="https://discuss.pixls.us/t/one-liner-challenge/8785/7?u=joan_rake1">a one-line filter by Afre</a>.
* **`Otsu Levels` ($1)** (int) : défaut = **4**  (1,32)
* **`Norm 1` ($2)** (float) : défaut = **0**  (-5,5)
* **`Norm 2` ($3)** (float) : défaut = **1**  (-5,5)
* **`Merging Option` ($4)** (choice) : choix possibles => Add, Alpha, And, Average, Blue, Burn, Darken, Difference, Divide, Dodge, Exclusion, Freeze, Grainextract, Grainmerge, Green, Hardlight, Hardmix, Hue, Interpolation, Lighten, Lightness, Linearburn, Linearlight, Luminance, Multiply, Negation, Or, Overlay, Pinlight, Red, Reflect, Saturation, Screen, Shapeaverage, Softburn, Softdodge, Softlight, Stamp, Subtract, Value, Vividlight, Xor
* **`Opacity` ($5)** (float) : défaut = **1**  (0,1)
* **`Reverse Order` ($6)** (bool) : par défaut = Faux (0)
