---
tags: [gmic, filter]
command: fx_charred_plastic
---

# Filtre G'MIC : fx_charred_plastic

## Structure de la commande
```text
fx_charred_plastic:
    1_amplitude = $1
    2_gaussian_1 = $2
    3_gaussian_2 = $3
    4_mode = $4
    5_amplitude = $5
    6_noise_type = $6
    7_channel_s = $7
    8_amplitude = $8
    9_radius = $9
    10_neighborhood_smoothness = $10
    11_average_smoothness = $11
    12_constrain_values = $12
    13_channel_s = $13
```
## Définition des variables
(Note) : Difference of Gaussians
* **`1. Amplitude` ($1)** (float) : défaut = **1**  (-10,10)
* **`2. Gaussian 1` ($2)** (float) : défaut = **10**  (0,100)
* **`3. Gaussian 2` ($3)** (float) : défaut = **40**  (0,100)
* **`4. Mode` ($4)** (choice) : choix possibles => Pixels, Percent
(Note) : Noise
* **`5. Amplitude` ($5)** (float) : défaut = **10**  (0,200)
* **`6. Noise Type` ($6)** (choice) : choix possibles => Gaussian, Uniform, Salt and Pepper, Poisson, Rice
* **`7. Channel(s)` ($7)** (choice) : choix possibles => All, RGBA [all], RGB [all], RGB [red], RGB [green], RGB [blue], RGBA [alpha], Linear RGB [all], Linear RGB [red], Linear RGB [green], Linear RGB [blue], YCbCr [luminance], YCbCr [blue-Red Chrominances], YCbCr [blue Chrominance], YCbCr [red Chrominance], YCbCr [green Chrominance], Lab [lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [hue], HSV [saturation], HSV [value], HSI [intensity], HSL [lightness], CMYK [cyan], CMYK [magenta], CMYK [yellow], CMYK [key], YIQ [luma], YIQ [chromas]
(Note) : Local Normalization
* **`8. Amplitude` ($8)** (float) : défaut = **2**  (0,60)
* **`9. Radius` ($9)** (int) : défaut = **6**  (1,64)
* **`10. Neighborhood Smoothness` ($10)** (float) : défaut = **5**  (0,40)
* **`11. Average Smoothness` ($11)** (float) : défaut = **20**  (0,40)
* **`12. Constrain Values` ($12)** (bool) : par défaut = Faux (0)
* **`13. Channel(s)` ($13)** (choice) : choix possibles => All, RGBA [All], RGB [All], RGB [Red], RGB [Green], RGB [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [Hue], HSV [Saturation], HSV [Value], HSI [Intensity], HSL [Lightness], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
