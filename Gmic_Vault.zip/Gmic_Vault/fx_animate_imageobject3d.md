---
tags: [gmic, filter]
command: fx_animate_imageobject3d
---

# Filtre G'MIC : fx_animate_imageobject3d

## Structure de la commande
```text
fx_animate_imageobject3d:
    frames = $1
    output_as_frames = $2
    output_as_files = $3
    type = $5
    width = $6
    height = $7
    rendering = $8
    size = $9
    x_angle = $10
    y_angle = $11
    z_angle = $12
    fov = $13
    x_light = $14
    y_light = $15
    z_light = $16
    specular_lightness = $17
    specular_shininess = $18
    size = $19
    x_angle = $20
    y_angle = $21
    z_angle = $22
    fov = $23
    x_light = $24
    y_light = $25
    z_light = $26
    specular_lightness = $27
    specular_shininess = $28
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Animates a 3D object mapped with the image. 
* **`Frames` ($1)** (int) : défaut = **10**  (2,100)
* **`Output as Frames` ($2)** (bool) : par défaut = Faux (0)
* **`Output as Files` ($3)** (bool) : par défaut = Faux (0)
(Note) : 
Global parameters :
* **`Type` ($4)** (choice) : choix possibles => Plane, Cube, Pyramid, Sphere, Torus, Gyroid, Weird, Cup, Rubik
* **`Width` ($5)** (int) : défaut = **1024**  (1,4096)
* **`Height` ($6)** (int) : défaut = **1024**  (1,4096)
* **`Rendering` ($7)** (choice) : choix possibles => Dots, Wireframe, Flat, Flat-Shaded, Gouraud, Phong
(Note) : 
Starting parameters :
* **`Size` ($8)** (float) : défaut = **0.5**  (0,3)
* **`X-Angle` ($9)** (float) : défaut = **57**  (0,360)
* **`Y-Angle` ($10)** (float) : défaut = **41**  (0,360)
* **`Z-Angle` ($11)** (float) : défaut = **21**  (0,360)
* **`FOV` ($12)** (float) : défaut = **45**  (1,90)
* **`X-Light` ($13)** (float) : défaut = **0**  (-100,100)
* **`Y-Light` ($14)** (float) : défaut = **0**  (-100,100)
* **`Z-Light` ($15)** (float) : défaut = **-100**  (-100,0)
* **`Specular Lightness` ($16)** (float) : défaut = **0.5**  (0,1)
* **`Specular Shininess` ($17)** (float) : défaut = **0.7**  (0,3)
(Note) : 
Ending parameters :
* **`Size` ($18)** (float) : défaut = **0.5**  (0,3)
* **`X-Angle` ($19)** (float) : défaut = **57**  (0,1440)
* **`Y-Angle` ($20)** (float) : défaut = **401**  (0,1440)
* **`Z-Angle` ($21)** (float) : défaut = **21**  (0,1440)
* **`FOV` ($22)** (float) : défaut = **45**  (1,90)
* **`X-Light` ($23)** (float) : défaut = **0**  (-100,100)
* **`Y-Light` ($24)** (float) : défaut = **0**  (-100,100)
* **`Z-Light` ($25)** (float) : défaut = **-100**  (-100,0)
* **`Specular Lightness` ($26)** (float) : défaut = **0.5**  (0,1)
* **`Specular Shininess` ($27)** (float) : défaut = **0.7**  (0,3)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
