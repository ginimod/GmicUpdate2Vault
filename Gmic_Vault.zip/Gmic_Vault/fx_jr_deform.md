---
tags: [gmic, filter]
command: fx_jr_deform
---

# Filtre G'MIC : fx_jr_deform

## Structure de la commande
```text
fx_jr_deform:
    amplitude = $2
    interpolation = $3
    matrix_density = $4
    matrix_interpolation = $5
    mode = $6
    character = $7
    boundary = $8
    preview_type = $9
    preview_split_x = $10
    preview_split_y = $11
```
## Définition des variables
* **`Amplitude` ($1)** (float) : défaut = **5**  (0,50)
* **`Interpolation` ($2)** (choice) : choix possibles => None, Linear, Bicubic
* **`Matrix Density` ($3)** (float) : défaut = **10**  (1,100)
* **`Matrix Interpolation` ($4)** (choice) : choix possibles => Linear, Bicubic
* **`Mode` ($5)** (choice) : choix possibles => Noise, Spread Noise
* **`Character` ($6)** (float) : défaut = **0**  (-100,100)
* **`Boundary` ($7)** (choice) : choix possibles => Dirichlet, Neumann, Periodic, Mirror
* **`Preview Type` ($8)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($9)** (point) : position = 0,0
