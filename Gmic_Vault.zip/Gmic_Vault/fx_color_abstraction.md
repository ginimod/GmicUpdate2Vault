---
tags: [gmic, filter]
command: fx_color_abstraction
---

# Filtre G'MIC : fx_color_abstraction

## Structure de la commande
```text
fx_color_abstraction:
    smoothness = $1
    levels = $2
    contrast = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simplifies the image colors into a more abstract palette. 
* **`Smoothness` ($1)** (float) : défaut = **1**  (0,10)
* **`Levels` ($2)** (int) : défaut = **10**  (2,100)
* **`Contrast` ($3)** (float) : défaut = **0.2**  (0.01,1)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2011/10/19.
