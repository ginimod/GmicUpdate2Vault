---
tags: [gmic, filter]
command: dt_segment_shaded
---

# Filtre G'MIC : dt_segment_shaded

## Structure de la commande
```text
dt_segment_shaded:
    density = $1
    shading = $2
    smoothness = $3
```
## Définition des variables
* **`Density` ($1)** (float) : défaut = **1**  (0,3)
* **`Shading` ($2)** (float) : défaut = **0.7**  (0,2)
* **`Smoothness` ($3)** (float) : défaut = **1**  (0,10)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest update: 2013/01/02.
