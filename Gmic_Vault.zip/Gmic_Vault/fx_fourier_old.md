---
tags: [gmic, filter]
command: fx_fourier_old
---

# Filtre G'MIC : fx_fourier_old

## Structure de la commande
```text
fx_fourier_old:
    magnitude_phase = $1
    discard_transparency = $2
```
## Définition des variables
* **`Magnitude / Phase` ($1)** (choice) : choix possibles => One Layer (Horizontal), One Layer (Vertical), Two Layers
* **`Discard Transparency` ($2)** (bool) : par défaut = Faux (0)
(Note) : Note: Apply this filter once to get the direct FFT, and once again to get the reverse transform.
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2018/06/16.
