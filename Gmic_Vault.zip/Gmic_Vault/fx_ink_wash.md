---
tags: [gmic, filter]
command: fx_ink_wash
---

# Filtre G'MIC : fx_ink_wash

## Structure de la commande
```text
fx_ink_wash:
    size = $1
    amplitude = $2
    skip_all_other_steps = $3
    smoother_sharpness = $4
    smoother_edge_protection = $5
    smoother_softness = $6
    stretch_contrast = $7
    ln_amplitude = $8
    ln_size = $9
    ln_neightborhood_smoothness = $10
    ln_average_smoothness = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates an ink wash painting style. 
(Note) : Ink wash controls
* **`Size` ($1)** (float) : défaut = **0.14**  (0,4)
* **`Amplitude` ($2)** (float) : défaut = **23**  (0,200)
(Note) : Check if you wish visual control on this step
* **`Skip All Other Steps` ($3)** (bool) : par défaut = Faux (0)
(Note) : Uncheck to reactivate the other controls
* **`Smoother Sharpness` ($4)** (float) : défaut = **0.5**  (0,2)
* **`Smoother Edge Protection` ($5)** (float) : défaut = **0.54**  (0,1)
* **`Smoother Softness` ($6)** (float) : défaut = **2.25**  (0,10)
* **`Stretch Contrast` ($7)** (choice) : choix possibles => None, Automatic, Automatic & Contrast Mask, Manual Controls
(Note) : To activate the sliders below chose 'Manual Controls'
* **`LN Amplitude` ($8)** (float) : défaut = **2**  (0,60)
* **`LN Size` ($9)** (float) : défaut = **6**  (0,64)
* **`LN Neightborhood-Smoothness` ($10)** (float) : défaut = **5**  (0,40)
* **`LN Average-Smoothness` ($11)** (float) : défaut = **20**  (0,40)
(Note) : Author: PhotoComiX.       Latest Update: 2011/04/05.
