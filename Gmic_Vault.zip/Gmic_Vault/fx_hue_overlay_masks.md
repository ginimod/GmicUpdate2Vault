---
tags: [gmic, filter]
command: fx_hue_overlay_masks
---

# Filtre G'MIC : fx_hue_overlay_masks

## Structure de la commande
```text
fx_hue_overlay_masks:
    stretch_constrast = $1
    preview_type = $2
```
## Définition des variables
(Note) : This plugin creates RGB hue masks. They are be exported in overlay mode into Gimp. Try each one to see how it changes your picture. Alternatively you can use them as masks to select regions based on hue.
* **`Stretch Constrast` ($1)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($2)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right
(Note) : More details <a href="https://discuss.pixls.us/t/hue-overlay-masks-my-first-filter">here</a>.
(Note) : Author: <a href="https://discuss.pixls.us/u/McCap">McCap/pixls.us</a>.      Latest update: 2017/09/02.
