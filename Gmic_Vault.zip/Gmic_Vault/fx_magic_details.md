---
tags: [gmic, filter]
command: fx_magic_details
---

# Filtre G'MIC : fx_magic_details

## Structure de la commande
```text
fx_magic_details:
    amplitude = $1
    spatial_scale = $2
    value_scale = $3
    edges = $4
    smoothness = $5
    channel_s = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Enhances details locally using Bilateral filter. 
* **`Amplitude` ($1)** (float) : défaut = **6**  (0,30)
* **`Spatial Scale` ($2)** (float) : défaut = **3**  (0,10)
* **`Value Scale` ($3)** (float) : défaut = **15**  (0,20)
* **`Edges` ($4)** (float) : défaut = **-0.5**  (-3,3)
* **`Smoothness` ($5)** (float) : défaut = **2**  (0,20)
* **`Channel(s)` ($6)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2018/01/10.
