---
tags: [gmic, filter]
command: bayer2rgb
---

# Filtre G'MIC : bayer2rgb

## Structure de la commande
```text
bayer2rgb:
    g_m_smoothness = $1
    r_b_smoothness_principal = $2
    r_b_smoothness_secondary = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Demosaics a Bayer Pattern image into RGB. 
* **`G/M Smoothness` ($1)** (float) : défaut = **6**  (0,20)
* **`R/B Smoothness (Principal)` ($2)** (float) : défaut = **6**  (0,20)
* **`R/B Smoothness (Secondary)` ($3)** (float) : défaut = **4**  (0,20)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
