---
tags: [gmic, filter]
command: fx_animate_cartoon
---

# Filtre G'MIC : fx_animate_cartoon

## Structure de la commande
```text
fx_animate_cartoon:
    frames = $1
    output_frames = $2
    output_files = $3
    color_quantization = $5
    smoothness = $6
    sharpening = $7
    edge_threshold = $8
    edge_thickness = $9
    color_strength = $10
    smoothness = $11
    sharpening = $12
    edge_threshold = $13
    edge_thickness = $14
    color_strength = $15
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Animates the parameters of the cartoon effect. 
* **`Frames` ($1)** (int) : défaut = **10**  (2,100)
* **`Output Frames` ($2)** (bool) : par défaut = Faux (0)
* **`Output Files` ($3)** (bool) : par défaut = Faux (0)
(Note) : 
Global Parameters :
* **`Color Quantization` ($4)** (int) : défaut = **4**  (2,256)
(Note) : 
Starting parameters :
* **`Smoothness` ($5)** (float) : défaut = **0.5**  (0,2)
* **`Sharpening` ($6)** (float) : défaut = **200**  (0,400)
* **`Edge Threshold` ($7)** (float) : défaut = **10**  (1,30)
* **`Edge Thickness` ($8)** (float) : défaut = **0.1**  (0,1)
* **`Color Strength` ($9)** (float) : défaut = **1.5**  (0,3)
(Note) : 
Ending parameters :
* **`Smoothness` ($10)** (float) : défaut = **3**  (0,2)
* **`Sharpening` ($11)** (float) : défaut = **200**  (0,400)
* **`Edge Threshold` ($12)** (float) : défaut = **10**  (1,30)
* **`Edge Thickness` ($13)** (float) : défaut = **0.1**  (0,1)
* **`Color Strength` ($14)** (float) : défaut = **1.5**  (0,3)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
