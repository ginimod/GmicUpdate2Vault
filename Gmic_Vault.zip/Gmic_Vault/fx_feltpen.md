---
tags: [gmic, filter]
command: fx_feltpen
---

# Filtre G'MIC : fx_feltpen

## Structure de la commande
```text
fx_feltpen:
    amplitude = $1
    density = $2
    smoothness = $3
    opacity = $4
    edge = $5
    thickness = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates a drawing made with felt-tip markers. 
* **`Amplitude` ($1)** (float) : défaut = **300**  (0,4000)
* **`Density` ($2)** (float) : défaut = **50**  (0,100)
* **`Smoothness` ($3)** (float) : défaut = **1**  (0,10)
* **`Opacity` ($4)** (float) : défaut = **0.1**  (0,1)
* **`Edge` ($5)** (float) : défaut = **20**  (0,100)
* **`Thickness` ($6)** (int) : défaut = **5**  (2,32)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2012/10/25.
