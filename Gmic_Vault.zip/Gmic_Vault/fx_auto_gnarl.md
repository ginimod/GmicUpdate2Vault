---
tags: [gmic, filter]
command: fx_auto_gnarl
---

# Filtre G'MIC : fx_auto_gnarl

## Structure de la commande
```text
fx_auto_gnarl:
    smoothness = $1
    contrast = $2
    min_threshold = $3
    max_threshold = $4
    negative = $5
    scale_x = $6
    scale_y = $7
    interpolation = $8
    amplitude = $9
    radius = $10
    neighborhood_smoothness = $11
    average_smoothness = $12
    constrain_values = $13
    smoothness = $14
    rounding = $15
    amplitude = $16
    interpolation = $17
    boundary = $18
```
## Définition des variables
(Note) : Applies random deformations mainly to sharp edges.
(Note) : Gradient Norm
* **`Smoothness` ($1)** (float) : défaut = **3**  (0,10)
* **`Contrast` ($2)** (float) : défaut = **0.45**  (0,1.5)
* **`Min Threshold` ($3)** (float) : défaut = **40**  (0,100)
* **`Max Threshold` ($4)** (float) : défaut = **60**  (0,100)
* **`Negative` ($5)** (bool) : par défaut = Faux (0)
* **`Scale X` ($6)** (float) : défaut = **1**  (0,5)
* **`Scale Y` ($7)** (float) : défaut = **1**  (0,5)
* **`Interpolation` ($8)** (choice) : choix possibles => Nearest, Average, Bilinear, Bicubic
(Note) : Noise Local Normalisation
* **`Amplitude` ($9)** (float) : défaut = **4**  (0,60)
* **`Radius` ($10)** (int) : défaut = **6**  (1,64)
* **`Neighborhood Smoothness` ($11)** (float) : défaut = **5**  (0,40)
* **`Average Smoothness` ($12)** (float) : défaut = **20**  (0,40)
* **`Constrain Values` ($13)** (bool) : par défaut = Faux (0)
(Note) : Warping
* **`Smoothness` ($14)** (float) : défaut = **2.5**  (0,30)
* **`Rounding` ($15)** (float) : défaut = **0.5**  (0,1)
* **`Amplitude` ($16)** (float) : défaut = **2**  (0,5)
* **`Interpolation` ($17)** (choice) : choix possibles => Nearest, Bilinear, Bicubic
* **`Boundary` ($18)** (choice) : choix possibles => None, Nearest, Periodic, Mirror
