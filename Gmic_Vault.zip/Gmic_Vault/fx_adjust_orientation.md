---
tags: [gmic, filter]
command: fx_adjust_orientation
---

# Filtre G'MIC : fx_adjust_orientation

## Structure de la commande
```text
fx_adjust_orientation:
    threshold = $1
```
## Définition des variables
* **`Threshold` ($1)** (float) : défaut = **5**  (0,100)
