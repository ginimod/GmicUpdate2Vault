---
tags: [gmic, filter]
command: fx_powertwirl
---

# Filtre G'MIC : fx_powertwirl

## Structure de la commande
```text
fx_powertwirl:
    amplitude = $1
    offset = $2
    center_x = $3
    center_y = $4
    power = $5
    boundary = $6
    mode = $7
```
## Définition des variables
* **`Amplitude` ($1)** (float) : défaut = **1**  (-20,20)
* **`Offset` ($2)** (float) : défaut = **0**  (-180,180)
* **`Center (%)` ($3)** (point) : position = 0,0
* **`Power` ($4)** (float) : défaut = **1**  (-20,20)
* **`Boundary` ($5)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
* **`Mode` ($6)** (choice) : choix possibles => Polar, Cartesian
