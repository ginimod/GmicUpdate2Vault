---
tags: [gmic, filter]
command: fx_random_rectangles
---

# Filtre G'MIC : fx_random_rectangles

## Structure de la commande
```text
fx_random_rectangles:
    density = $1
    consistency = $2
    outline_px = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Subdivide image as a set of random-sized colored rectangles. 
* **`Density (%)` ($1)** (float) : défaut = **10**  (0,100)
* **`Consistency (%)` ($2)** (float) : défaut = **100**  (0,100)
* **`Outline (px)` ($3)** (int) : défaut = **0**  (1,16)
* **`Outline Color` ($4)** (color) : défaut = 0,0,0
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2023/02/05.
