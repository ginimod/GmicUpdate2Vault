---
tags: [gmic, filter]
command: fx_custom_gradient
---

# Filtre G'MIC : fx_custom_gradient

## Structure de la commande
```text
fx_custom_gradient:
    select_by = $1
    smoothness = $2
    threshold = $3
    preview_shape = $4
    number_of_colors = $5
    cycles = $6
    offset = $7
    shading = $8
    inner_length = $9
    outer_length = $10
    spatial_metric = $11
    color_metric = $12
    shade_back_to_first_color = $13
    preview_gradient = $14
    colormap_type = $16
    predefined_colormap = $17
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a gradient conforming to an input shape. 
(Note) : Shape selection:
* **`Select By` ($1)** (choice) : choix possibles => Auto, Dark Pixels, Bright Pixels, Opaque Pixels
* **`Smoothness` ($2)** (float) : défaut = **0**  (0,10)
* **`Threshold` ($3)** (float) : défaut = **0**  (0,100)
* **`Preview Shape` ($4)** (bool) : par défaut = Faux (0)
(Note) : Note: Shapes with small strokes may lead to incorrect previews.
(Note) : Gradient parameters:
* **`Number of Colors` ($5)** (int) : défaut = **4**  (2,10)
* **`Cycles` ($6)** (float) : défaut = **1**  (1,16)
* **`Offset` ($7)** (float) : défaut = **0**  (0,100)
* **`Shading` ($8)** (float) : défaut = **128**  (1,256)
* **`Inner Length` ($9)** (float) : défaut = **100**  (0,100)
* **`Outer Length` ($10)** (float) : défaut = **100**  (0,100)
* **`Spatial Metric` ($11)** (choice) : choix possibles => Chebyshev, Manhattan, Euclidean
* **`Color Metric` ($12)** (choice) : choix possibles => RGB, HSV, Lab
* **`Shade Back to First Color` ($13)** (bool) : par défaut = Faux (0)
* **`Preview Gradient` ($14)** (bool) : par défaut = Faux (0)
(Note) : Color definitions:
* **`Colormap Type` ($15)** (choice) : choix possibles => Predefined, User-Defined
* **`Predefined Colormap` ($16)** (int) : défaut = **0**  (0,65535)
* **`1st Color` ($17)** (color) : défaut = 0,0,0,255
* **`2nd Color` ($18)** (color) : défaut = 255,0,0,255
* **`3rd Color` ($19)** (color) : défaut = 255,255,0,255
* **`4th Color` ($20)** (color) : défaut = 255,255,255,255
* **`5th Color` ($21)** (color) : défaut = 0,255,255,255
* **`6th Color` ($22)** (color) : défaut = 0,255,0,255
* **`7th Color` ($23)** (color) : défaut = 0,0,255,255
* **`8th Color` ($24)** (color) : défaut = 128,128,128,255
* **`9th Color` ($25)** (color) : défaut = 255,0,255,255
* **`10th Color` ($26)** (color) : défaut = 0,0,0,0
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2013/10/03.
