---
tags: [gmic, filter]
command: fx_pen_drawing
---

# Filtre G'MIC : fx_pen_drawing

## Structure de la commande
```text
fx_pen_drawing:
    amplitude = $1
```
## Définition des variables
* **`Amplitude` ($1)** (float) : défaut = **10**  (0,30)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/29/12.
