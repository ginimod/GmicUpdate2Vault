---
tags: [gmic, filter]
command: fx_bitplane8
---

# Filtre G'MIC : fx_bitplane8

## Structure de la commande
```text
fx_bitplane8:
    mode = $1
    split_mode = $2
    value_mode = $3
    alpha = $4
```
## Définition des variables
* **`Mode` ($1)** (choice) : choix possibles => Decompose, Recompose
* **`Split Mode` ($2)** (choice) : choix possibles => Z Layers, Separate Images
* **`Value Mode` ($3)** (choice) : choix possibles => Real, 1, 255
* **`Alpha` ($4)** (bool) : par défaut = Faux (0)
