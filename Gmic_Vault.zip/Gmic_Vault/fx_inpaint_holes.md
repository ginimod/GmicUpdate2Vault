---
tags: [gmic, filter]
command: fx_inpaint_holes
---

# Filtre G'MIC : fx_inpaint_holes

## Structure de la commande
```text
fx_inpaint_holes:
    maximal_area = $1
    tolerance = $2
    connectivity = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Fills transparent holes using surrounding content. 
* **`Maximal Area` ($1)** (float) : défaut = **4**  (1,512)
* **`Tolerance` ($2)** (float) : défaut = **20**  (0,255)
* **`Connectivity` ($3)** (choice) : choix possibles => Low, High
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2014/05/27.
