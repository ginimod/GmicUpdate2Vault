---
tags: [gmic, filter]
command: fx_barnsley_fern
---

# Filtre G'MIC : fx_barnsley_fern

## Structure de la commande
```text
fx_barnsley_fern:
    type = $1
    density = $2
    angle = $3
    opacity = $4
    add_as_a_new_layer = $9
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Renders a Barnsley Fern fractal. 
* **`Type` ($1)** (choice) : choix possibles => Asplenium Adiantum-Nigrum, Thelypteridaceae
* **`Density (%)` ($2)** (float) : défaut = **100**  (0,300)
* **`Angle` ($3)** (float) : défaut = **30**  (-180,180)
* **`Opacity (%)` ($4)** (float) : défaut = **40**  (0,100)
* **`Color` ($5)** (color) : défaut = 10,178,0,255
* **`Add as a New Layer` ($6)** (bool) : par défaut = Faux (0)
(Note) : This filter renders the Barnsley fern fractal, described here:
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/10/18.
