---
tags: [gmic, filter]
command: fx_make_seamless
---

# Filtre G'MIC : fx_make_seamless

## Structure de la commande
```text
fx_make_seamless:
    equalize_light = $1
    preview_original = $2
    tiled_preview = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Makes the image tileable using a diffusion method. 
* **`Equalize Light` ($1)** (float) : défaut = **0**  (0,100)
* **`Preview Original` ($2)** (bool) : par défaut = Faux (0)
* **`Tiled Preview` ($3)** (choice) : choix possibles => None, 2x1, 1x2, 2x2, 3x3, 4x4
(Note) : Note: This filter helps in converting your input pattern as a seamless (i.e. periodic) texture.
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/02/24.
