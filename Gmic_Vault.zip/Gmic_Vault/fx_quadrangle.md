---
tags: [gmic, filter]
command: fx_quadrangle
---

# Filtre G'MIC : fx_quadrangle

## Structure de la commande
```text
fx_quadrangle:
    top_left_vertex_x = $1
    top_left_vertex_y = $2
    top_right_vertex_x = $3
    top_right_vertex_y = $4
    bottom_right_vertex_x = $5
    bottom_right_vertex_y = $6
    bottom_left_vertex_x = $7
    bottom_left_vertex_y = $8
    interpolation = $9
    boundary = $10
    preview_type = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Remaps the image into a defined quadrangle region. 
* **`Top-Left Vertex (%)` ($1)** (point) : position = 0,0
* **`Top-Right Vertex (%)` ($2)** (point) : position = 0,0
* **`Bottom-Right Vertex (%)` ($3)** (point) : position = 0,0
* **`Bottom-Left Vertex (%)` ($4)** (point) : position = 0,0
* **`Interpolation` ($5)** (choice) : choix possibles => Nearest Neighbor, Linear
* **`Boundary` ($6)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
* **`Preview Type` ($7)** (choice) : choix possibles => Input, Output, Both
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2017/10/11.
