---
tags: [gmic, filter]
command: fx_boost_chroma
---

# Filtre G'MIC : fx_boost_chroma

## Structure de la commande
```text
fx_boost_chroma:
    amplitude = $1
    color_space = $2
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Increases or decreases the intensity of colors without affecting luminance. 
* **`Amplitude (%)` ($1)** (float) : défaut = **50**  (0,100)
* **`Color Space` ($2)** (choice) : choix possibles => YCbCr (Distinct), YCbCr (Mixed), Lab (Distinct), Lab (Mixed)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/07/19.
