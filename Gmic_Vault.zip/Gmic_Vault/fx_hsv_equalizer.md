---
tags: [gmic, filter]
command: fx_hsv_equalizer
---

# Filtre G'MIC : fx_hsv_equalizer

## Structure de la commande
```text
fx_hsv_equalizer:
    preview_bands = $1
    hue_band = $2
    band_width = $3
    hue_shift = $4
    saturation_correction = $5
    value_correction = $6
    hue_band = $7
    band_width = $8
    hue_shift = $9
    saturation_correction = $10
    value_correction = $11
    hue_band = $12
    band_width = $13
    hue_shift = $14
    saturation_correction = $15
    value_correction = $16
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Equalizes the Hue, Saturation, or Value channels. 
* **`Preview Bands` ($1)** (bool) : par défaut = Faux (0)
* **`Hue Band` ($2)** (float) : défaut = **180**  (0,360)
* **`Band Width` ($3)** (float) : défaut = **40**  (1,360)
* **`Hue Shift` ($4)** (float) : défaut = **0**  (-180,180)
* **`Saturation Correction` ($5)** (float) : défaut = **0**  (-0.99,0.99)
* **`Value Correction` ($6)** (float) : défaut = **0**  (-0.99,0.99)
* **`Hue Band` ($7)** (float) : défaut = **180**  (0,360)
* **`Band Width` ($8)** (float) : défaut = **40**  (1,360)
* **`Hue Shift` ($9)** (float) : défaut = **0**  (-180,180)
* **`Saturation Correction` ($10)** (float) : défaut = **0**  (-0.99,0.99)
* **`Value Correction` ($11)** (float) : défaut = **0**  (-0.99,0.99)
* **`Hue Band` ($12)** (float) : défaut = **180**  (0,360)
* **`Band Width` ($13)** (float) : défaut = **40**  (1,360)
* **`Hue Shift` ($14)** (float) : défaut = **0**  (-180,180)
* **`Saturation Correction` ($15)** (float) : défaut = **0**  (-0.99,0.99)
* **`Value Correction` ($16)** (float) : défaut = **0**  (-0.99,0.99)
(Note) : Author: Jérome Ferrari.       Latest Update: 01/14/2011.
