---
tags: [gmic, filter]
command: cl_lineart
---

# Filtre G'MIC : cl_lineart

## Structure de la commande
```text
cl_lineart:
    local_contrast_enhancement = $1
    simplification = $2
    flattening_for_edge_bilateral = $3
    line_thickness = $4
    line_strength = $5
    lines_antialias = $6
    add_black_or_gray = $7
    luminosity_increase = $8
    final_flattening_bilateral = $9
    type = $10
    final_antialias = $11
    pen_drawing = $12
    effect = $13
    preview_type = $14
    preview_split_x = $15
    preview_split_y = $16
```
## Définition des variables
(Note) : Photo to Line Art
(Note) :  
* **`Local Contrast Enhancement` ($1)** (int) : défaut = **0**  (0,4)
* **`Simplification` ($2)** (bool) : par défaut = Faux (0)
(Note) : For edges:
* **`Flattening for Edge (bilateral)` ($3)** (int) : défaut = **2**  (0,5)
* **`Line Thickness` ($4)** (float) : défaut = **1**  (0.5,2)
* **`Line Strength` ($5)** (float) : défaut = **15**  (0,19)
* **`Lines Antialias` ($6)** (int) : défaut = **15**  (0,100)
* **`Add Black or Gray` ($7)** (bool) : par défaut = Faux (0)
(Note) : For black and grays:
* **`Luminosity Increase` ($8)** (int) : défaut = **0**  (0,40)
* **`Final Flattening (bilateral)` ($9)** (int) : défaut = **6**  (0,10)
* **`Type` ($10)** (choice) : choix possibles => Soft Threshold, Gray Patches, Lines and Black, Black and Lines
* **`Final Antialias` ($11)** (choice) : choix possibles => None, Light Simple, Simple, Very Strong
* **`Pen Drawing` ($12)** (choice) : choix possibles => None, Simple, Undoing Patterns
* **`Effect` ($13)** (choice) : choix possibles => None, Charcoal, Groove
* **`Preview Type` ($14)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($15)** (point) : position = 0,0
(Note) : Author: Claude Lion.      Latest Update: 2022/05/10.
(Note) : It uses filters of David Tschumperlé and a few filters of Jérôme Boulanger.
(Note) : Type='Lines and Black' is a shortcut of 'Black and Lines' with 'Local Contrast Enhancement = 1' and 'Luminosity Increase = 40'. In this case, 'Local Contrast Enhancement' and 'Luminosity Increase' cursors have no effect.
