---
tags: [gmic, filter]
command: fx_DemoVecRot
---

# Filtre G'MIC : fx_DemoVecRot

## Structure de la commande
```text
fx_DemoVecRot:
    angle_shift = $1
```
## Définition des variables
(Note) : Vector field rotation and quiver sample
* **`Angle Shift` ($1)** (float) : défaut = **0**  (-180,180)
(Note) : Author : Arto Huotari with help from David Tschumperlé.     Latest update : 2012/02/25.
