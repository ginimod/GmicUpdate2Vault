---
tags: [gmic, filter]
command: fx_equation_parametric
---

# Filtre G'MIC : fx_equation_parametric

## Structure de la commande
```text
fx_equation_parametric:
    min_t = $3
    max_t = $4
    resolution = $5
    outline_opacity = $6
    dot_size = $7
    colored_outline = $14
    antialiasing = $15
    decoration = $16
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Plots a parametric curve. 
* **`Min-T` ($1)** (float) : défaut = **0**  (-1000,1000)
* **`Max-T` ($2)** (float) : défaut = **100**  (-1000,1000)
* **`Resolution` ($3)** (int) : défaut = **4096**  (2,32768)
* **`Outline Opacity` ($4)** (float) : défaut = **1**  (0,1)
* **`Dot Size` ($5)** (int) : défaut = **0**  (0,16)
* **`Start Color` ($6)** (color) : défaut = 64,0,0
* **`End Color` ($7)** (color) : défaut = 128,0,0
* **`Colored Outline` ($8)** (bool) : par défaut = Faux (0)
* **`Antialiasing` ($9)** (bool) : par défaut = Faux (0)
* **`Decoration` ($10)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2013/11/13.
