---
tags: [gmic, filter]
command: fx_lava
---

# Filtre G'MIC : fx_lava

## Structure de la commande
```text
fx_lava:
    perturbation = $1
    smoothness = $2
    scale = $3
    sharpness = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a fluid, lava-like pattern. 
* **`Perturbation` ($1)** (int) : défaut = **8**  (0,15)
* **`Smoothness` ($2)** (float) : défaut = **5**  (0,100)
* **`Scale` ($3)** (float) : défaut = **3**  (0,20)
* **`Sharpness` ($4)** (float) : défaut = **0**  (0,1000)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2012/11/26.
