---
tags: [gmic, filter]
command: fx_edges
---

# Filtre G'MIC : fx_edges

## Structure de la commande
```text
fx_edges:
    smoothness = $1
    threshold = $2
    negative_colors = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generic edge detection filter. 
* **`Smoothness` ($1)** (float) : défaut = **0**  (0,10)
* **`Threshold` ($2)** (float) : défaut = **15**  (0,50)
* **`Negative Colors` ($3)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
