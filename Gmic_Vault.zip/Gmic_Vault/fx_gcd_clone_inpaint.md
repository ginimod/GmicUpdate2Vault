---
tags: [gmic, filter]
command: fx_gcd_clone_inpaint
---

# Filtre G'MIC : fx_gcd_clone_inpaint

## Structure de la commande
```text
fx_gcd_clone_inpaint:
    type = $1
    bias = $2
    scale = $3
    blend_to_boundary = $4
```
## Définition des variables
(Note) : Simple proximity cloning inpaint for object removal
* **`Type` ($1)** (choice) : choix possibles => Horizontal, Vertical
* **`Bias` ($2)** (choice) : choix possibles => Left/Top, None, Right/Bottom
* **`Scale` ($3)** (float) : défaut = **10**  (1,100)
* **`Blend to Boundary` ($4)** (bool) : par défaut = Faux (0)
(Note) : Author : Garagecoder.      Latest update : 2022/08/08.
(Note) : 
<u>Notes</u>
(Note) : Transparent regions will be inpainted
(Note) : This filter is not automatic: adjust scale as required
(Note) : For best results, inpaint a single region with a simple shape
