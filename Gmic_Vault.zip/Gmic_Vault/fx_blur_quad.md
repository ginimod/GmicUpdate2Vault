---
tags: [gmic, filter]
command: fx_blur_quad
---

# Filtre G'MIC : fx_blur_quad

## Structure de la commande
```text
fx_blur_quad:
    1st_amplitude = $1
    2nd_amplitude = $2
    brightness = $3
    contrast = $4
    gamma = $5
    mode = $6
    opacity = $7
    p0_x = $8
    p0_y = $9
    p1_x = $10
    p1_y = $11
    p2_x = $12
    p2_y = $13
    p3_x = $14
    p3_y = $15
```
## Définition des variables
(Note) : Blur parameters:
* **`1st Amplitude (%)` ($1)** (float) : défaut = **0**  (0,100)
* **`2nd Amplitude (%)` ($2)** (float) : défaut = **5**  (0,100)
* **`Brightness (%)` ($3)** (float) : défaut = **0**  (-100,100)
* **`Contrast (%)` ($4)** (float) : défaut = **0**  (-100,100)
* **`Gamma (%)` ($5)** (float) : défaut = **0**  (-100,100)
* **`Mode` ($6)** (choice) : choix possibles => Add, Alpha, And, Average, Blue, Burn, Darken, Difference, Divide, Dodge, Edges, Exclusion, Freeze, Grain Extract, Grain Merge, Green, Hard Light, Hard Mix, Hue, Interpolation, Lighten, Lightness, Linear Burn, Linear Light, Luminance, Multiply, Negation, Or, Overlay, Pin Light, Red, Reflect, Saturation, Soft Burn, Soft Dodge, Soft Light, Screen, Stamp, Subtract, Value, Vivid Light, Xor
* **`Opacity (%)` ($7)** (float) : défaut = **100**  (0,100)
(Note) : Quad coordinates:
* **`P0` ($8)** (point) : position = 0,0
* **`P1` ($9)** (point) : position = 0,0
* **`P2` ($10)** (point) : position = 0,0
* **`P3` ($11)** (point) : position = 0,0
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2021/01/18.
