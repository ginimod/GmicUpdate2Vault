---
tags: [gmic, filter]
command: fx_crt_phosphors
---

# Filtre G'MIC : fx_crt_phosphors

## Structure de la commande
```text
fx_crt_phosphors:
    phosphor_type = $1
    upscale_factor = $2
    rendering_precision = $3
    smoothness = $4
    neighborhood_size_px = $5
    stride = $6
    adaptive_pattern = $7
    use_luma_for_adaptive_pattern = $8
    transpose_pattern = $9
    average_over_pattern = $10
    normalize_image = $11
    preview_type = $12
    preview_split_x = $13
    preview_split_y = $14
    preview_zoom = $15
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates the phosphor triad pattern of a CRT screen. 
* **`Phosphor Type` ($1)** (choice) : choix possibles => Phosphor-1, Phosphor-2, Phosphor-3
* **`Upscale Factor` ($2)** (choice) : choix possibles => X1, X2, X3, X4, X5, X6, X7, X8
* **`Rendering Precision` ($3)** (choice) : choix possibles => Low (Faster), High (Slower)
* **`Smoothness (%)` ($4)** (float) : défaut = **0**  (0,10)
* **`Neighborhood Size (px)` ($5)** (int) : défaut = **4**  (1,16)
* **`Stride (%)` ($6)** (float) : défaut = **50**  (0,100)
* **`Adaptive Pattern` ($7)** (bool) : par défaut = Faux (0)
* **`Use Luma for Adaptive Pattern` ($8)** (bool) : par défaut = Faux (0)
* **`Transpose Pattern` ($9)** (bool) : par défaut = Faux (0)
* **`Average Over Pattern` ($10)** (bool) : par défaut = Faux (0)
* **`Normalize Image` ($11)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($12)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($13)** (point) : position = 0,0
* **`Preview Zoom (%)` ($14)** (float) : défaut = **0**  (0,100)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2023/12/26.
