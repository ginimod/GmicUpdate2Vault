---
tags: [gmic, filter]
command: fx_frame
---

# Filtre G'MIC : fx_frame

## Structure de la commande
```text
fx_frame:
    x_start = $1
    x_end = $2
    y_start = $3
    y_end = $4
    width = $5
    height = $6
    outline_size = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds a simple solid color frame. 
(Note) : Crop parameters :
* **`X-Start (%)` ($1)** (int) : défaut = **0**  (0,100)
* **`X-End (%)` ($2)** (int) : défaut = **100**  (0,100)
* **`Y-Start (%)` ($3)** (int) : défaut = **0**  (0,100)
* **`Y-End (%)` ($4)** (int) : défaut = **100**  (0,100)
(Note) : Frame parameters :
* **`Width (%)` ($5)** (int) : défaut = **10**  (0,100)
* **`Height (%)` ($6)** (int) : défaut = **10**  (0,100)
* **`Color` ($7)** (color) : défaut = 0,0,0,255
* **`Outline Size` ($8)** (int) : défaut = **1**  (0,100)
* **`Outline Color` ($9)** (color) : défaut = 255,255,255,255
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
