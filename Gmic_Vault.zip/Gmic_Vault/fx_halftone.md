---
tags: [gmic, filter]
command: fx_halftone
---

# Filtre G'MIC : fx_halftone

## Structure de la commande
```text
fx_halftone:
    brightness = $1
    contrast = $2
    gamma = $3
    smoothness = $4
    number_of_tones = $5
    size_for_dark_tones = $6
    size_for_bright_tones = $7
    shape = $8
    smoothness = $9
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates a printing halftone pattern (dots). 
(Note) : Image parameters :
* **`Brightness (%)` ($1)** (float) : défaut = **0**  (-100,100)
* **`Contrast (%)` ($2)** (float) : défaut = **0**  (-100,100)
* **`Gamma (%)` ($3)** (float) : défaut = **0**  (-100,100)
* **`Smoothness` ($4)** (float) : défaut = **0**  (0,10)
(Note) : Halftone parameters :
* **`Number of Tones` ($5)** (int) : défaut = **5**  (2,32)
* **`Size for Dark Tones` ($6)** (int) : défaut = **8**  (2,256)
* **`Size for Bright Tones` ($7)** (int) : défaut = **8**  (2,256)
* **`Shape` ($8)** (choice) : choix possibles => Square, Diamond, Circle, Square (Inv.), Diamond (Inv.), Circle (Inv.)
* **`Smoothness` ($9)** (float) : défaut = **0.1**  (0,32)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2012/07/23.
