---
tags: [gmic, filter]
command: fx_color_ellipses
---

# Filtre G'MIC : fx_color_ellipses

## Structure de la commande
```text
fx_color_ellipses:
    density = $1
    radius = $2
    opacity = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Draws random colored ellipses over the image. 
* **`Density` ($1)** (int) : défaut = **400**  (0,3000)
* **`Radius` ($2)** (float) : défaut = **8**  (0,30)
* **`Opacity` ($3)** (float) : défaut = **0.1**  (0.01,0.5)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
