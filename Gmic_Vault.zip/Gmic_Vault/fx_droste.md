---
tags: [gmic, filter]
command: fx_droste
---

# Filtre G'MIC : fx_droste

## Structure de la commande
```text
fx_droste:
    point_0_x = $1
    point_0_y = $2
    point_1_x = $3
    point_1_y = $4
    point_2_x = $5
    point_2_y = $6
    point_3_x = $7
    point_3_y = $8
    iterations = $9
    x_shift = $10
    y_shift = $11
    angle = $12
    zoom = $13
    mirror = $14
    boundary = $15
    drawing_mode = $16
    view_outlines_only = $17
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Creates a recursive "picture within a picture" effect. 
(Note) : <span color="red">Upper-left coordinates :</span>
* **`Point #0` ($1)** (point) : position = 0,0
(Note) : <span color="magenta">Upper-right coordinates :</span>
* **`Point #1` ($2)** (point) : position = 0,0
(Note) : <span color="blue">Lower-right coordinates :</span>
* **`Point #2` ($3)** (point) : position = 0,0
(Note) : <span color="cyan">Lower-left coordinates :</span>
* **`Point #3` ($4)** (point) : position = 0,0
* **`Iterations` ($5)** (int) : défaut = **1**  (1,10)
* **`X-Shift` ($6)** (float) : défaut = **0**  (-100,100)
* **`Y-Shift` ($7)** (float) : défaut = **0**  (-100,100)
* **`Angle` ($8)** (float) : défaut = **0**  (0,360)
* **`Zoom` ($9)** (float) : défaut = **1**  (0.1,5)
* **`Mirror` ($10)** (choice) : choix possibles => None, X-Axis, Y-Axis, XY-Axes
* **`Boundary` ($11)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
* **`Drawing Mode` ($12)** (choice) : choix possibles => Replace, Replace (Sharpest), Behind, Below
* **`View Outlines Only` ($13)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2012/06/11.
