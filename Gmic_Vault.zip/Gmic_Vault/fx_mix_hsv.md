---
tags: [gmic, filter]
command: fx_mix_hsv
---

# Filtre G'MIC : fx_mix_hsv

## Structure de la commande
```text
fx_mix_hsv:
    hue_factor = $1
    hue_shift = $2
    hue_smoothness = $3
    saturation_factor = $4
    saturation_shift = $5
    saturation_smoothness = $6
    value_factor = $7
    value_shift = $8
    value_smoothness = $9
    tones_range = $10
    tones_smoothness = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Mixes channels using the HSV color model. 
* **`Hue Factor` ($1)** (float) : défaut = **1**  (0,4)
* **`Hue Shift` ($2)** (float) : défaut = **0**  (-180,180)
* **`Hue Smoothness` ($3)** (float) : défaut = **0**  (0,10)
* **`Saturation Factor` ($4)** (float) : défaut = **1**  (0,4)
* **`Saturation Shift` ($5)** (float) : défaut = **0**  (-1,1)
* **`Saturation Smoothness` ($6)** (float) : défaut = **0**  (0,10)
* **`Value Factor` ($7)** (float) : défaut = **1**  (0,4)
* **`Value Shift` ($8)** (float) : défaut = **0**  (-1,1)
* **`Value Smoothness` ($9)** (float) : défaut = **0**  (0,10)
* **`Tones Range` ($10)** (choice) : choix possibles => All Tones, Shadows, Mid-Tones, Highlights
* **`Tones Smoothness` ($11)** (float) : défaut = **2**  (0,10)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/06/20.
