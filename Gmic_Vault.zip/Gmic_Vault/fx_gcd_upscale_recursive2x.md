---
tags: [gmic, filter]
command: fx_gcd_upscale_recursive2x
---

# Filtre G'MIC : fx_gcd_upscale_recursive2x

## Structure de la commande
```text
fx_gcd_upscale_recursive2x:
    kernel = $1
    sharpness = $2
    grain = $3
```
## Définition des variables
(Note) : <u>Self similarity 2x upscale</u>
(Note) : 
Quality Options
* **`Kernel` ($1)** (int) : défaut = **4**  (0,10)
(Note) : 
Processing Options
* **`Sharpness` ($2)** (float) : défaut = **0.05**  (0,0.4)
* **`Grain` ($3)** (float) : défaut = **0.01**  (0,0.1)
(Note) : Author : Garagecoder.      Latest update : 2023/02/14.
(Note) : 
<u>Notes</u>
(Note) : Preview is fixed to lowest quality kernel.
(Note) : Kernel size zero will use randomized matching.
(Note) : Due to the algorithm some glitches are expected.
(Note) : 
Warning: large kernels are slow to compute.
(Note) : Image size also affects computation time significantly.
