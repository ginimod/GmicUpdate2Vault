---
tags: [gmic, filter]
command: Cercles_Concentriques_A
---

# Filtre G'MIC : Cercles_Concentriques_A

## Structure de la commande
```text
Cercles_Concentriques_A:
    dimension_en_pixels = $1
    supprimer_calque_delete_layer = $2
    nb_cercles_circles_anneaux = $3
    variation_dimensions_size = $4
    angle_variation_origine = $5
    angle_variation_fin_end = $6
    coef_variation = $7
    rotation_horaire_rotate_clockwise = $8
    decalage_cercles_shift = $9
    conserver_exterieur_keep_outside = $10
    activer_rayons_de_couleurs_enable = $11
    affichage_display_contours = $16
    dilate_contours = $17
    flou_blur_contours = $18
    sharpen = $19
    repetition_des_couleurs = $20
    angle_decalage_des_couleurs = $21
    couleurs_aleatoires_random_colors = $42
    melange_couleurs_contours_blend = $43
    activer_symmetrizoscope = $44
    iterations = $45
    angle = $46
    symmetry_sides = $47
```
## Définition des variables
(Note) : <span foreground="orangered">Image Finale / Resulting Image</span>
* **`Dimension En Pixels` ($1)** (int) : défaut = **800**  (256,1920)
* **`Supprimer Calque / Delete Layer` ($2)** (bool) : par défaut = Faux (0)
(Note) : <span foreground="orangered">Cercles / Circles Rings</span>
* **`Nb Cercles / Circles (anneaux)` ($3)** (int) : défaut = **6**  (1,180)
* **`Variation Dimensions / Size` ($4)** (choice) : choix possibles => Sin A, Sin B, Lineaire
* **`Angle Variation Origine` ($5)** (float) : défaut = **0**  (0,180)
* **`Angle Variation Fin / End` ($6)** (float) : défaut = **90**  (0,180)
* **`Coef. Variation` ($7)** (float) : défaut = **1**  (-1,1)
* **`Rotation Horaire / Rotate Clockwise` ($8)** (bool) : par défaut = Faux (0)
* **`Décalage Cercles % / Shift` ($9)** (float) : défaut = **50**  (0,500)
* **`Conserver Extérieur / Keep Outside` ($10)** (bool) : par défaut = Faux (0)
(Note) : <span foreground="orangered">Rayons De Couleurs Et Contours / Colored Rays And Contours</span>
* **`Activer Rayons De Couleurs / Enable` ($11)** (bool) : par défaut = Faux (0)
(Note) : <span foreground="blue"> - Contours - </span>
* **`Contours` ($12)** (color) : défaut = 0,0,0,255
* **`Affichage / Display Contours` ($13)** (choice) : choix possibles => Sans, Rayons Et Cercles, Rayons, Cercles
* **`Dilate Contours` ($14)** (int) : défaut = **0**  (0,16)
* **`Flou / Blur Contours` ($15)** (float) : défaut = **0**  (0,5)
* **`Sharpen` ($16)** (int) : défaut = **0**  (0,600)
(Note) : <span foreground="blue"> - Couleurs - </span>
* **`Répétition Des Couleurs` ($17)** (int) : défaut = **5**  (1,180)
* **`Angle Décalage Des Couleurs` ($18)** (float) : défaut = **0**  (0,360)
* **`Couleur / Color A` ($19)** (color) : défaut = 0,0,255,255
* **`Couleur / Color B` ($20)** (color) : défaut = 255,255,0,255
* **`Couleur / Color C` ($21)** (color) : défaut = 255,0,0,255
* **`Couleur / Color D` ($22)** (color) : défaut = 0,255,255,255
* **`Couleur / Color E` ($23)** (color) : défaut = 255,0,255,255
* **`Couleurs Aléatoires / Random Colors` ($24)** (bool) : par défaut = Faux (0)
* **`Mélange Couleurs Contours / Blend` ($25)** (bool) : par défaut = Faux (0)
(Note) : <span foreground="orangered">Symmetrizoscope</span>
* **`Activer Symmetrizoscope` ($26)** (bool) : par défaut = Faux (0)
* **`Itérations` ($27)** (int) : défaut = **5**  (1,32)
* **`Angle` ($28)** (float) : défaut = **0**  (0,360)
* **`Symmetry Sides` ($29)** (choice) : choix possibles => Backward, Forward, Swap
(Note) : samj - Dernière mise à jour : 2020/10/24.
