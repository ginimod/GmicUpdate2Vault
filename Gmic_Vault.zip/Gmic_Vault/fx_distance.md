---
tags: [gmic, filter]
command: fx_distance
---

# Filtre G'MIC : fx_distance

## Structure de la commande
```text
fx_distance:
    value = $1
    metric = $2
    normalization = $3
    modulo_value = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Computes the distance of each pixel to the nearest edge. 
* **`Value` ($1)** (int) : défaut = **128**  (0,255)
* **`Metric` ($2)** (choice) : choix possibles => Chebyshev, Manhattan, Euclidean, Squared-Euclidean
* **`Normalization` ($3)** (choice) : choix possibles => Cut, Normalize, Modulo
* **`Modulo Value` ($4)** (int) : défaut = **32**  (1,255)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2011/07/04.
