---
tags: [gmic, filter]
command: fx_blend_bomb
---

# Filtre G'MIC : fx_blend_bomb

## Structure de la commande
```text
fx_blend_bomb:
    process_as = $2
    mesh_x = $3
    mesh_y = $4
    mesh_smoothness = $5
    contrast_scheme = $6
    mesh_contrast = $7
    reverse_blending_layers = $8
    dimensions = $9
    alpha = $10
    normalise = $11
    output_mesh = $12
```
## Définition des variables
(Note) : Creates a random transfer function 'mesh' and then blends images accordingly. Based on method shown <a href="https://discuss.pixls.us/t/im-generating-new-blending-modes-for-krita/8104/16">on discuss.pixls.us</a>.
* **`Process As` ($1)** (choice) : choix possibles => Two-By-Two, Self-Blend for Each Layer
* **`Mesh X` ($2)** (int) : défaut = **16**  (1,256)
* **`Mesh Y` ($3)** (int) : défaut = **16**  (1,256)
* **`Mesh Smoothness` ($4)** (float) : défaut = **2**  (0,10)
* **`Contrast Scheme` ($5)** (choice) : choix possibles => Arctan, Clip, Power
* **`Mesh Contrast` ($6)** (float) : défaut = **50**  (0,100)
* **`Reverse Blending Layers` ($7)** (bool) : par défaut = Faux (0)
* **`Dimensions` ($8)** (choice) : choix possibles => Bottom Layer, Top Layer
* **`Alpha` ($9)** (bool) : par défaut = Faux (0)
* **`Normalise` ($10)** (bool) : par défaut = Faux (0)
* **`Output Mesh` ($11)** (bool) : par défaut = Faux (0)
