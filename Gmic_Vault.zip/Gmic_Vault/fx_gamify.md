---
tags: [gmic, filter]
command: fx_gamify
---

# Filtre G'MIC : fx_gamify

## Structure de la commande
```text
fx_gamify:
    lightness = $1
    chroma = $2
    normalize = $3
    contrast = $4
    preview_type = $5
```
## Définition des variables
* **`Lightness` ($1)** (int) : défaut = **50**  (50,60)
* **`Chroma` ($2)** (float) : défaut = **2**  (1.1,5)
* **`Normalize` ($3)** (bool) : par défaut = Faux (0)
* **`Contrast` ($4)** (float) : défaut = **1**  (1,1.5)
* **`Preview Type` ($5)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Filter by afre. Latest update: 2017-01-05.
