---
tags: [gmic, filter]
command: fx_bwrecolorize
---

# Filtre G'MIC : fx_bwrecolorize

## Structure de la commande
```text
fx_bwrecolorize:
    brightness = $1
    contrast = $2
    gamma = $3
    normalize_input = $4
    gradient_preset = $5
    interpolation_type = $6
    preserve_initial_brightness = $7
    number_of_tones = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Remaps the grayscale values of the image to a specific color map. 
* **`Brightness (%)` ($1)** (float) : défaut = **0**  (-100,100)
* **`Contrast (%)` ($2)** (float) : défaut = **0**  (-100,100)
* **`Gamma (%)` ($3)** (float) : défaut = **0**  (-100,100)
* **`Normalize Input` ($4)** (bool) : par défaut = Faux (0)
* **`Gradient Preset` ($5)** (choice) : choix possibles => User-Defined, Black to White, White to Black, Sepia, Solarize
* **`Interpolation Type` ($6)** (choice) : choix possibles => Nearest, Linear, Cubic, Lanczos
* **`Preserve Initial Brightness` ($7)** (bool) : par défaut = Faux (0)
(Note) : <u>User-defined gradient :</u>
* **`Number of Tones` ($8)** (int) : défaut = **5**  (2,8)
* **`1st Tone` ($9)** (color) : défaut = 0,0,0,255
* **`2nd Tone` ($10)** (color) : défaut = 43,25,55,255
* **`3rd Tone` ($11)** (color) : défaut = 158,137,189,255
* **`4th Tone` ($12)** (color) : défaut = 224,191,228,255
* **`5th Tone` ($13)** (color) : défaut = 255,255,255,255
* **`6th Tone` ($14)** (color) : défaut = 255,255,255,255
* **`7th Tone` ($15)** (color) : défaut = 255,255,255,255
* **`8th Tone` ($16)** (color) : défaut = 255,255,255,255
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
