---
tags: [gmic, filter]
command: csswap
---

# Filtre G'MIC : csswap

## Structure de la commande
```text
csswap:
    to_rgb_from = $1
    from_rgb_to = $2
    preview_type = $3
    preview_split_x = $4
    preview_split_y = $5
```
## Définition des variables
* **`To RGB From` ($1)** (choice) : choix possibles => RGB, SRGB, CMY, RYB, Ohta8, Ohta, YES8, YES, Kodak1-8, Kodak1, Lab8, Lab, Oklab, LUV, Jzazbz, YIQ8, YIQ, YUV8, YUV, YCbCr, YCbCrGLIC, YCbCrJPEG, YDbDr, XYZ8, XYZ, HSV8, HSV, HSL8, HSL, HSI8, HSI, LCH8, LCH, JzCzHz, HCY
* **`From RGB To` ($2)** (choice) : choix possibles => RGB, SRGB, CMY, RYB, Ohta8, Ohta, YES8, YES, Kodak1-8, Kodak1, Lab8, Lab, Oklab, LUV, Jzazbz, YIQ8, YIQ, YUV8, YUV, YCbCr, YCbCrGLIC, YCbCrJPEG, YDbDr, XYZ8, XYZ, HSV8, HSV, HSL8, HSL, HSI8, HSI, LCH8, LCH, Jzczhz, HCY
* **`Preview Type` ($3)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($4)** (point) : position = 0,0
