---
tags: [gmic, filter]
command: conic_equidistant_projection
---

# Filtre G'MIC : conic_equidistant_projection

## Structure de la commande
```text
conic_equidistant_projection:
    roll = $1
    pitch = $2
    yaw = $3
    central_longitude = $4
    reference_parallel = $5
    standard_parallel_1 = $6
    standard_parallel_2 = $7
```
## Définition des variables
(Note) : Rotate an equirectangular map or panorama around three axises in order and output it as a conic equidistant map. Neither equal-area or conformal.
* **`Roll` ($1)** (float) : défaut = **0**  (-360,360)
* **`Pitch` ($2)** (float) : défaut = **0**  (-360,360)
* **`Yaw` ($3)** (float) : défaut = **0**  (-360,360)
* **`Central Longitude` ($4)** (float) : défaut = **0**  (-180,180)
* **`Reference Parallel` ($5)** (float) : défaut = **0**  (-90,90)
* **`Standard Parallel #1` ($6)** (float) : défaut = **20**  (-90,90)
* **`Standard Parallel #2` ($7)** (float) : défaut = **60**  (-90,90)
(Note) : Author: <a href="https://www.cartographersguild.com/showthread.php?t=47591">Kristian Järventaus</a>.      Latest Update: 2024/03/05.
