---
tags: [gmic, filter]
command: fx_crt_scanlines
---

# Filtre G'MIC : fx_crt_scanlines

## Structure de la commande
```text
fx_crt_scanlines:
    upscale_factor = $1
    neighborhood_size = $2
    bloom_shape = $3
    bloom_threshold = $4
    use_luma_for_bloom = $5
    fuzz_shape = $6
    normalize_image = $7
    preview_type = $8
    preview_split_x = $9
    preview_split_y = $10
    preview_zoom = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds scanlines to mimic an old monitor. 
* **`Upscale Factor` ($1)** (int) : défaut = **4**  (1,16)
* **`Neighborhood Size` ($2)** (int) : défaut = **16**  (8,64)
* **`Bloom Shape` ($3)** (choice) : choix possibles => Square, Triangular, Sine, Gaussian
* **`Bloom Threshold` ($4)** (float) : défaut = **0**  (-1,1)
* **`Use Luma For Bloom` ($5)** (bool) : par défaut = Faux (0)
* **`Fuzz Shape` ($6)** (choice) : choix possibles => Square, Triangular, Sine, Gaussian
* **`Normalize Image` ($7)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($8)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($9)** (point) : position = 0,0
* **`Preview Zoom (%)` ($10)** (float) : défaut = **50**  (0,100)
(Note) : Authors: Romain Hérault and <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2024/01/10.
