---
tags: [gmic, filter]
command: fx_psyglass
---

# Filtre G'MIC : fx_psyglass

## Structure de la commande
```text
fx_psyglass:
    white_separators = $1
    edges = $2
    shading = $3
    thin_separators = $4
    equalize = $5
    layer_fx = $6
    opacity = $7
    apply_mask = $8
    raise_local_contrast = $9
    activate_mirrors = $10
    iterations = $11
    x_offset = $12
    y_offset = $13
    array_mode = $14
    initialization = $15
    expand_size = $16
    preview_type = $17
```
## Définition des variables
(Note) : Stained Glass controls
* **`White Separators` ($1)** (bool) : par défaut = Faux (0)
* **`Edges` ($2)** (float) : défaut = **20**  (0,100)
* **`Shading` ($3)** (float) : défaut = **0.1**  (0,0.5)
* **`Thin Separators` ($4)** (bool) : par défaut = Faux (0)
* **`Equalize` ($5)** (bool) : par défaut = Faux (0)
(Note) : To skip Layer Fx set Opacity to 0
* **`Layer Fx` ($6)** (choice) : choix possibles => Grain Merge, Hard Light, Soft Light, Overlay, Color Burn, Multiply
* **`Opacity` ($7)** (float) : défaut = **1**  (0,1)
(Note) : Quick Corrections and Special Fx
* **`Apply Mask` ($8)** (bool) : par défaut = Faux (0)
(Note) : Contrast Mask preset
* **`Raise Local Contrast` ($9)** (bool) : par défaut = Faux (0)
(Note) : Local Normalization preset
(Note) : Mirrors Controls
* **`Activate Mirrors` ($10)** (bool) : par défaut = Faux (0)
* **`Iterations` ($11)** (int) : défaut = **1**  (1,10)
* **`X-Offset` ($12)** (float) : défaut = **0**  (0,100)
* **`Y-Offset` ($13)** (float) : défaut = **0**  (0,100)
* **`Array Mode` ($14)** (choice) : choix possibles => X-Axis, Y-Axis, XY-Axes, 2XY-Axes
* **`Initialization` ($15)** (choice) : choix possibles => Original, Mirror X, Mirror Y, Rotate 90 Deg., Rotate 180 Deg., Rotate 270 Deg.
* **`Expand Size` ($16)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($17)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author: PhotoComiX. Latest update : 2011/30/03.
