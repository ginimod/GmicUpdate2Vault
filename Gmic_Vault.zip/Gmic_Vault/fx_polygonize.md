---
tags: [gmic, filter]
command: fx_polygonize
---

# Filtre G'MIC : fx_polygonize

## Structure de la commande
```text
fx_polygonize:
    amplitude = $1
    smoothness = $2
    minimal_area = $3
    x_resolution = $4
    y_resolution = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Approximates the image using polygonal shapes based on energy minimization. 
* **`Amplitude` ($1)** (int) : défaut = **300**  (0,2000)
* **`Smoothness` ($2)** (float) : défaut = **10**  (0,100)
* **`Minimal Area` ($3)** (float) : défaut = **10**  (0,100)
* **`X-Resolution` ($4)** (float) : défaut = **10**  (1,256)
* **`Y-Resolution` ($5)** (float) : défaut = **10**  (1,256)
* **`Outline Color` ($6)** (color) : défaut = 0,0,0,255
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2013/12/02.
