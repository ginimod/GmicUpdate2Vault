---
tags: [gmic, filter]
command: fx_poincare_disk
---

# Filtre G'MIC : fx_poincare_disk

## Structure de la commande
```text
fx_poincare_disk:
    p_value = $1
    q_value = $2
    size = $3
    iterations = $4
    angle_deg = $5
    tiling = $6
    antialiasing = $7
    filling = $8
    shift_x = $9
    shift_y = $10
    zoom = $11
    angle_deg = $12
    outline_px = $13
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Maps the image onto a Poincaré disk (hyperbolic geometry). 
* **`P-Value` ($1)** (int) : défaut = **5**  (3,16)
* **`Q-Value` ($2)** (int) : défaut = **6**  (3,32)
* **`Size (%)` ($3)** (float) : défaut = **100**  (0,200)
* **`Iterations` ($4)** (int) : défaut = **20**  (0,40)
* **`Angle (deg.)` ($5)** (float) : défaut = **0**  (-180,180)
* **`Tiling` ($6)** (choice) : choix possibles => Triangular, Polygonal
* **`Antialiasing` ($7)** (bool) : par défaut = Faux (0)
* **`Filling` ($8)** (choice) : choix possibles => Binary, Image
* **`Shift` ($9)** (point) : position = 0,0
* **`Zoom` ($10)** (float) : défaut = **0**  (-10,10)
* **`Angle (deg.)` ($11)** (float) : défaut = **0**  (-180,180)
* **`Outline (px)` ($12)** (int) : défaut = **2**  (0,8)
* **`Outline Color` ($13)** (color) : défaut = 0,0,0
* **`First Color` ($14)** (color) : défaut = 0,0,0
* **`Second Color` ($15)** (color) : défaut = 255,255,255
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2024/01/13.
