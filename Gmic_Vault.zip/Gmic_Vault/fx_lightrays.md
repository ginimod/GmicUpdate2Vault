---
tags: [gmic, filter]
command: fx_lightrays
---

# Filtre G'MIC : fx_lightrays

## Structure de la commande
```text
fx_lightrays:
    density = $1
    center_x = $2
    center_y = $3
    length = $4
    attenuation = $5
    transparency = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates volumetric light rays (crepuscular rays). 
* **`Density` ($1)** (float) : défaut = **30**  (0,100)
* **`Center (%)` ($2)** (point) : position = 0,0
* **`Length` ($3)** (float) : défaut = **1**  (0,1)
* **`Attenuation` ($4)** (float) : défaut = **0.5**  (0,1)
* **`Transparency` ($5)** (bool) : par défaut = Faux (0)
* **`Color` ($6)** (color) : défaut = 255,255,255
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2023/09/01.
