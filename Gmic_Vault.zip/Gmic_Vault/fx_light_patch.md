---
tags: [gmic, filter]
command: fx_light_patch
---

# Filtre G'MIC : fx_light_patch

## Structure de la commande
```text
fx_light_patch:
    density = $1
    darkness = $2
    lightness = $3
    channel_s = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds localized patches of light. 
* **`Density` ($1)** (int) : défaut = **5**  (2,30)
* **`Darkness` ($2)** (float) : défaut = **0.7**  (0,1)
* **`Lightness` ($3)** (float) : défaut = **2.5**  (1,4)
* **`Channel(s)` ($4)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
