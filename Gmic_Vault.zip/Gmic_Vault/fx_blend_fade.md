---
tags: [gmic, filter]
command: fx_blend_fade
---

# Filtre G'MIC : fx_blend_fade

## Structure de la commande
```text
fx_blend_fade:
    preset = $1
    offset = $2
    thinness = $3
    sharpness = $4
    sharpest = $5
    revert_layers = $6
    color_space = $7
    1st_parameter = $8
    2nd_parameter = $9
    3rd_parameter = $10
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Spatially fades layers into one another. 
* **`Preset` ($1)** (choice) : choix possibles => Custom, Linear, Circular, Wave, Keftales
* **`Offset` ($2)** (float) : défaut = **0**  (-1,1)
* **`Thinness` ($3)** (float) : défaut = **0**  (0,10)
* **`Sharpness` ($4)** (float) : défaut = **5**  (1,20)
* **`Sharpest` ($5)** (bool) : par défaut = Faux (0)
* **`Revert Layers` ($6)** (bool) : par défaut = Faux (0)
* **`Color Space` ($7)** (choice) : choix possibles => SRGB, Linear RGB, Lab
(Note) : 
 The parameters below are used in most presets. 
* **`1st Parameter` ($8)** (float) : défaut = **0**  (-1,1)
* **`2nd Parameter` ($9)** (float) : défaut = **0**  (-1,1)
* **`3rd Parameter` ($10)** (float) : défaut = **0**  (-1,1)
(Note) : 
 The formula below is used for the Custom preset. 
(Note) : Note: This filter needs two layers to work properly. Set the Input layers option to handle multiple input layers. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2013/01/21.
