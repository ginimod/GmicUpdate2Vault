---
tags: [gmic, filter]
command: fx_morph_layers
---

# Filtre G'MIC : fx_morph_layers

## Structure de la commande
```text
fx_morph_layers:
    inter_frames = $1
    smoothness = $2
    precision = $3
    revert_layers = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Morphs (interpolates with motion) between layers. 
* **`Inter-Frames` ($1)** (int) : défaut = **10**  (2,100)
* **`Smoothness` ($2)** (float) : défaut = **0.2**  (0,2)
* **`Precision` ($3)** (float) : défaut = **0.1**  (0,2)
* **`Revert Layers` ($4)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
