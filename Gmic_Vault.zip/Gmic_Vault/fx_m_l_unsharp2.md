---
tags: [gmic, filter]
command: fx_m_l_unsharp2
---

# Filtre G'MIC : fx_m_l_unsharp2

## Structure de la commande
```text
fx_m_l_unsharp2:
    radius_1 = $1
    amount_1 = $2
    radius_2 = $3
    amount_2 = $4
    darken_merge_opacity = $5
    lighten_merge_opacity = $6
    add_painter_s_touch = $7
    painter_s_touch_sharpness = $8
    painter_s_edge_protection_flow = $9
    painter_s_smoothness = $10
    preview_type = $11
```
## Définition des variables
* **`Radius 1` ($1)** (float) : défaut = **12**  (0,100)
* **`Amount 1` ($2)** (float) : défaut = **2.18**  (0,10)
* **`Radius 2` ($3)** (float) : défaut = **0.3**  (0,100)
* **`Amount 2` ($4)** (float) : défaut = **1.5**  (0,10)
* **`Darken Merge Opacity` ($5)** (float) : défaut = **1**  (0,1)
* **`Lighten Merge Opacity` ($6)** (float) : défaut = **0.5**  (0,1)
(Note) : Additional Painter Module
* **`Add Painter's Touch` ($7)** (bool) : par défaut = Faux (0)
* **`Painter's Touch Sharpness` ($8)** (float) : défaut = **0.5**  (0,2)
* **`Painter's Edge Protection Flow` ($9)** (float) : défaut = **0.8**  (0,1)
* **`Painter's Smoothness` ($10)** (float) : défaut = **1.28**  (0,10)
* **`Preview Type` ($11)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author: PhotoComiX. Latest update : 12/29/2010.
