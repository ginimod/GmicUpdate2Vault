---
tags: [gmic, filter]
command: fx_animate_stencilbw
---

# Filtre G'MIC : fx_animate_stencilbw

## Structure de la commande
```text
fx_animate_stencilbw:
    frames = $1
    output_frames = $2
    output_files = $3
    edge_threshold = $5
    smoothness = $6
    edge_threshold = $7
    smoothness = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Animates a stencil threshold effect. 
* **`Frames` ($1)** (int) : défaut = **10**  (2,100)
* **`Output Frames` ($2)** (bool) : par défaut = Faux (0)
* **`Output Files` ($3)** (bool) : par défaut = Faux (0)
(Note) : 
Starting Parameters :
* **`Edge Threshold` ($4)** (float) : défaut = **10**  (0,30)
* **`Smoothness` ($5)** (float) : défaut = **10**  (0,30)
(Note) : 
Ending Parameters :
* **`Edge Threshold` ($6)** (float) : défaut = **10**  (0,30)
* **`Smoothness` ($7)** (float) : défaut = **20**  (0,30)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
