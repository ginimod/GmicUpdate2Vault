---
tags: [gmic, filter]
command: cl_colorWheel
---

# Filtre G'MIC : cl_colorWheel

## Structure de la commande
```text
cl_colorWheel:
    external_circle_radius = $1
    internal_circle_radius_percentage = $2
    parts = $3
    type = $4
    inverse_order = $5
    rotation = $6
```
## Définition des variables
(Note) : Warning: This is an enormously gross approximation of the color models.
(Note) : Dimension:
* **`External Circle Radius` ($1)** (float) : défaut = **200**  (10,1000)
* **`Internal Circle Radius Percentage` ($2)** (float) : défaut = **80**  (1,99)
* **`Parts` ($3)** (choice) : choix possibles => X1, X2, X3, X4, Continuous
(Note) : Colors:
* **`Type` ($4)** (choice) : choix possibles => Red-Green-Blue Model, Red-Yellow-Blue Model, Opponent Model
(Note) : Rotation:
* **`Inverse Order` ($5)** (bool) : par défaut = Faux (0)
* **`Rotation` ($6)** (float) : défaut = **0**  (0,360)
(Note) : Author: Claude Lion. Latest Update: 2024/01/23.
