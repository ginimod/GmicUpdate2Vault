---
tags: [gmic, filter]
command: fx_drop_water
---

# Filtre G'MIC : fx_drop_water

## Structure de la commande
```text
fx_drop_water:
    shapes = $1
    density = $2
    radius = $3
    variability = $4
    random_seed = $5
    refraction = $6
    light_angle = $7
    specular_size = $8
    specular_intensity = $9
    specular_centering = $10
    shadow_size = $11
    shadow_intensity = $12
    shadow_smoothness = $13
    diffuse_shadow = $14
    smoothness = $15
    output_as_separate_layers = $16
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates water drops locally distorting the image. 
(Note) : Shape geometry:
* **`Shapes` ($1)** (choice) : choix possibles => Procedural, Opaque Regions on Top Layer
* **`Density` ($2)** (float) : défaut = **20**  (0,100)
* **`Radius` ($3)** (float) : défaut = **2**  (0,5)
* **`Variability` ($4)** (float) : défaut = **80**  (0,100)
* **`Random Seed` ($5)** (int) : défaut = **0**  (0,16384)
(Note) : Parameters Density, Radius, Variability and Random seed are used only in Procedural shapes mode.
(Note) : Light parameters:
* **`Refraction` ($6)** (float) : défaut = **3**  (0,20)
* **`Light Angle` ($7)** (float) : défaut = **35**  (0,360)
* **`Specular Size` ($8)** (float) : défaut = **10**  (0,100)
* **`Specular Intensity` ($9)** (float) : défaut = **1**  (0,1)
* **`Specular Centering` ($10)** (float) : défaut = **0.5**  (0,1)
(Note) : Shadow parameters:
* **`Shadow Size` ($11)** (float) : défaut = **0.25**  (0,3)
* **`Shadow Intensity` ($12)** (float) : défaut = **0.5**  (0,1)
* **`Shadow Smoothness` ($13)** (float) : défaut = **0.75**  (0,3)
* **`Diffuse Shadow` ($14)** (float) : défaut = **0.05**  (0,3)
* **`Smoothness` ($15)** (float) : défaut = **0.15**  (0,3)
* **`Output as Separate Layers` ($16)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/07/21.
