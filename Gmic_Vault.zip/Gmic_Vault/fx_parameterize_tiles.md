---
tags: [gmic, filter]
command: fx_parameterize_tiles
---

# Filtre G'MIC : fx_parameterize_tiles

## Structure de la commande
```text
fx_parameterize_tiles:
    x_tile_size_px = $1
    y_tile_size_px = $2
    fitting_function = $3
    x_overlap = $4
    y_overlap = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Approximate each image tile with a polynomial. 
* **`X-Tile Size (px)` ($1)** (int) : défaut = **32**  (1,256)
* **`Y-Tile Size (px)` ($2)** (int) : défaut = **32**  (1,256)
* **`Fitting Function` ($3)** (choice) : choix possibles => Linear, Quadratic, Cubic
* **`X-Overlap (%)` ($4)** (int) : défaut = **0**  (0,75)
* **`Y-Overlap (%)` ($5)** (int) : défaut = **0**  (0,75)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2024/12/17.
