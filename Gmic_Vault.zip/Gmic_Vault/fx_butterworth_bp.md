---
tags: [gmic, filter]
command: fx_butterworth_bp
---

# Filtre G'MIC : fx_butterworth_bp

## Structure de la commande
```text
fx_butterworth_bp:
    lp_frequency_power = $1
    lp_order_cube_root = $2
    lp_resonance = $3
    hp_frequency_power = $4
    hp_order_cube_root = $5
    hp_resonance = $6
    colour_space = $7
    alpha = $8
    absolute = $9
    makeup_gain = $10
    preview_frequency_response = $11
```
## Définition des variables
(Note) : Lowpass and highpass zero-phase resonant Butterworth-style filters.
* **`LP Frequency Power` ($1)** (float) : défaut = **3**  (0,16)
* **`LP Order Cube Root` ($2)** (float) : défaut = **2**  (0,4)
* **`LP Resonance` ($3)** (float) : défaut = **0**  (0,5)
* **`HP Frequency Power` ($4)** (float) : défaut = **4**  (0,16)
* **`HP Order Cube Root` ($5)** (float) : défaut = **2**  (0,4)
* **`HP Resonance` ($6)** (float) : défaut = **0**  (0,5)
* **`Colour Space` ($7)** (choice) : choix possibles => RGB, SRGB, CMY, RYB, Ohta8, Ohta, YES8, YES, Kodak 1-8, Kodak1, Lab8, Lab, Oklab, LUV, Jzazbz, YIQ8, YIQ, YUV8, YUV, YCbCr, YCbCrGLIC, YCbCrJPEG, YDbDr, XYZ8, XYZ, HSV8, HSV, HSL8, HSL, HSI8, HSI, LCH8, LCH, JzCzHz, HCY
* **`Alpha` ($8)** (bool) : par défaut = Faux (0)
* **`Absolute` ($9)** (bool) : par défaut = Faux (0)
* **`Makeup Gain` ($10)** (bool) : par défaut = Faux (0)
* **`Preview Frequency Response` ($11)** (bool) : par défaut = Faux (0)
