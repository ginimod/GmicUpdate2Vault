---
tags: [gmic, filter]
command: fx_marble
---

# Filtre G'MIC : fx_marble

## Structure de la commande
```text
fx_marble:
    image_weight = $1
    pattern_weight = $2
    pattern_angle = $3
    amplitude = $4
    sharpness = $5
    anisotropy = $6
    alpha = $7
    sigma = $8
    cut_low = $9
    cut_high = $10
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a marble-like texture. 
* **`Image Weight` ($1)** (float) : défaut = **.5**  (0,30)
* **`Pattern Weight` ($2)** (float) : défaut = **1**  (0,30)
* **`Pattern Angle` ($3)** (float) : défaut = **0**  (0,360)
* **`Amplitude` ($4)** (float) : défaut = **0**  (0,1000)
* **`Sharpness` ($5)** (float) : défaut = **.4**  (0,5)
* **`Anisotropy` ($6)** (float) : défaut = **.6**  (0,1)
* **`Alpha` ($7)** (float) : défaut = **.6**  (0,20)
* **`Sigma` ($8)** (float) : défaut = **1.1**  (0,20)
* **`Cut Low` ($9)** (float) : défaut = **0**  (0,100)
* **`Cut High` ($10)** (float) : défaut = **100**  (0,100)
(Note) : Author: Preben Soeberg.      Latest Update: 2010/12/29.
