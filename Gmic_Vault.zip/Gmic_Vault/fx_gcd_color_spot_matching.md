---
tags: [gmic, filter]
command: fx_gcd_color_spot_matching
---

# Filtre G'MIC : fx_gcd_color_spot_matching

## Structure de la commande
```text
fx_gcd_color_spot_matching:
    source_x = $1
    source_y = $2
    target_x = $3
    target_y = $4
    chromacity_range = $5
    preview = $6
    swap_layers = $7
```
## Définition des variables
(Note) : Use color curves to match the target to the source
* **`Source` ($1)** (point) : position = 0,0
* **`Target` ($2)** (point) : position = 0,0
* **`Chromacity Range` ($3)** (choice) : choix possibles => Global, Wide, Narrow
* **`Preview` ($4)** (choice) : choix possibles => Vertical, Horizontal, Layers
* **`Swap Layers` ($5)** (bool) : par défaut = Faux (0)
(Note) : Author : Garagecoder.      Latest update : 2022/06/15.
(Note) : 
<u>Notes</u>
(Note) : Ensure the layer dimensions match for best results.
(Note) : Reduce chromacity range to limit the affected regions.
(Note) : sRGB D65 input is assumed.
