---
tags: [gmic, filter]
command: fx_gcd_weighted_boxfilter
---

# Filtre G'MIC : fx_gcd_weighted_boxfilter

## Structure de la commande
```text
fx_gcd_weighted_boxfilter:
    radius = $1
    weight = $2
    channel_s = $3
```
## Définition des variables
(Note) : Weighted box average filter
* **`Radius` ($1)** (float) : défaut = **1**  (0,2)
* **`Weight` ($2)** (float) : défaut = **0**  (-2,2)
* **`Channel(s)` ($3)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CYMK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author : Garagecoder.      Latest update : 2023/09/30.
