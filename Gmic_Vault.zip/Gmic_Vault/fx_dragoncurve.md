---
tags: [gmic, filter]
command: fx_dragoncurve
---

# Filtre G'MIC : fx_dragoncurve

## Structure de la commande
```text
fx_dragoncurve:
    recursions = $1
    angle = $2
    opacity = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Renders a Dragon Curve fractal. 
* **`Recursions` ($1)** (int) : défaut = **20**  (0,30)
* **`Angle` ($2)** (float) : défaut = **0**  (-180,180)
* **`Opacity` ($3)** (float) : défaut = **1**  (0,1)
* **`Color` ($4)** (color) : défaut = 255,255,255
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2019/01/29.
