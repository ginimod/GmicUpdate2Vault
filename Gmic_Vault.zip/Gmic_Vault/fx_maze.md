---
tags: [gmic, filter]
command: fx_maze
---

# Filtre G'MIC : fx_maze

## Structure de la commande
```text
fx_maze:
    cell_size = $1
    thickness = $2
    masking = $3
    preserve_image_dimension = $4
    maze_type = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a random maze. 
* **`Cell Size` ($1)** (int) : défaut = **24**  (1,256)
* **`Thickness` ($2)** (int) : défaut = **1**  (1,10)
* **`Masking` ($3)** (choice) : choix possibles => None, Render on Dark Areas, Render on White Areas
* **`Preserve Image Dimension` ($4)** (bool) : par défaut = Faux (0)
* **`Maze Type` ($5)** (choice) : choix possibles => Dark Walls, White Walls
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2011/02/09.
