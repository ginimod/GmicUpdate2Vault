---
tags: [gmic, filter]
command: fx_normalize_local
---

# Filtre G'MIC : fx_normalize_local

## Structure de la commande
```text
fx_normalize_local:
    amplitude = $1
    radius = $2
    neighborhood_smoothness = $3
    average_smoothness = $4
    constrain_values = $5
    channel_s = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Normalizes brightness/contrast within local neighborhoods. 
* **`Amplitude` ($1)** (float) : défaut = **2**  (0,60)
* **`Radius` ($2)** (int) : défaut = **6**  (1,64)
* **`Neighborhood Smoothness` ($3)** (float) : défaut = **5**  (0,40)
* **`Average Smoothness` ($4)** (float) : défaut = **20**  (0,40)
* **`Constrain Values` ($5)** (bool) : par défaut = Faux (0)
* **`Channel(s)` ($6)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
