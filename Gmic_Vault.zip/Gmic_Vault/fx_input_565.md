---
tags: [gmic, filter]
command: fx_input_565
---

# Filtre G'MIC : fx_input_565

## Structure de la commande
```text
fx_input_565:
    reverse_endianness = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Imports an image from a raw RGB-565 file. 
* **`Reverse Endianness` ($1)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2020/05/03.
