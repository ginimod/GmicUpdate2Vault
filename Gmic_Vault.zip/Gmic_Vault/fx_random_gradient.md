---
tags: [gmic, filter]
command: fx_random_gradient
---

# Filtre G'MIC : fx_random_gradient

## Structure de la commande
```text
fx_random_gradient:
    density = $1
    seed = $2
    smoothness = $3
    quantization = $4
    opacity = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a color gradient with random colors/positions. 
* **`Density` ($1)** (int) : défaut = **32**  (1,1024)
* **`Seed` ($2)** (int) : défaut = **0**  (0,65535)
* **`Smoothness` ($3)** (float) : défaut = **0**  (0,10)
* **`Quantization` ($4)** (int) : défaut = **0**  (0,64)
* **`Color Balance` ($5)** (color) : défaut = 128,128,128
* **`Opacity` ($6)** (float) : défaut = **1**  (0,1)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/04/08.
