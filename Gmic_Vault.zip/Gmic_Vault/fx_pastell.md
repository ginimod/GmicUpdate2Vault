---
tags: [gmic, filter]
command: fx_pastell
---

# Filtre G'MIC : fx_pastell

## Structure de la commande
```text
fx_pastell:
    masteropacity = $1
    bg_textured = $2
    reverse_effect = $3
    amplitude = $4
    thickness = $5
    sharpness = $6
    orientations = $7
    offset = $8
    color_mode = $9
    smoothness = $10
    linearity = $11
    negative_colors = $12
    activate_shakes = $13
    amount = $14
    strength = $15
    activate_lizards = $16
    toes = $17
    shivers = $18
    activate_pink_elephants = $19
    trunks = $20
    preview_type = $21
```
## Définition des variables
* **`MasterOpacity` ($1)** (float) : défaut = **0.6**  (0.3,1)
* **`BG Textured` ($2)** (bool) : par défaut = Faux (0)
* **`Reverse Effect` ($3)** (bool) : par défaut = Faux (0)
(Note) : Rodilius settings
* **`Amplitude` ($4)** (float) : défaut = **20**  (0,30)
* **`Thickness` ($5)** (float) : défaut = **30**  (0,100)
* **`Sharpness` ($6)** (float) : défaut = **300**  (0,1000)
* **`Orientations` ($7)** (int) : défaut = **1**  (1,36)
* **`Offset` ($8)** (float) : défaut = **30**  (0,180)
* **`Color Mode` ($9)** (choice) : choix possibles => Darker, Lighter
(Note) : Gradient settings
* **`Smoothness` ($10)** (float) : défaut = **1**  (0,10)
* **`Linearity` ($11)** (float) : défaut = **0.5**  (0,1.5)
* **`Negative Colors` ($12)** (bool) : par défaut = Faux (0)
* **`Activate Shakes` ($13)** (bool) : par défaut = Faux (0)
* **`Amount` ($14)** (float) : défaut = **10**  (0,30)
* **`Strength` ($15)** (float) : défaut = **3**  (1,300)
* **`Activate Lizards` ($16)** (bool) : par défaut = Faux (0)
* **`Toes` ($17)** (float) : défaut = **9**  (0,300)
* **`Shivers` ($18)** (float) : défaut = **3**  (0,4)
* **`Activate Pink Elephants` ($19)** (bool) : par défaut = Faux (0)
* **`Trunks` ($20)** (float) : défaut = **12**  (0,100)
* **`Preview Type` ($21)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author : Arto Huotari.      Latest update : 2013/09/28.
