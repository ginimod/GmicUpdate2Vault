---
tags: [gmic, filter]
command: fx_dices
---

# Filtre G'MIC : fx_dices

## Structure de la commande
```text
fx_dices:
    resolution = $1
    size = $2
    color_model = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Reconstructs the image using a mosaic of dice faces. 
* **`Resolution` ($1)** (float) : défaut = **2**  (1,10)
* **`Size` ($2)** (int) : défaut = **24**  (8,64)
* **`Color Model` ($3)** (choice) : choix possibles => Black Dices, White Dices, Dices with Colored Numbers, Dices with Colored Sides
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2013/06/27.
