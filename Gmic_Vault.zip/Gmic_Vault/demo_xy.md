---
tags: [gmic, filter]
command: demo_xy
---

# Filtre G'MIC : demo_xy

## Structure de la commande
```text
demo_xy:
    x_scale = $1
    y_scale = $2
```
## Définition des variables
(Note) : mathmap xy: demo
* **`X Scale` ($1)** (float) : défaut = **1**  (0,10)
* **`Y Scale` ($2)** (float) : défaut = **1**  (0,10)
