---
tags: [gmic, filter]
command: fx_mix_rgb
---

# Filtre G'MIC : fx_mix_rgb

## Structure de la commande
```text
fx_mix_rgb:
    red_factor = $1
    red_shift = $2
    red_smoothness = $3
    green_factor = $4
    green_shift = $5
    green_smoothness = $6
    blue_factor = $7
    blue_shift = $8
    blue_smoothness = $9
    tones_range = $10
    tones_smoothness = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Standard RGB channel mixer. 
* **`Red Factor` ($1)** (float) : défaut = **1**  (0,4)
* **`Red Shift` ($2)** (float) : défaut = **0**  (-255,255)
* **`Red Smoothness` ($3)** (float) : défaut = **0**  (0,10)
* **`Green Factor` ($4)** (float) : défaut = **1**  (0,4)
* **`Green Shift` ($5)** (float) : défaut = **0**  (-255,255)
* **`Green Smoothness` ($6)** (float) : défaut = **0**  (0,10)
* **`Blue Factor` ($7)** (float) : défaut = **1**  (0,4)
* **`Blue Shift` ($8)** (float) : défaut = **0**  (-255,255)
* **`Blue Smoothness` ($9)** (float) : défaut = **0**  (0,10)
* **`Tones Range` ($10)** (choice) : choix possibles => All Tones, Shadows, Mid-Tones, Highlights
* **`Tones Smoothness` ($11)** (float) : défaut = **2**  (0,10)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/06/20.
