---
tags: [gmic, filter]
command: deinterlace
---

# Filtre G'MIC : deinterlace

## Structure de la commande
```text
deinterlace:
    algorithm = $1
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Removes interlacing lines from video frames. 
* **`Algorithm` ($1)** (choice) : choix possibles => Standard, Motion-Compensated
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
