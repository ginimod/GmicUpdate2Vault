---
tags: [gmic, filter]
command: fx_hardsketchbw
---

# Filtre G'MIC : fx_hardsketchbw

## Structure de la commande
```text
fx_hardsketchbw:
    amplitude = $1
    density = $2
    smoothness = $3
    opacity = $4
    edge = $5
    fast_approximation = $6
    color_model = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a high-contrast, rough sketch. 
* **`Amplitude` ($1)** (float) : défaut = **300**  (0,4000)
* **`Density` ($2)** (float) : défaut = **50**  (0,100)
* **`Smoothness` ($3)** (float) : défaut = **1**  (0,10)
* **`Opacity` ($4)** (float) : défaut = **0.1**  (0,1)
* **`Edge` ($5)** (float) : défaut = **20**  (0,100)
* **`Fast Approximation` ($6)** (bool) : par défaut = Faux (0)
* **`Color Model` ($7)** (choice) : choix possibles => Black on White, White on Black, Black on Transparent White, White on Transparent Black, Color on White
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
