---
tags: [gmic, filter]
command: fx_map_sphere
---

# Filtre G'MIC : fx_map_sphere

## Structure de la commande
```text
fx_map_sphere:
    width = $1
    height = $2
    radius = $3
    dilation = $4
    angle = $5
    border_smoothness = $6
    border_width = $7
    orientation = $8
    background = $9
    fading = $10
    fading_shape = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Maps the image onto a sphere. 
* **`Width` ($1)** (int) : défaut = **512**  (1,4096)
* **`Height` ($2)** (int) : défaut = **512**  (1,4096)
* **`Radius` ($3)** (float) : défaut = **90**  (0,400)
* **`Dilation` ($4)** (float) : défaut = **0.5**  (0,1)
* **`Angle` ($5)** (float) : défaut = **0**  (-50,50)
* **`Border Smoothness` ($6)** (float) : défaut = **0**  (0,200)
* **`Border Width` ($7)** (float) : défaut = **20**  (0,100)
* **`Orientation` ($8)** (choice) : choix possibles => 0 Deg., 90 Deg., 180 Deg., 270 Deg.
* **`Background` ($9)** (choice) : choix possibles => Transparent, Mean Color
* **`Fading` ($10)** (float) : défaut = **0**  (0,100)
* **`Fading Shape` ($11)** (float) : défaut = **0.5**  (0,3)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2011/07/11.
