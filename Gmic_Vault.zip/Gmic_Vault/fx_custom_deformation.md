---
tags: [gmic, filter]
command: fx_custom_deformation
---

# Filtre G'MIC : fx_custom_deformation

## Structure de la commande
```text
fx_custom_deformation:
    relative_warping = $3
    interpolation = $4
    boundary = $5
    a = $6
    b = $7
    c = $8
    d = $9
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Applies a deformation based on Cartesian coordinates formulae. 
* **`Relative Warping` ($1)** (bool) : par défaut = Faux (0)
* **`Interpolation` ($2)** (choice) : choix possibles => Nearest Neighbor, Linear
* **`Boundary` ($3)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
(Note) : Note:The parameters below can be used in the warping formulas:
* **`A` ($4)** (float) : défaut = **10**  (-100,100)
* **`B` ($5)** (float) : défaut = **10**  (-100,100)
* **`C` ($6)** (float) : défaut = **10**  (-100,100)
* **`D` ($7)** (float) : défaut = **10**  (-100,100)
(Note) : This filter lets you define custom mapping functions.
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2023/10/26.
