---
tags: [gmic, filter]
command: exfusion5
---

# Filtre G'MIC : exfusion5

## Structure de la commande
```text
exfusion5:
    contrast_bias = $1
    saturation_bias = $2
    exposure_sigma = $3
    exposure_bias = $4
    local_contrast = $5
    curve = $6
```
## Définition des variables
* **`Contrast Bias` ($1)** (float) : défaut = **0**  (0,1)
* **`Saturation Bias` ($2)** (float) : défaut = **.2**  (0,1)
* **`Exposure Sigma` ($3)** (float) : défaut = **0.2**  (0,1)
* **`Exposure Bias` ($4)** (float) : défaut = **1**  (0,1)
(Note) : Post Fusion Options
* **`Local Contrast` ($5)** (float) : défaut = **0**  (0,3)
* **`Curve` ($6)** (float) : défaut = **0**  (-127,127)
