---
tags: [gmic, filter]
command: fx_frame_painting
---

# Filtre G'MIC : fx_frame_painting

## Structure de la commande
```text
fx_frame_painting:
    size = $1
    contrast = $2
    smoothness = $3
    vignette_size = $7
    vignette_contrast = $8
    defects_contrast = $9
    defects_density = $10
    defects_size = $11
    defects_smoothness = $12
    serial_number = $13
    frame_as_a_new_layer = $14
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds a border that looks like a painting frame. 
* **`Size (%)` ($1)** (float) : défaut = **10**  (0,100)
* **`Contrast` ($2)** (float) : défaut = **0.4**  (0,1)
* **`Smoothness` ($3)** (float) : défaut = **6**  (0,30)
* **`Color` ($4)** (color) : défaut = 225,200,120
* **`Vignette Size` ($5)** (float) : défaut = **2**  (0,50)
* **`Vignette Contrast` ($6)** (float) : défaut = **400**  (0,1000)
* **`Defects Contrast` ($7)** (float) : défaut = **50**  (0,512)
* **`Defects Density` ($8)** (float) : défaut = **10**  (0,100)
* **`Defects Size` ($9)** (float) : défaut = **1**  (0,10)
* **`Defects Smoothness` ($10)** (float) : défaut = **0.5**  (0,20)
* **`Serial Number` ($11)** (int) : défaut = **123456**  (0,1000000)
* **`Frame as a New Layer` ($12)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2012/06/07.
