---
tags: [gmic, filter]
command: fx_LCE
---

# Filtre G'MIC : fx_LCE

## Structure de la commande
```text
fx_LCE:
    spatial_radius = $1
    amount = $2
    darkness_level = $3
    lightness_level = $4
    channel_s = $5
    preview_type = $6
```
## Définition des variables
(Note) : Local contrast enhancement is Unsharp Mask with high radius. Apply filter to RGB channels for color and contrast enhancement.
* **`Spatial Radius` ($1)** (float) : défaut = **80**  (30,200)
* **`Amount` ($2)** (float) : défaut = **0.5**  (0,5)
* **`Darkness Level` ($3)** (float) : défaut = **1**  (0,4)
* **`Lightness Level` ($4)** (float) : défaut = **1**  (0,4)
* **`Channel(s)` ($5)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CYMK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
* **`Preview Type` ($6)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : 

Note :  Original USM code by by David Tschumperlé. 
(Note) : Authors : Arto Huotari, PhotoComiX.      Latest update : 2013/03/23.
