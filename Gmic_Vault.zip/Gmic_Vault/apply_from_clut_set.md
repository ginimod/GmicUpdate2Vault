---
tags: [gmic, filter]
command: apply_from_clut_set
---

# Filtre G'MIC : apply_from_clut_set

## Structure de la commande
```text
apply_from_clut_set:
    index = $2
    strength = $3
    brightness = $4
    contrast = $5
    gamma = $6
    hue = $7
    saturation = $8
    normalize_colors = $9
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Applies a CLUT from a built-in predefined set (.gmz format). 
* **`Index` ($1)** (int) : défaut = **1**  (1,1024)
* **`Strength (%)` ($2)** (float) : défaut = **100**  (0,100)
* **`Brightness (%)` ($3)** (float) : défaut = **0**  (-100,100)
* **`Contrast (%)` ($4)** (float) : défaut = **0**  (-100,100)
* **`Gamma (%)` ($5)** (float) : défaut = **0**  (-100,100)
* **`Hue (%)` ($6)** (float) : défaut = **0**  (-100,100)
* **`Saturation (%)` ($7)** (float) : défaut = **0**  (-100,100)
* **`Normalize Colors` ($8)** (choice) : choix possibles => None, Pre-Normalize, Post-Normalize, Both
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2022/05/08.
