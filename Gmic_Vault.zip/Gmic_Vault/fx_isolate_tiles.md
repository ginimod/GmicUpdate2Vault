---
tags: [gmic, filter]
command: fx_isolate_tiles
---

# Filtre G'MIC : fx_isolate_tiles

## Structure de la commande
```text
fx_isolate_tiles:
    x_size = $1
    y_size = $2
    x_border = $3
    y_border = $4
    keep_tiles_square = $5
    keep_borders_square = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Separates grid tiles into distinct regions. 
* **`X-Size` ($1)** (float) : défaut = **10**  (0,100)
* **`Y-Size` ($2)** (float) : défaut = **10**  (0,100)
* **`X-Border` ($3)** (float) : défaut = **5**  (0,100)
* **`Y-Border` ($4)** (float) : défaut = **5**  (0,100)
* **`Keep Tiles Square` ($5)** (bool) : par défaut = Faux (0)
* **`Keep Borders Square` ($6)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2011/04/13.
