---
tags: [gmic, filter]
command: fx_channel_processing
---

# Filtre G'MIC : fx_channel_processing

## Structure de la commande
```text
fx_channel_processing:
    brightness = $1
    contrast = $2
    gamma = $3
    smoothness = $4
    value_action = $5
    low_value = $6
    high_value = $7
    quantization = $8
    equalization = $9
    negation = $10
    tones_range = $11
    tones_smoothness = $12
    channel_s = $13
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Applies operations to specific color channels. 
* **`Brightness (%)` ($1)** (float) : défaut = **0**  (-100,100)
* **`Contrast (%)` ($2)** (float) : défaut = **0**  (-100,100)
* **`Gamma (%)` ($3)** (float) : défaut = **0**  (-100,100)
* **`Smoothness` ($4)** (float) : défaut = **0**  (0,10)
* **`Value Action` ($5)** (choice) : choix possibles => None, Cut, Cut & Normalize, Normalize, Threshold
* **`Low Value` ($6)** (float) : défaut = **0**  (0,100)
* **`High Value` ($7)** (float) : défaut = **100**  (0,100)
* **`Quantization` ($8)** (int) : défaut = **256**  (1,256)
* **`Equalization` ($9)** (bool) : par défaut = Faux (0)
* **`Negation` ($10)** (bool) : par défaut = Faux (0)
* **`Tones Range` ($11)** (choice) : choix possibles => All Tones, Shadows, Mid-Tones, Highlights
* **`Tones Smoothness` ($12)** (float) : défaut = **2**  (0,10)
* **`Channel(s)` ($13)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
