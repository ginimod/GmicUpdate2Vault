---
tags: [gmic, filter]
command: fx_plasma
---

# Filtre G'MIC : fx_plasma

## Structure de la commande
```text
fx_plasma:
    alpha = $1
    beta = $2
    scale = $3
    randomize = $4
    transparency = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a colorful plasma cloud effect. 
* **`Alpha` ($1)** (float) : défaut = **0.5**  (0,5)
* **`Beta` ($2)** (float) : défaut = **0**  (0,100)
* **`Scale` ($3)** (int) : défaut = **8**  (2,10)
* **`Randomize` ($4)** (bool) : par défaut = Faux (0)
* **`Transparency` ($5)** (bool) : par défaut = Faux (0)
* **`Color Balance` ($6)** (color) : défaut = 128,128,128
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2011/03/20.
