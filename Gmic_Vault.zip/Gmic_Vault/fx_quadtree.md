---
tags: [gmic, filter]
command: fx_quadtree
---

# Filtre G'MIC : fx_quadtree

## Structure de la commande
```text
fx_quadtree:
    mode = $1
    precision = $2
    homogeneity = $3
    outline = $4
    primary_radius = $5
    secondary_radius = $6
    anisotropy = $7
    only_leafs = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Decomposes the image into rectangles of different sizes using a Quadtree algorithm. 
* **`Mode` ($1)** (choice) : choix possibles => Squares, Sierpinksi Design, Ellipse Painting
* **`Precision` ($2)** (int) : défaut = **1024**  (2,4096)
* **`Homogeneity` ($3)** (float) : défaut = **0.5**  (0,2)
* **`Outline` ($4)** (int) : défaut = **0**  (0,4)
(Note) : For 'Ellipse painting' only:
* **`Primary Radius` ($5)** (float) : défaut = **3**  (0,5)
* **`Secondary Radius` ($6)** (float) : défaut = **1.5**  (0,5)
* **`Anisotropy` ($7)** (float) : défaut = **1**  (0,4)
* **`Only Leafs` ($8)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2017/06/15.
