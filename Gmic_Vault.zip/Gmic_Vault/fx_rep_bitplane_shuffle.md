---
tags: [gmic, filter]
command: fx_rep_bitplane_shuffle
---

# Filtre G'MIC : fx_rep_bitplane_shuffle

## Structure de la commande
```text
fx_rep_bitplane_shuffle:
    direction = $1
    depth = $2
    use_alpha = $3
    shuffle_index = $6
    shuffle_index = $7
    plane_shift_method = $9
    plane_a = $10
    plane_b = $11
    plane_c = $12
    plane_d = $13
    plane_e = $14
    plane_f = $15
    plane_g = $16
    plane_h = $17
    plane_a = $18
    plane_b = $19
    plane_c = $20
    plane_d = $21
    plane_e = $22
    plane_f = $23
    plane_g = $24
    plane_h = $25
    plane_a = $26
    plane_b = $27
    plane_c = $28
    plane_d = $29
    plane_e = $30
    plane_f = $31
    plane_g = $32
    plane_h = $33
    plane_i = $34
    plane_j = $35
    plane_k = $36
    plane_l = $37
    plane_m = $38
    plane_n = $39
    plane_o = $40
    plane_p = $41
    plane_a = $42
    plane_b = $43
    plane_c = $44
    plane_d = $45
    plane_e = $46
    plane_f = $47
    plane_g = $48
    plane_h = $49
    plane_i = $50
    plane_j = $51
    plane_k = $52
    plane_l = $53
    plane_m = $54
    plane_n = $55
    plane_o = $56
    plane_p = $57
    depth = $59
    visited_8_bit = $60
    visited_16_bit = $61
    preview_type = $62
    preview_split_x = $63
    preview_split_y = $64
```
## Définition des variables
(Note) : Main
* **`Direction` ($1)** (choice) : choix possibles => Forward, Backward
* **`Depth` ($2)** (choice) : choix possibles => 8-Bit, 16-Bit
* **`Use Alpha?` ($3)** (bool) : par défaut = Faux (0)
(Note) : CLI Command
(Note) : Plane Shuffling
* **`Shuffle Index` ($4)** (int) : défaut = **0**  (0,40319)
* **`Shuffle Index` ($5)** (int) : défaut = **0**  (0,40319)
* **`Plane Shift Method` ($6)** (choice) : choix possibles => Move, Swap
* **`Plane A` ($7)** (int) : défaut = **1**  (1,8)
* **`Plane B` ($8)** (int) : défaut = **2**  (1,8)
* **`Plane C` ($9)** (int) : défaut = **3**  (1,8)
* **`Plane D` ($10)** (int) : défaut = **4**  (1,8)
* **`Plane E` ($11)** (int) : défaut = **5**  (1,8)
* **`Plane F` ($12)** (int) : défaut = **6**  (1,8)
* **`Plane G` ($13)** (int) : défaut = **7**  (1,8)
* **`Plane H` ($14)** (int) : défaut = **8**  (1,8)
* **`Plane A` ($15)** (int) : défaut = **1**  (1,8)
* **`Plane B` ($16)** (int) : défaut = **2**  (1,8)
* **`Plane C` ($17)** (int) : défaut = **3**  (1,8)
* **`Plane D` ($18)** (int) : défaut = **4**  (1,8)
* **`Plane E` ($19)** (int) : défaut = **5**  (1,8)
* **`Plane F` ($20)** (int) : défaut = **6**  (1,8)
* **`Plane G` ($21)** (int) : défaut = **7**  (1,8)
* **`Plane H` ($22)** (int) : défaut = **8**  (1,8)
* **`Plane A` ($23)** (int) : défaut = **8**  (1,16)
* **`Plane B` ($24)** (int) : défaut = **10**  (1,16)
* **`Plane C` ($25)** (int) : défaut = **9**  (1,16)
* **`Plane D` ($26)** (int) : défaut = **4**  (1,16)
* **`Plane E` ($27)** (int) : défaut = **7**  (1,16)
* **`Plane F` ($28)** (int) : défaut = **13**  (1,16)
* **`Plane G` ($29)** (int) : défaut = **1**  (1,16)
* **`Plane H` ($30)** (int) : défaut = **3**  (1,16)
* **`Plane I` ($31)** (int) : défaut = **11**  (1,16)
* **`Plane J` ($32)** (int) : défaut = **14**  (1,16)
* **`Plane K` ($33)** (int) : défaut = **6**  (1,16)
* **`Plane L` ($34)** (int) : défaut = **2**  (1,16)
* **`Plane M` ($35)** (int) : défaut = **12**  (1,16)
* **`Plane N` ($36)** (int) : défaut = **5**  (1,16)
* **`Plane O` ($37)** (int) : défaut = **15**  (1,16)
* **`Plane P` ($38)** (int) : défaut = **16**  (1,16)
* **`Plane A` ($39)** (int) : défaut = **8**  (1,16)
* **`Plane B` ($40)** (int) : défaut = **10**  (1,16)
* **`Plane C` ($41)** (int) : défaut = **9**  (1,16)
* **`Plane D` ($42)** (int) : défaut = **4**  (1,16)
* **`Plane E` ($43)** (int) : défaut = **7**  (1,16)
* **`Plane F` ($44)** (int) : défaut = **13**  (1,16)
* **`Plane G` ($45)** (int) : défaut = **1**  (1,16)
* **`Plane H` ($46)** (int) : défaut = **3**  (1,16)
* **`Plane I` ($47)** (int) : défaut = **11**  (1,16)
* **`Plane J` ($48)** (int) : défaut = **14**  (1,16)
* **`Plane K` ($49)** (int) : défaut = **6**  (1,16)
* **`Plane L` ($50)** (int) : défaut = **2**  (1,16)
* **`Plane M` ($51)** (int) : défaut = **12**  (1,16)
* **`Plane N` ($52)** (int) : défaut = **5**  (1,16)
* **`Plane O` ($53)** (int) : défaut = **15**  (1,16)
* **`Plane P` ($54)** (int) : défaut = **16**  (1,16)
* **`Depth` ($55)** (choice) : choix possibles => 8-Bit, 16-Bit
* **`Visited 8-Bit` ($56)** (bool) : par défaut = Faux (0)
* **`Visited 16-Bit` ($57)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($58)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($59)** (point) : position = 0,0
(Note) : Author: Reptorian Latest update: 2023/11/27.
