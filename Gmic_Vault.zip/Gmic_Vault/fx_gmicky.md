---
tags: [gmic, filter]
command: fx_gmicky
---

# Filtre G'MIC : fx_gmicky

## Structure de la commande
```text
fx_gmicky:
    mascot_image = $1
```
## Définition des variables
* **`Mascot Image` ($1)** (choice) : choix possibles => Gmicky (by Deevad), Gmicky (by Mahvin), Gmicky & Wilber (by Mahvin), Roddy (by Mahvin)
(Note) : Gmicky is the name of the G'MIC mascot. He is a small and cute tiger who knows how to do magic. Gmicky is a tiger, i.e. fast, agile and elegant, just as the G'MIC code is :). Like many magicians, Gmicky knows a lot of gimmicks, and he is a direct and friendly companion of the ImageMagick's wizard, or the GraphicMagick's frog.
(Note) : Roddy is another mascot designed specifically for the Artistic / Rodilius filter of G'MIC.

(Note) : Gmicky and Roddy have been both created and drawn by 
(Note) : and
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2026/03/16.
