---
tags: [gmic, filter]
command: fx_circle_abstraction
---

# Filtre G'MIC : fx_circle_abstraction

## Structure de la commande
```text
fx_circle_abstraction:
    number_of_colors = $1
    density = $2
    opacity = $3
    smoothness = $4
    filled_circles = $5
    fill_transparent_holes = $6
    normalize_colors = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Approximates the image using variable-sized circles. 
* **`Number of Colors` ($1)** (int) : défaut = **8**  (2,16)
* **`Density` ($2)** (int) : défaut = **5**  (1,100)
* **`Opacity` ($3)** (float) : défaut = **0.8**  (0,1)
* **`Smoothness` ($4)** (float) : défaut = **0**  (0,4)
* **`Filled Circles` ($5)** (bool) : par défaut = Faux (0)
* **`Fill Transparent Holes` ($6)** (bool) : par défaut = Faux (0)
* **`Normalize Colors` ($7)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2014/06/16.
