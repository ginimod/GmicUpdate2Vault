---
tags: [gmic, filter]
command: fx_gradient_poles
---

# Filtre G'MIC : fx_gradient_poles

## Structure de la commande
```text
fx_gradient_poles:
    ph_r = $1
    color_space = $2
    quantization = $3
    point_0_x = $4
    point_0_y = $5
    point_1_x = $10
    point_1_y = $11
    point_2_x = $16
    point_2_y = $17
    point_3_x = $22
    point_3_y = $23
    point_4_x = $28
    point_4_y = $29
    point_5_x = $34
    point_5_y = $35
    point_6_x = $40
    point_6_y = $41
    point_7_x = $46
    point_7_y = $47
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a color gradient between control points. 
* **`φ(r)` ($1)** (choice) : choix possibles => Exp(-R), √(1+r²), R, R³, R.log(1+r)
* **`Color Space` ($2)** (choice) : choix possibles => SRGB, Linear RGB, Lab
* **`Quantization` ($3)** (int) : défaut = **0**  (0,64)
* **`Point #0` ($4)** (point) : position = 0,0
* **`Color #0` ($5)** (color) : défaut = 0,0,0,255
* **`Point #1` ($6)** (point) : position = 0,0
* **`Color #1` ($7)** (color) : défaut = 0,0,255,255
* **`Point #2` ($8)** (point) : position = 0,0
* **`Color #2` ($9)** (color) : défaut = 0,255,0,255
* **`Point #3` ($10)** (point) : position = 0,0
* **`Color #3` ($11)** (color) : défaut = 0,255,255,255
* **`Point #4` ($12)** (point) : position = 0,0
* **`Color #4` ($13)** (color) : défaut = 255,0,0,255
* **`Point #5` ($14)** (point) : position = 0,0
* **`Color #5` ($15)** (color) : défaut = 255,0,255,255
* **`Point #6` ($16)** (point) : position = 0,0
* **`Color #6` ($17)** (color) : défaut = 255,255,0,255
* **`Point #7` ($18)** (point) : position = 0,0
* **`Color #7` ($19)** (color) : défaut = 255,255,255,255
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>       Latest Update: 2025/10/23.
