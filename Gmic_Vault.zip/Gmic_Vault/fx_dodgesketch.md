---
tags: [gmic, filter]
command: fx_dodgesketch
---

# Filtre G'MIC : fx_dodgesketch

## Structure de la commande
```text
fx_dodgesketch:
    power = $1
    spatial_variance = $2
    value_variance = $3
    iterations = $4
    colored = $5
    preview_type = $6
```
## Définition des variables
(Note) : Simple BW sketch
(Note) : in addition an option to color the sketch is included
(Note) : Power setting for sketch
* **`Power` ($1)** (int) : défaut = **3**  (0,10)
(Note) : Presmoothing settins of bilateral filter
* **`Spatial Variance` ($2)** (float) : défaut = **10**  (0,100)
* **`Value Variance` ($3)** (float) : défaut = **7**  (0,100)
* **`Iterations` ($4)** (int) : défaut = **2**  (1,10)
* **`Colored?` ($5)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($6)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author : Arto Huotari.      Latest update : 2013/09/28.
