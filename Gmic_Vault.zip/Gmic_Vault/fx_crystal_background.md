---
tags: [gmic, filter]
command: fx_crystal_background
---

# Filtre G'MIC : fx_crystal_background

## Structure de la commande
```text
fx_crystal_background:
    iterations = $1
    density = $2
    random_seed = $3
    opacity = $4
    color = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a background of abstract crystals. 
* **`Iterations` ($1)** (int) : défaut = **10**  (1,32)
* **`Density (%)` ($2)** (float) : défaut = **25**  (0,100)
* **`Random Seed` ($3)** (int) : défaut = **0**  (0,65535)
* **`Opacity (%)` ($4)** (float) : défaut = **100**  (0,100)
* **`Color` ($5)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/10/18.
