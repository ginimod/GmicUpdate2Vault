---
tags: [gmic, filter]
command: fx_conformal_maps
---

# Filtre G'MIC : fx_conformal_maps

## Structure de la commande
```text
fx_conformal_maps:
    mapping = $1
    exponent_real = $2
    exponent_imaginary = $3
    zoom = $5
    angle = $6
    aspect_ratio = $7
    x_shift = $8
    y_shift = $9
    boundary = $10
    anti_aliasing = $11
    specify_different_output_size = $12
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Applies complex conformal mapping deformations. 
* **`Mapping` ($1)** (choice) : choix possibles => Custom Formula, Z, (z+1)/(z-1), Cos(z), Sin(z), Tan(z), Exp(z), Log(z), Dipole: 1/(4*z^2-1), Star: -5*(z^3/3-Z/4)/2
* **`Exponent (Real)` ($2)** (float) : défaut = **1**  (-16,16)
* **`Exponent (Imaginary)` ($3)** (float) : défaut = **0**  (-16,16)
* **`Zoom` ($4)** (float) : défaut = **0**  (-4,4)
* **`Angle` ($5)** (float) : défaut = **0**  (-180,180)
* **`Aspect Ratio` ($6)** (float) : défaut = **0**  (-1,1)
* **`X-Shift` ($7)** (float) : défaut = **0**  (-5,5)
* **`Y-Shift` ($8)** (float) : défaut = **0**  (-5,5)
* **`Boundary` ($9)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
* **`Anti-Aliasing` ($10)** (int) : défaut = **0**  (0,3)
* **`Specify Different Output Size` ($11)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2017/02/15.
