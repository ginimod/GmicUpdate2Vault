---
tags: [gmic, filter]
command: fx_boost_fade
---

# Filtre G'MIC : fx_boost_fade

## Structure de la commande
```text
fx_boost_fade:
    amplitude = $1
    chromaticity_from = $2
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Enhances/reduces color vibrance. 
* **`Amplitude` ($1)** (float) : défaut = **5**  (0,10)
* **`Chromaticity From` ($2)** (choice) : choix possibles => YCbCr, Lab
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2018/11/26.
