---
tags: [gmic, filter]
command: fft_tile
---

# Filtre G'MIC : fft_tile

## Structure de la commande
```text
fft_tile:
    threshold = $1
    tile_size = $2
    fast = $3
```
## Définition des variables
* **`Threshold` ($1)** (float) : défaut = **500**  (0,50000)
* **`Tile Size` ($2)** (int) : défaut = **128**  (16,256)
* **`Fast` ($3)** (bool) : par défaut = Faux (0)
(Note) : Author : Iain Fergusson.      Latest update : 2012/08/08
