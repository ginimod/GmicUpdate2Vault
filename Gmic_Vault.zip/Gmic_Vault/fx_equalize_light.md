---
tags: [gmic, filter]
command: fx_equalize_light
---

# Filtre G'MIC : fx_equalize_light

## Structure de la commande
```text
fx_equalize_light:
    amount = $1
    mode = $2
    channel_s = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Balances uneven lighting across the image. 
* **`Amount (%)` ($1)** (float) : défaut = **75**  (0,100)
* **`Mode` ($2)** (choice) : choix possibles => Preserve Range, Preserve Covariance
* **`Channel(s)` ($3)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2021/03/23.
