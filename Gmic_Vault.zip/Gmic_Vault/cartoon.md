---
tags: [gmic, filter]
command: cartoon
---

# Filtre G'MIC : cartoon

## Structure de la commande
```text
cartoon:
    smoothness = $1
    sharpening = $2
    edge_threshold = $3
    edge_thickness = $4
    color_strength = $5
    color_quantization = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simplifies colors and adds black outlines for a comic book look. 
* **`Smoothness` ($1)** (float) : défaut = **3**  (0,10)
* **`Sharpening` ($2)** (float) : défaut = **200**  (0,400)
* **`Edge Threshold` ($3)** (float) : défaut = **20**  (1,30)
* **`Edge Thickness` ($4)** (float) : défaut = **0.25**  (0,1)
* **`Color Strength` ($5)** (float) : défaut = **1.5**  (0,3)
* **`Color Quantization` ($6)** (int) : défaut = **8**  (2,256)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
