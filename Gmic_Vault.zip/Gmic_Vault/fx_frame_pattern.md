---
tags: [gmic, filter]
command: fx_frame_pattern
---

# Filtre G'MIC : fx_frame_pattern

## Structure de la commande
```text
fx_frame_pattern:
    tiles = $1
    pattern = $2
    iterations = $3
    constrain_image_size = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds a frame generated from a repeating pattern. 
* **`Tiles` ($1)** (int) : défaut = **10**  (3,30)
* **`Pattern` ($2)** (choice) : choix possibles => Top Layer, Self Image
* **`Iterations` ($3)** (int) : défaut = **1**  (1,10)
* **`Constrain Image Size` ($4)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2014/08/01.
