---
tags: [gmic, filter]
command: fx_memoakten_algorithm_a
---

# Filtre G'MIC : fx_memoakten_algorithm_a

## Structure de la commande
```text
fx_memoakten_algorithm_a:
    random_seed = $1
    density_of_initial_points = $2
    rate_of_primary_segments = $3
    rate_of_secondary_segments = $4
    max_secondary_segments_occurrences = $5
    secondary_segments_centering_constraint = $6
    min_segment_length = $7
    max_segment_length = $8
    angle_constraint = $9
    line_thickness_px = $10
    density_of_color_fill = $11
    anti_aliasing = $12
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates abstract art based on Memo Akten's Algorithm A. 
* **`Random Seed` ($1)** (int) : défaut = **0**  (0,65535)
* **`Density of Initial Points (%)` ($2)** (float) : défaut = **20**  (0,100)
* **`Rate of Primary Segments (%)` ($3)** (float) : défaut = **60**  (0,100)
* **`Rate of Secondary Segments (%)` ($4)** (float) : défaut = **30**  (0,100)
* **`Max Secondary Segments Occurrences` ($5)** (int) : défaut = **2**  (1,16)
* **`Secondary Segments Centering Constraint (%)` ($6)** (float) : défaut = **50**  (0,100)
* **`Min Segment Length (%)` ($7)** (float) : défaut = **10**  (0,100)
* **`Max Segment Length (%)` ($8)** (float) : défaut = **50**  (0,100)
* **`Angle Constraint (%)` ($9)** (float) : défaut = **40**  (0,100)
* **`Line Thickness (px)` ($10)** (int) : défaut = **3**  (1,16)
* **`Density of Color Fill (%)` ($11)** (float) : défaut = **60**  (0,100)
* **`Anti-Aliasing` ($12)** (choice) : choix possibles => None, X1.5, X2
* **`Foreground Color` ($13)** (color) : défaut = 0,0,0
* **`Background Color` ($14)** (color) : défaut = 255,255,255
* **`Fill Color 1` ($15)** (color) : défaut = 255,0,0
* **`Fill Color 2` ($16)** (color) : défaut = 255,128,0
* **`Fill Color 3` ($17)** (color) : défaut = 255,255,0
* **`Fill Color 4` ($18)** (color) : défaut = 0,0,0
(Note) : Note: This filter has been implemented after reading the following tweet from Memo Akten:
(Note) : I (David) found the idea really nice so I tried to convert the algorithm into a G'MIC script. The code is not optimized and probably very perfectible, but at least it works :)
(Note) : Authors: <a href="https://www.memo.tv/">Memo Akten</a> (algorithm) and <a href="https://tschumperle.users.greyc.fr/">David Tschumperlé</a> (G'MIC conversion)       Latest Update: 2022/08/09.
