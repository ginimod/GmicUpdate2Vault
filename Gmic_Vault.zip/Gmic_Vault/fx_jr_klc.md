---
tags: [gmic, filter]
command: fx_jr_klc
---

# Filtre G'MIC : fx_jr_klc

## Structure de la commande
```text
fx_jr_klc:
    kaleidoscope_mirrors = $1
    mirror_rotation = $2
    m_rot_mode = $3
    result_rotation = $4
    r_rot_mode = $5
    mirror_offset_x = $6
    mirror_offset_y = $7
    centre_x = $8
    centre_y = $9
    slice_mode = $10
    layer_cake_density = $11
    angle = $12
    angle_mode = $13
    scale = $14
    anti_alias = $15
    interpolation = $16
    boundary = $17
```
## Définition des variables
* **`Kaleidoscope Mirrors` ($1)** (int) : défaut = **6**  (0,64)
* **`Mirror Rotation` ($2)** (float) : défaut = **0**  (-360,360)
* **`M-Rot Mode` ($3)** (choice) : choix possibles => Fixed Mirrors, Fixed Background
* **`Result Rotation` ($4)** (float) : défaut = **0**  (-360,360)
* **`R-Rot Mode` ($5)** (choice) : choix possibles => Full, Sector
* **`Mirror Offset (%)` ($6)** (point) : position = 0,0
* **`Centre (%)` ($7)** (point) : position = 0,0
* **`Slice Mode` ($8)** (choice) : choix possibles => Symmetric, Asymmetric, Reverse Asymmetric
* **`Layer Cake Density` ($9)** (float) : défaut = **30**  (0,100)
* **`Angle` ($10)** (float) : défaut = **0**  (-1440,1440)
* **`Angle Mode` ($11)** (choice) : choix possibles => Layer, Density, Sector, Density & Sector
* **`Scale (%)` ($12)** (float) : défaut = **100**  (0,1000)
* **`Anti-Alias` ($13)** (float) : défaut = **1**  (0,2)
* **`Interpolation` ($14)** (choice) : choix possibles => None, Linear, Bicubic
* **`Boundary` ($15)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
