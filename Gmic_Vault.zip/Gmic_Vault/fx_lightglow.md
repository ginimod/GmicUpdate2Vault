---
tags: [gmic, filter]
command: fx_lightglow
---

# Filtre G'MIC : fx_lightglow

## Structure de la commande
```text
fx_lightglow:
    density = $1
    amplitude = $2
    mode = $3
    opacity = $4
    channel_s = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds a soft glowing light effect. 
* **`Density` ($1)** (float) : défaut = **30**  (0,100)
* **`Amplitude` ($2)** (float) : défaut = **0.5**  (0,2)
* **`Mode` ($3)** (choice) : choix possibles => Burn, Dodge, Freeze, Grain Merge, Hard Light, Interpolation, Lighten, Multiply, Overlay, Reflect, Soft Light, Stamp, Value
* **`Opacity` ($4)** (float) : défaut = **0.8**  (0,1)
* **`Channel(s)` ($5)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2011/02/21.
