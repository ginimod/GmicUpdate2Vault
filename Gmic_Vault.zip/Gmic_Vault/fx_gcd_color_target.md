---
tags: [gmic, filter]
command: fx_gcd_color_target
---

# Filtre G'MIC : fx_gcd_color_target

## Structure de la commande
```text
fx_gcd_color_target:
    coordinates_x = $1
    coordinates_y = $2
    chromacity_range = $6
```
## Définition des variables
(Note) : Use color curves to make the selected point match the target
* **`Coordinates` ($1)** (point) : position = 0,0
* **`Target Color` ($2)** (color) : défaut = 175,175,175
* **`Chromacity Range` ($3)** (choice) : choix possibles => Global, Wide, Narrow
(Note) : Author : Garagecoder.      Latest update : 2022/06/15.
(Note) : 
<u>Notes</u>
(Note) : Set the target to the desired color for the spot you selected.
(Note) : Reduce chromacity range to limit the affected regions.
(Note) : sRGB D65 input is assumed.
