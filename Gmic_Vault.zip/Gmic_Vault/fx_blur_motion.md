---
tags: [gmic, filter]
command: fx_blur_motion
---

# Filtre G'MIC : fx_blur_motion

## Structure de la commande
```text
fx_blur_motion:
    mode = $1
    strength = $2
    control_points = $3
    point0_x = $5
    point0_y = $6
    point1_x = $7
    point1_y = $8
    point2_x = $9
    point2_y = $10
    point3_x = $11
    point3_y = $12
    point4_x = $13
    point4_y = $14
    centering = $15
    weight_decay = $16
    subsampling = $17
    boundary = $18
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates motion blur. 
* **`Mode` ($1)** (choice) : choix possibles => Average, Max (Slower)
* **`Strength` ($2)** (float) : défaut = **1**  (0,5)
* **`Control Points` ($3)** (choice) : choix possibles => 3, 4, 5
* **`Point0` ($4)** (point) : position = 0,0
* **`Point1` ($5)** (point) : position = 0,0
* **`Point2` ($6)** (point) : position = 0,0
* **`Point3` ($7)** (point) : position = 0,0
* **`Point4` ($8)** (point) : position = 0,0
* **`Centering` ($9)** (bool) : par défaut = Faux (0)
* **`Weight Decay (%)` ($10)** (float) : défaut = **75**  (0,100)
* **`Subsampling` ($11)** (int) : défaut = **0**  (0,20)
(Note) : Set Subsampling to 0 to disable subsampling.
* **`Boundary` ($12)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2024/04/02.
