---
tags: [gmic, filter]
command: fx_jpeg_artefacts
---

# Filtre G'MIC : fx_jpeg_artefacts

## Structure de la commande
```text
fx_jpeg_artefacts:
    quality = $1
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates JPEG compression blocks and noise. 
(Note) : This filter simulates the JPEG compression artifacts, using DCT quantization on 8x8 blocks.
* **`Quality (%)` ($1)** (int) : défaut = **50**  (1,100)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2024/02/21.
