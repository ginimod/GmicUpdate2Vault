---
tags: [gmic, filter]
command: fx_paint_with_brush
---

# Filtre G'MIC : fx_paint_with_brush

## Structure de la commande
```text
fx_paint_with_brush:
    predefined_style = $1
    painting_order = $3
    number_of_iterations = $4
    precision = $5
    details = $6
    background = $7
    sharpness = $8
    anisotropy = $9
    smoothness = $10
    coherence = $11
    twist_angle_deg = $12
    twist_strength = $13
    init_canvas = $14
    brush_diameter_px = $15
    stroke_length_px = $16
    hue_randomness = $17
    saturation_randomness = $18
    value_randomness = $19
    opacity = $20
    brush_diameter_px = $21
    stroke_length_px = $22
    hue_randomness = $23
    saturation_randomness = $24
    value_randomness = $25
    opacity = $26
    brush_diameter = $27
    stroke_length = $28
    hue_randomness = $29
    saturation_randomness = $30
    value_randomness = $31
    opacity = $32
    spatial_step = $33
    angular_step_deg = $34
    preview_progression_while_running = $35
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Repaints the image using a virtual brush. 
* **`Predefined Style` ($1)** (choice) : choix possibles => Default, Felt Spots, Colored Edges, Circles, Dreamy, Fuzzy, Whirls, Smooth
(Note) : <span color="#EE5500">Global Settings:</span>
* **`Painting Order` ($2)** (choice) : choix possibles => Random, Coarse to Fine, Fine to Coarse
* **`Number of Iterations` ($3)** (int) : défaut = **16**  (1,128)
* **`Precision (%)` ($4)** (float) : défaut = **30**  (0,100)
* **`Details (%)` ($5)** (float) : défaut = **100**  (0,100)
* **`Background (%)` ($6)** (float) : défaut = **100**  (0,100)
* **`Sharpness (%)` ($7)** (float) : défaut = **10**  (0,100)
* **`Anisotropy (%)` ($8)** (float) : défaut = **80**  (0,100)
* **`Smoothness` ($9)** (float) : défaut = **0.5**  (0,8)
* **`Coherence` ($10)** (float) : défaut = **3**  (0,16)
* **`Twist Angle (°)` ($11)** (int) : défaut = **45**  (-1,360)
(Note) : (-1 means 'Random Angle').
* **`Twist Strength (%)` ($12)** (int) : défaut = **0**  (-1,100)
(Note) : (-1: use automatic angle shift).
* **`Init Canvas` ($13)** (choice) : choix possibles => Black, Gray, White, Self, Blur, Kuwahara, Vector Painting
(Note) : <span color="#EE5500">Brush for Details:</span>
* **`Brush Diameter (px)` ($14)** (float) : défaut = **2**  (0,100)
* **`Stroke Length (px)` ($15)** (float) : défaut = **10**  (0,100)
* **`Hue Randomness (%)` ($16)** (float) : défaut = **0**  (0,100)
* **`Saturation Randomness (%)` ($17)** (float) : défaut = **0**  (0,100)
* **`Value Randomness (%)` ($18)** (float) : défaut = **0**  (0,100)
* **`Opacity (%)` ($19)** (float) : défaut = **60**  (0,100)
(Note) : <span color="#EE5500">Brush for Background:</span>
* **`Brush Diameter (px)` ($20)** (float) : défaut = **20**  (0,100)
* **`Stroke Length (px)` ($21)** (float) : défaut = **1**  (0,100)
* **`Hue Randomness (%)` ($22)** (float) : défaut = **0**  (0,100)
* **`Saturation Randomness (%)` ($23)** (float) : défaut = **0**  (0,100)
* **`Value Randomness (%)` ($24)** (float) : défaut = **0**  (0,100)
* **`Opacity (%)` ($25)** (float) : défaut = **30**  (0,100)
(Note) : <span color="#EE5500">Brush Dynamics:</span>
* **`Brush Diameter` ($26)** (float) : défaut = **15**  (0,255)
* **`Stroke Length` ($27)** (float) : défaut = **15**  (0,255)
* **`Hue Randomness` ($28)** (float) : défaut = **15**  (0,255)
* **`Saturation Randomness` ($29)** (float) : défaut = **15**  (0,255)
* **`Value Randomness` ($30)** (float) : défaut = **15**  (0,255)
* **`Opacity` ($31)** (float) : défaut = **15**  (0,255)
* **`Spatial Step` ($32)** (float) : défaut = **1**  (0,3)
* **`Angular Step (°)` ($33)** (float) : défaut = **45**  (0,90)
* **`Preview Progression While Running` ($34)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2021/08/30.
