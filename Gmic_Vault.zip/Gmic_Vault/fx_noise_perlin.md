---
tags: [gmic, filter]
command: fx_noise_perlin
---

# Filtre G'MIC : fx_noise_perlin

## Structure de la commande
```text
fx_noise_perlin:
    random_seed = $1
    amplitude = $2
    scale = $3
    x_y_ratio = $4
    amplitude = $5
    scale = $6
    x_y_ratio = $7
    amplitude = $8
    scale = $9
    x_y_ratio = $10
    amplitude = $11
    scale = $12
    x_y_ratio = $13
    channel_s = $14
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds Perlin (procedural) noise. 
* **`Random Seed` ($1)** (int) : défaut = **0**  (0,65536)
(Note) : 1st scale:
* **`Amplitude` ($2)** (float) : défaut = **100**  (0,512)
* **`Scale (%)` ($3)** (float) : défaut = **8**  (0,100)
* **`X/Y-Ratio` ($4)** (float) : défaut = **0**  (-4,4)
(Note) : 2nd scale:
* **`Amplitude` ($5)** (float) : défaut = **0**  (0,512)
* **`Scale (%)` ($6)** (float) : défaut = **4**  (0,100)
* **`X/Y-Ratio` ($7)** (float) : défaut = **0**  (-4,4)
(Note) : 3rd scale:
* **`Amplitude` ($8)** (float) : défaut = **0**  (0,512)
* **`Scale (%)` ($9)** (float) : défaut = **2**  (0,100)
* **`X/Y-Ratio` ($10)** (float) : défaut = **0**  (-4,4)
(Note) : 4th scale:
* **`Amplitude` ($11)** (float) : défaut = **0**  (0,512)
* **`Scale (%)` ($12)** (float) : défaut = **1**  (0,100)
* **`X/Y-Ratio` ($13)** (float) : défaut = **0**  (-4,4)
* **`Channel(s)` ($14)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2019/01/24.
