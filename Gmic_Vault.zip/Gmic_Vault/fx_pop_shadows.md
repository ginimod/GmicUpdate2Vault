---
tags: [gmic, filter]
command: fx_pop_shadows
---

# Filtre G'MIC : fx_pop_shadows

## Structure de la commande
```text
fx_pop_shadows:
    strength = $1
    scale = $2
    post_normalize = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Enhances the density and color of shadows. 
* **`Strength` ($1)** (float) : défaut = **0.75**  (0,1)
* **`Scale` ($2)** (float) : défaut = **5**  (0,20)
* **`Post-Normalize` ($3)** (bool) : par défaut = Faux (0)
(Note) : Authors: Morgan Hardwood and <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.       Latest Update: 2017/03/05.
