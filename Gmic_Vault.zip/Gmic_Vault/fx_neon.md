---
tags: [gmic, filter]
command: fx_neon
---

# Filtre G'MIC : fx_neon

## Structure de la commande
```text
fx_neon:
    1_norm_mode = $1
    2_thinning = $2
    3_recovery = $3
    4_brightness = $4
    5_details = $5
    6_smoothness = $6
    7_contrast = $7
    8_min_threshold = $8
    9_max_threshold = $9
    10_negative = $10
    11_opacity_over_original = $11
    12_saturation = $12
    13_blur_colours = $13
    14_amplitude = $14
    15_edge_threshold = $15
    16_smoothness = $16
    17_size = $17
    18_intensity = $18
    19_darken = $19
    20_saturation = $20
    21_size = $21
    22_intensity = $22
    23_darken = $23
    24_saturation = $24
    25_size = $25
    26_intensity = $26
    27_smooth_hues = $27
    28_alpha = $28
    29_alpha_power = $29
    30_alpha_multiplier = $30
    31_preview_type = $31
    32_33_preview_split_x = $32
    32_33_preview_split_y = $33
```
## Définition des variables
(Note) : Turns bright image outlines into bright, neon-like lines.
(Note) : Lines
* **`1. Norm Mode` ($1)** (choice) : choix possibles => Gradient Norm, Hessian, Laplacian, Rotation-Invariant Gradient, Afre's Edge Algorithm
* **`2. Thinning` ($2)** (int) : défaut = **1**  (1,10)
* **`3. Recovery` ($3)** (float) : défaut = **1**  (.5,4)
* **`4. Brightness` ($4)** (float) : défaut = **1**  (.5,4)
* **`5. Details` ($5)** (float) : défaut = **1**  (.5,4)
* **`6. Smoothness` ($6)** (float) : défaut = **0**  (0,10)
* **`7. Contrast` ($7)** (float) : défaut = **0.45**  (0,1.5)
* **`8. Min Threshold` ($8)** (float) : défaut = **40**  (0,100)
* **`9. Max Threshold` ($9)** (float) : défaut = **60**  (0,100)
* **`10. Negative` ($10)** (bool) : par défaut = Faux (0)
* **`11. Opacity Over Original` ($11)** (float) : défaut = **1**  (0,1)
* **`12. Saturation` ($12)** (float) : défaut = **1.15**  (0,4)
* **`13. Blur Colours` ($13)** (float) : défaut = **2**  (0,20)
(Note) : Antialias
* **`14. Amplitude` ($14)** (float) : défaut = **3**  (0,100)
* **`15. Edge Threshold (%)` ($15)** (float) : défaut = **0**  (0,100)
* **`16. Smoothness` ($16)** (float) : défaut = **3**  (0,5)
(Note) : Colour Glow 1
* **`17. Size` ($17)** (float) : défaut = **20**  (0,100)
* **`18. Intensity` ($18)** (float) : défaut = **0.4**  (0,3)
* **`19. Darken` ($19)** (float) : défaut = **0.1**  (0,1)
* **`20. Saturation` ($20)** (float) : défaut = **1.5**  (0,4)
(Note) : Colour Glow 2
* **`21. Size` ($21)** (float) : défaut = **5**  (0,100)
* **`22. Intensity` ($22)** (float) : défaut = **0.2**  (0,3)
* **`23. Darken` ($23)** (float) : défaut = **0.1**  (0,1)
* **`24. Saturation` ($24)** (float) : défaut = **1**  (0,4)
(Note) : Boost Glow
* **`25. Size` ($25)** (float) : défaut = **2**  (0,5)
* **`26. Intensity` ($26)** (float) : défaut = **1**  (0,3)
* **`27. Smooth Hues` ($27)** (float) : défaut = **0**  (0,20)
* **`28. Alpha` ($28)** (bool) : par défaut = Faux (0)
* **`29. Alpha Power` ($29)** (float) : défaut = **1**  (0,5)
* **`30. Alpha Multiplier` ($30)** (float) : défaut = **1**  (0,5)
* **`31. Preview Type` ($31)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`32-33. Preview Split` ($32)** (point) : position = 0,0
