---
tags: [gmic, filter]
command: fx_heightfield_warp
---

# Filtre G'MIC : fx_heightfield_warp

## Structure de la commande
```text
fx_heightfield_warp:
    type = $1
    factor = $3
    smoothnness = $4
    align_camera_center = $5
    focal_length = $6
    light_on_off_x = $7
    light_on_off_y = $8
    ambient_light = $9
    diffuse_shadows = $10
    diffuse_highlights = $11
    specular_light = $12
    specular_material = $13
    preview_grid_overlay = $14
    preview_resolution = $15
    center_x = $17
    center_y = $18
    size_angle_x = $19
    size_angle_y = $20
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Apply a geometric warp by projecting the image onto a 3D heightfield surface. 
(Note) : <span color="#EE5500">Heighfield Geometry:</span>
* **`Type` ($1)** (choice) : choix possibles => Custom, Sphere, Cylinder
* **`Factor (%)` ($2)** (float) : défaut = **100**  (-500,500)
* **`Smoothnness (%)` ($3)** (float) : défaut = **0**  (0,10)
(Note) : <span color="#EE5500">3D Parameters:</span>
* **`Align Camera Center` ($4)** (bool) : par défaut = Faux (0)
* **`Focal Length` ($5)** (float) : défaut = **1.5**  (0.5,10)
* **`Light On/Off` ($6)** (point) : position = 0,0
* **`Ambient Light (%)` ($7)** (float) : défaut = **50**  (0,100)
* **`Diffuse Shadows (%)` ($8)** (float) : défaut = **20**  (0,100)
* **`Diffuse Highlights (%)` ($9)** (float) : défaut = **20**  (0,100)
* **`Specular Light (%)` ($10)** (float) : défaut = **40**  (0,200)
* **`Specular Material` ($11)** (float) : défaut = **30**  (1,100)
* **`Preview Grid Overlay (%)` ($12)** (float) : défaut = **20**  (0,100)
* **`Preview Resolution` ($13)** (choice) : choix possibles => Full, Mid, Low
* **`Center` ($14)** (point) : position = 0,0
* **`Size / Angle` ($15)** (point) : position = 0,0
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2026/02/03.
