---
tags: [gmic, filter]
command: fx_imagegrid_hexagonal
---

# Filtre G'MIC : fx_imagegrid_hexagonal

## Structure de la commande
```text
fx_imagegrid_hexagonal:
    resolution = $1
    outline = $2
    anti_aliasing = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Converts the image into a pixelated hexagonal grid. 
* **`Resolution` ($1)** (int) : défaut = **32**  (1,128)
* **`Outline` ($2)** (float) : défaut = **0.1**  (0,0.5)
* **`Anti-Aliasing` ($3)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/01/12.
