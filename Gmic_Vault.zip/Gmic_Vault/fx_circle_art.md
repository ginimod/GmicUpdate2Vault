---
tags: [gmic, filter]
command: fx_circle_art
---

# Filtre G'MIC : fx_circle_art

## Structure de la commande
```text
fx_circle_art:
    type = $1
    density = $2
    radius = $3
    modulo = $4
    anti_aliasing = $5
    random_colors = $6
    curve_length = $7
    curve_angle = $8
    minimal_radius = $9
    maximal_radius = $10
    x_dispersion = $11
    y_dispersion = $12
    x_factor = $13
    y_factor = $14
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Abstract rendering of spiraled circles. 
* **`Type` ($1)** (choice) : choix possibles => Random, Lissajous Spiral
* **`Density` ($2)** (float) : défaut = **15**  (0,100)
* **`Radius` ($3)** (float) : défaut = **0.5**  (0,1)
* **`Modulo` ($4)** (int) : défaut = **8**  (2,16)
* **`Anti-Aliasing` ($5)** (bool) : par défaut = Faux (0)
* **`Random Colors` ($6)** (bool) : par défaut = Faux (0)
(Note) : Lissajous parameters:
* **`Curve Length` ($7)** (float) : défaut = **15**  (0,50)
* **`Curve Angle` ($8)** (float) : défaut = **0**  (0,360)
* **`Minimal Radius` ($9)** (float) : défaut = **0**  (-5,5)
* **`Maximal Radius` ($10)** (float) : défaut = **0.5**  (-5,5)
* **`X-Dispersion` ($11)** (float) : défaut = **1**  (0,4)
* **`Y-Dispersion` ($12)** (float) : défaut = **1**  (0,4)
* **`X-Factor` ($13)** (int) : défaut = **1**  (0,16)
* **`Y-Factor` ($14)** (int) : défaut = **1**  (0,16)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2014/08/22.
