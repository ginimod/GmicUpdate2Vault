---
tags: [gmic, filter]
command: fx_reflect
---

# Filtre G'MIC : fx_reflect

## Structure de la commande
```text
fx_reflect:
    height = $1
    attenuation = $2
    waves_amplitude = $7
    waves_smoothness = $8
    x_angle = $9
    y_angle = $10
    focal_length = $11
    zoom = $12
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds a water reflection effect. 
* **`Height` ($1)** (float) : défaut = **50**  (0,100)
* **`Attenuation` ($2)** (float) : défaut = **1**  (0.1,4)
* **`Color` ($3)** (color) : défaut = 110,160,190,64
* **`Waves Amplitude` ($4)** (float) : défaut = **0**  (0,100)
* **`Waves Smoothness` ($5)** (float) : défaut = **1.5**  (0,4)
* **`X-Angle` ($6)** (float) : défaut = **0**  (-10,10)
* **`Y-Angle` ($7)** (float) : défaut = **-3.30**  (-10,10)
* **`Focal Length` ($8)** (float) : défaut = **7**  (0,10)
* **`Zoom` ($9)** (float) : défaut = **1.5**  (1,5)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
