---
tags: [gmic, filter]
command: fx_gcd_crt
---

# Filtre G'MIC : fx_gcd_crt

## Structure de la commande
```text
fx_gcd_crt:
    horizontal_blur = $1
    vertical_blur = $2
    screen_border = $3
    equalize = $4
```
## Définition des variables
(Note) : Cathode ray tube sub-pixel rendering filter
* **`Horizontal Blur` ($1)** (float) : défaut = **1.8**  (0,5)
* **`Vertical Blur` ($2)** (float) : défaut = **1.8**  (0,5)
* **`Screen Border` ($3)** (bool) : par défaut = Faux (0)
* **`Equalize` ($4)** (bool) : par défaut = Faux (0)
(Note) : Author : Garagecoder.      Latest update : 2014/12/11.
