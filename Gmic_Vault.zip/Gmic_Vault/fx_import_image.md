---
tags: [gmic, filter]
command: fx_import_image
---

# Filtre G'MIC : fx_import_image

## Structure de la commande
```text
fx_import_image:
    normalize = $2
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Imports raw data or specific file formats. 
* **`Normalize` ($1)** (bool) : par défaut = Faux (0)
(Note) : 
Note:  This filter can import any image data read by the G'MIC language interpreter. It includes exotic formats as : Pandore, CImg, Inrimage, AVI/MPEG (requires FFMPEG installed), ... 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
