---
tags: [gmic, filter]
command: fx_blocks3d
---

# Filtre G'MIC : fx_blocks3d

## Structure de la commande
```text
fx_blocks3d:
    resolution = $1
    smoothness = $2
    elevation = $3
    size = $4
    angle = $5
    tilt = $6
    fov = $7
    centering_x = $8
    centering_y = $9
    x_light = $10
    y_light = $11
    z_light = $12
    specular_lightness = $13
    specular_shininess = $14
    use_light = $15
    antialiasing = $16
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Renders a field of 3D blocks based on image brightness. 
* **`Resolution` ($1)** (int) : défaut = **32**  (1,128)
* **`Smoothness` ($2)** (float) : défaut = **0**  (0,40)
* **`Elevation` ($3)** (float) : défaut = **4**  (-10,10)
* **`Size` ($4)** (float) : défaut = **1.5**  (0,3)
* **`Angle` ($5)** (float) : défaut = **30**  (0,360)
* **`Tilt` ($6)** (float) : défaut = **60**  (0,90)
* **`FOV` ($7)** (float) : défaut = **45**  (1,90)
* **`Centering (%)` ($8)** (point) : position = 0,0
* **`X-Light` ($9)** (float) : défaut = **0**  (-100,100)
* **`Y-Light` ($10)** (float) : défaut = **-50**  (-100,100)
* **`Z-Light` ($11)** (float) : défaut = **-100**  (-100,0)
* **`Specular Lightness` ($12)** (float) : défaut = **0.5**  (0,1)
* **`Specular Shininess` ($13)** (float) : défaut = **0.7**  (0,3)
* **`Use Light` ($14)** (bool) : par défaut = Faux (0)
* **`Antialiasing` ($15)** (bool) : par défaut = Faux (0)
* **`Outline Color` ($16)** (color) : défaut = 0,0,0,128
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2014/02/10.
