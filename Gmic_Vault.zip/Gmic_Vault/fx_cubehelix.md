---
tags: [gmic, filter]
command: fx_cubehelix
---

# Filtre G'MIC : fx_cubehelix

## Structure de la commande
```text
fx_cubehelix:
    pre_greyscale = $1
    min_threshold = $2
    max_threshold = $3
    pre_normalise = $4
    start_hue = $11
    rotations = $12
    rotation_bend = $13
    saturation_bend = $14
    saturation_start = $15
    saturation_end = $16
    gamma_bend = $17
    gamma_start = $18
    gamma_end = $19
    scale_colour_variations = $20
    red_amplitude = $21
    red_phase_shift = $22
    green_amplitude = $23
    green_phase_shift = $24
    blue_amplitude = $25
    blue_phase_shift = $26
    preview_colour_scheme = $27
    preview_type = $28
    preview_split_x = $29
    preview_split_y = $30
```
## Définition des variables
(Note) : Implements and extends <a href="https://www.mrao.cam.ac.uk/~dag/CUBEHELIX/">the CubeHelix family of colour schemes</a>, allowing for interpolation between two colours as well as scaling the helix dimensions for each individual channel based on those colours.
* **`Pre-Greyscale` ($1)** (choice) : choix possibles => Off, Luminance, SRGB Mean
* **`Min Threshold` ($2)** (float) : défaut = **0**  (0,100)
* **`Max Threshold` ($3)** (float) : défaut = **100**  (0,100)
* **`Pre-Normalise` ($4)** (bool) : par défaut = Faux (0)
* **`Start Colour` ($5)** (color) : défaut = 0,0,0
* **`End Colour` ($6)** (color) : défaut = 255,255,255
* **`Start Hue` ($7)** (float) : défaut = **1**  (0,3)
* **`Rotations` ($8)** (float) : défaut = **-1.5**  (-20,20)
* **`Rotation Bend` ($9)** (float) : défaut = **0**  (-3,3)
* **`Saturation Bend` ($10)** (float) : défaut = **0**  (-3,3)
* **`Saturation Start` ($11)** (float) : défaut = **1**  (0,5)
* **`Saturation End` ($12)** (float) : défaut = **1**  (0,5)
* **`Gamma Bend` ($13)** (float) : défaut = **0**  (-3,3)
* **`Gamma Start` ($14)** (float) : défaut = **0**  (0,1)
* **`Gamma End` ($15)** (float) : défaut = **1**  (0,1)
* **`Scale Colour Variations` ($16)** (float) : défaut = **1**  (-4,4)
(Note) : Scales the colour variations to reflect the difference between the start and end colours. For example, a value of 0 when going from black to yellow will flatten the helix so that only the red and green channels vary.
* **`Red Amplitude` ($17)** (float) : défaut = **1**  (0,4.00000)
* **`Red Phase Shift` ($18)** (float) : défaut = **0**  (0,360)
* **`Green Amplitude` ($19)** (float) : défaut = **1**  (0,4.00000)
* **`Green Phase Shift` ($20)** (float) : défaut = **0**  (0,360)
* **`Blue Amplitude` ($21)** (float) : défaut = **1**  (0,4.00000)
* **`Blue Phase Shift` ($22)** (float) : défaut = **0**  (0,360)
* **`Preview Colour Scheme` ($23)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($24)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($25)** (point) : position = 0,0
