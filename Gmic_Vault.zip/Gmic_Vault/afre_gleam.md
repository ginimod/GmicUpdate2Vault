---
tags: [gmic, filter]
command: afre_gleam
---

# Filtre G'MIC : afre_gleam

## Structure de la commande
```text
afre_gleam:
    smooth = $1
    threshold = $2
```
## Définition des variables
(Note) : <strong>Add gleam effect.</strong>  Hint: Try different combinations of smooth and threshold.  <strong>Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2019.</strong>

 * Experimental filter.


* **`Smooth` ($1)** (int) : défaut = **3**  (2,100)
* **`Threshold` ($2)** (int) : défaut = **50**  (10,90)
