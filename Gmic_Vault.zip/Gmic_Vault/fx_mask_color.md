---
tags: [gmic, filter]
command: fx_mask_color
---

# Filtre G'MIC : fx_mask_color

## Structure de la commande
```text
fx_mask_color:
    color_metric = $1
    spatial_tolerance = $2
    color_tolerance = $3
    output_mode = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Interactively selects a specific color range to create a mask. 
* **`Color Metric` ($1)** (choice) : choix possibles => RGB [All], RGB [Red], RGB [Green], RGB [Blue], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [red Chrominance], YCbCr [green Chrominance], Lab [all], Lab [lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [all], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [all], HSV [hue], HSV [saturation], HSV [value], HSI [all], HSI [intensity], HSL [all], HSL [lightness], CMYK [cyan], CMYK [magenta], CMYK [yellow], CMYK [key], YIQ [luma], YIQ [chromas]
* **`Spatial Tolerance` ($2)** (float) : défaut = **10**  (0,100)
* **`Color Tolerance` ($3)** (float) : défaut = **5**  (0,100)
* **`Output Mode` ($4)** (choice) : choix possibles => Masked Image, Color Mask
(Note) : Note: This filter is CPU consuming, so use it at least with 4+ cores (or reduce the size of the interactive window to speed up computation).
(Note) : Interactions:
 Use the following actions in the interactive window to build your color mask:

 - Left mouse button marks the color pointed by the mouse wanted for the mask.
 - Right mouse button marks the color pointed by the mouse unwanted for the mask.
 - Middle mouse button or key R resets color mask.
 - Key SPACE or TAB toggles view modes (half/full-masked RGB or color mask).
 - Keys CTRL+D increase window size.
 - Keys CTRL+C decrease window size.
 - Keys CTRL+R resets window size.
 - Keys ESC, Q or RETURN exit the interactive window. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 01/20/2017.
