---
tags: [gmic, filter]
command: fx_intarsia
---

# Filtre G'MIC : fx_intarsia

## Structure de la commande
```text
fx_intarsia:
    maximum_image_size = $3
    maximum_number_of_image_colors = $4
    starting_point = $5
    loop_method = $6
    add_comment_area_in_html_page = $7
    preview_progress = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Converts the image into a knitting/intarsia notice. 
(Note) : Note: Intarsia is a method of Crochet/Knitting with a number of colors, in which a separate ball of yarn is used for each area of color. This filter creates a HTML version of a graph chart which is solely used for this purpose 
* **`Maximum Image Size` ($1)** (int) : défaut = **512**  (2,1024)
* **`Maximum Number of Image Colors` ($2)** (int) : défaut = **12**  (2,64)
* **`Starting Point` ($3)** (choice) : choix possibles => Top Left, Top Right, Bottom Left, Bottom Right
* **`Loop Method` ($4)** (choice) : choix possibles => Row by Row, Column by Column
* **`Add Comment Area in HTML Page` ($5)** (bool) : par défaut = Faux (0)
* **`Preview Progress (%)` ($6)** (float) : défaut = **100**  (0,100)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/07/09.
