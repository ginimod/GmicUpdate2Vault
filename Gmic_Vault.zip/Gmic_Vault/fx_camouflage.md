---
tags: [gmic, filter]
command: fx_camouflage
---

# Filtre G'MIC : fx_camouflage

## Structure de la commande
```text
fx_camouflage:
    scale = $1
    levels = $2
    coherence = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a military camouflage pattern. 
* **`Scale` ($1)** (int) : défaut = **9**  (2,12)
* **`Levels` ($2)** (int) : défaut = **12**  (2,32)
* **`Coherence` ($3)** (float) : défaut = **100**  (0,1000)
* **`Color 1` ($4)** (color) : défaut = 30,46,33
* **`Color 2` ($5)** (color) : défaut = 75,90,65
* **`Color 3` ($6)** (color) : défaut = 179,189,117
* **`Color 4` ($7)** (color) : défaut = 255,246,158
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/10/26.
