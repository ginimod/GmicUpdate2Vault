---
tags: [gmic, filter]
command: fx_buffer_destroyer
---

# Filtre G'MIC : fx_buffer_destroyer

## Structure de la commande
```text
fx_buffer_destroyer:
    1_alpha = $2
    2_width = $3
    3_height = $4
    4_buffer_selection_start = $5
    5_buffer_selection_length = $6
    6_buffer_selection_shift = $7
    7_repeat_buffer = $8
    8_randomised_start = $9
    9_channels = $10
    10_min_gap = $11
    11_max_gap = $12
    12_strength = $13
    13_order = $14
    14_axis = $15
    15_sorting_criterion = $16
    16_mask_by = $17
    17_lower_mask_threshold = $18
    18_higher_mask_threshold = $19
    19_mask_smoothness = $20
    20_invert_mask = $21
    21_preview_mask = $22
    22_channels = $23
    23_x_amplitude = $24
    24_x_iterations = $25
    25_y_amplitude = $26
    26_y_iterations = $27
    27_matrix_warp_multiplier = $28
    28_matrix_boundary = $29
    29_warp_boundary = $30
    30_inverse_of_be1 = $31
    31_width = $32
    32_height = $33
    33_buffer_selection_start = $34
    34_buffer_selection_length = $35
    35_buffer_selection_shift = $36
    36_repeat_buffer = $37
    preview_type = $38
    preview_split_x = $39
    preview_split_y = $40
```
## Définition des variables
(Note) : A preset combo of filters which rip images apart through simulated buffer manipulation and warping.
* **`1. Alpha` ($1)** (bool) : par défaut = Faux (0)
(Note) : Buffer Error 1
* **`2. Width` ($2)** (float) : défaut = **75**  (0,200)
* **`3. Height` ($3)** (float) : défaut = **40**  (0,200)
* **`4. Buffer Selection Start (%)` ($4)** (float) : défaut = **0**  (0,100)
* **`5. Buffer Selection Length (%)` ($5)** (float) : défaut = **100**  (0,400)
* **`6. Buffer Selection Shift (%)` ($6)** (float) : défaut = **0**  (0,100)
* **`7. Repeat Buffer` ($7)** (bool) : par défaut = Faux (0)
(Note) : Shredder
* **`8. Randomised Start` ($8)** (bool) : par défaut = Faux (0)
* **`9. Channels` ($9)** (choice) : choix possibles => Correlated, RGB, SRGB, CMY, RYB, Ohta8, Ohta, YES8, YES, Kodak 1-8, Kodak1, Lab8, Lab, Oklab, LUV, Jzazbz, YIQ8, YIQ, YUV8, YUV, YCbCr, YCbCrGLIC, YCbCrJPEG, YDbDr, XYZ8, XYZ, HSV8, HSV, HSL8, HSL, HSI8, HSI, LCH8, LCH, JzCzHz, HCY
* **`10. Min Gap` ($10)** (float) : défaut = **50**  (0,100)
* **`11. Max Gap` ($11)** (float) : défaut = **100**  (0,100)
* **`12. Strength` ($12)** (float) : défaut = **0.5**  (0,1)
(Note) : Pixel Sort
(Note) : Sorting parameters:
* **`13. Order` ($13)** (choice) : choix possibles => Decreasing, Increasing
* **`14. Axis` ($14)** (choice) : choix possibles => X-Axis, Y-Axis, X-Axis Then Y-Axis, Y-Axis Then X-Axis
* **`15. Sorting Criterion` ($15)** (choice) : choix possibles => Red, Green, Blue, Intensity, Luminance, Lightness, Hue, Saturation, Minimum, Maximum, Random
(Note) : Masking parameters:
* **`16. Mask By` ($16)** (choice) : choix possibles => Criterion, Contours, Random
* **`17. Lower Mask Threshold (%)` ($17)** (float) : défaut = **50**  (0,100)
* **`18. Higher Mask Threshold (%)` ($18)** (float) : défaut = **100**  (0,100)
* **`19. Mask Smoothness (%)` ($19)** (float) : défaut = **0**  (0,5)
* **`20. Invert Mask` ($20)** (bool) : par défaut = Faux (0)
* **`21. Preview Mask` ($21)** (bool) : par défaut = Faux (0)
(Note) : Shifter
(Note) : Amplitudes are cubed to tame the distortion a little bit.
* **`22. Channels` ($22)** (choice) : choix possibles => Correlated, RGB, SRGB, CMY, RYB, Ohta8, Ohta, YES8, YES, Kodak 1-8, Kodak1, Lab8, Lab, Oklab, LUV, Jzazbz, YIQ8, YIQ, YUV8, YUV, YCbCr, YCbCrGLIC, YCbCrJPEG, YDbDr, XYZ8, XYZ, HSV8, HSV, HSL8, HSL, HSI8, HSI, LCH8, LCH, JzCzHz, HCY
* **`23. X Amplitude` ($23)** (float) : défaut = **2.5**  (0,10)
* **`24. X Iterations` ($24)** (int) : défaut = **20**  (0,400)
* **`25. Y Amplitude` ($25)** (float) : défaut = **2.5**  (0,10)
* **`26. Y Iterations` ($26)** (int) : défaut = **20**  (0,400)
* **`27. Matrix Warp Multiplier` ($27)** (float) : défaut = **1**  (0,5)
* **`28. Matrix Boundary` ($28)** (choice) : choix possibles => Random, Random [non-Transparent], Transparent, Nearest, Periodic, Mirror
* **`29. Warp Boundary` ($29)** (choice) : choix possibles => Random, Random [non-Transparent], Transparent, Nearest, Periodic, Mirror
(Note) : Buffer Error 2
* **`30. Inverse Of BE1` ($30)** (bool) : par défaut = Faux (0)
* **`31. Width` ($31)** (float) : défaut = **120**  (0,200)
* **`32. Height` ($32)** (float) : défaut = **80**  (0,200)
* **`33. Buffer Selection Start (%)` ($33)** (float) : défaut = **0**  (0,100)
* **`34. Buffer Selection Length (%)` ($34)** (float) : défaut = **100**  (0,100)
* **`35. Buffer Selection Shift (%)` ($35)** (float) : défaut = **0**  (0,100)
* **`36. Repeat Buffer` ($36)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($37)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($38)** (point) : position = 0,0
