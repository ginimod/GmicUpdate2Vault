---
tags: [gmic, filter]
command: automixer
---

# Filtre G'MIC : automixer

## Structure de la commande
```text
automixer:
    output_colour_difference = $1
    use_partial_image_for_noise_calculation = $2
```
## Définition des variables
* **`Output Colour Difference` ($1)** (bool) : par défaut = Faux (0)
* **`Use Partial Image for Noise Calculation` ($2)** (bool) : par défaut = Faux (0)
(Note) : This filter creates a black and white mage with the most pleasant noise characteristics (IMHO). It measures the noise in each colour channel and scales each channel so that the noise levels are even and produces a greyscale output and optionally an extra image with the colour information.
(Note) : Author : Iain Fergusson.      Latest update : 2012/10/26
