---
tags: [gmic, filter]
command: fx_CompositionAnalysis
---

# Filtre G'MIC : fx_CompositionAnalysis

## Structure de la commande
```text
fx_CompositionAnalysis:
    method = $1
```
## Définition des variables
(Note) : A tool to abstract the image for subjective composition analysis. Two different methods are available. Set filter output to New layers. For actual analysis the aesthetic sense of the artist is required.
* **`Method` ($1)** (choice) : choix possibles => Thumbnail Abstraction, Value and Lines
(Note) : Author : Arto Huotari.      Latest update : 2015/01/17.
