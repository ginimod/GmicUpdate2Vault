---
tags: [gmic, filter]
command: fx_gradient_from_curve
---

# Filtre G'MIC : fx_gradient_from_curve

## Structure de la commande
```text
fx_gradient_from_curve:
    number_of_control_points = $1
    starting_point_x = $2
    starting_point_y = $3
    mid_point_1_x = $4
    mid_point_1_y = $5
    mid_point_2_x = $6
    mid_point_2_y = $7
    mid_point_3_x = $8
    mid_point_3_y = $9
    mid_point_4_x = $10
    mid_point_4_y = $11
    ending_point_x = $12
    ending_point_y = $13
    sampling = $14
    length = $15
    sort_colors = $16
    reverse_gradient = $17
    preview_gradient = $18
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Extract a color gradient that follows a curve. 
* **`Number of Control Points` ($1)** (int) : défaut = **2**  (2,6)
* **`Starting Point (%)` ($2)** (point) : position = 0,0
* **`Mid Point #1 (%)` ($3)** (point) : position = 0,0
* **`Mid Point #2 (%)` ($4)** (point) : position = 0,0
* **`Mid Point #3 (%)` ($5)** (point) : position = 0,0
* **`Mid Point #4 (%)` ($6)** (point) : position = 0,0
* **`Ending Point (%)` ($7)** (point) : position = 0,0
* **`Sampling (%)` ($8)** (float) : défaut = **100**  (0,100)
* **`Length` ($9)** (int) : défaut = **0**  (0,4096)
(Note) : Note: Set length to 0 to release gradient length constraints.
* **`Sort Colors` ($10)** (choice) : choix possibles => Don't Sort, By Red Component, By Green Component, By Blue Component, By Luminance, By Blue Chrominance, By Red Chrominance, By Lightness
* **`Reverse Gradient` ($11)** (bool) : par défaut = Faux (0)
* **`Preview Gradient` ($12)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2025/02/05.
