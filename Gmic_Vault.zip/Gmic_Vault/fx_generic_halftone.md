---
tags: [gmic, filter]
command: fx_generic_halftone
---

# Filtre G'MIC : fx_generic_halftone

## Structure de la commande
```text
fx_generic_halftone:
    background = $1
    base_shape = $2
    max_radius = $3
    smoothness = $4
    antialiasing = $5
    black_white = $6
    shape = $7
    layout = $8
    density = $9
    smoothness = $10
    angle = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> A versatile halftone generator with various shapes. 
(Note) : <span color="#EE5500">Global Settings:</span>
* **`Background` ($1)** (choice) : choix possibles => Black, White
* **`Base Shape` ($2)** (choice) : choix possibles => Square, Disc
* **`Max Radius (%)` ($3)** (float) : défaut = **100**  (0,300)
* **`Smoothness (%)` ($4)** (float) : défaut = **10**  (0,100)
* **`Antialiasing` ($5)** (choice) : choix possibles => None, X1.25, X1.5, X2, X2.5
* **`Black & White` ($6)** (bool) : par défaut = Faux (0)
(Note) : <span color="#EE5500">Halftoning Shape:</span>
* **`Shape` ($7)** (choice) : choix possibles => Custom (Top Layer), Dots, Lines, Self, Spiral
* **`Layout` ($8)** (choice) : choix possibles => Regular, Semi-Regular, Random
* **`Density (%)` ($9)** (float) : défaut = **75**  (0,100)
* **`Smoothness (%)` ($10)** (float) : défaut = **1**  (0,100)
* **`Angle` ($11)** (float) : défaut = **0**  (0,360)
(Note) : Note: When adding a top layer that defines a custom halftoning shape, it is recommended to use 1px wide strokes, for a better (and faster) result. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.       Latest Update: 2022/11/07.
