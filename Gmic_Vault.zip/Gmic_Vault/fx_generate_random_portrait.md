---
tags: [gmic, filter]
command: fx_generate_random_portrait
---

# Filtre G'MIC : fx_generate_random_portrait

## Structure de la commande
```text
fx_generate_random_portrait:
    resolution_px = $1
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a random face (StyleGAN). 
* **`Resolution (px)` ($1)** (int) : défaut = **800**  (0,2048)
(Note) : This filter loads data from the website:
(Note) : It means it doesn't perform any calculations on your machine and it requires an active Internet connection.
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.       Latest Update: 2022/04/14.
