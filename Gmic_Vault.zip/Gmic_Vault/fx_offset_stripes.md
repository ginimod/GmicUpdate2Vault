---
tags: [gmic, filter]
command: fx_offset_stripes
---

# Filtre G'MIC : fx_offset_stripes

## Structure de la commande
```text
fx_offset_stripes:
    iterations = $1
    random_seed = $2
    per_channel_shift = $3
    height = $4
    random_shift_amplitude = $5
    width = $6
    random_shift_amplitude = $7
    boundary = $8
    channel_s = $9
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Iteratively shifts horizontal/vertical stripes of the image. 
* **`Iterations` ($1)** (int) : défaut = **1**  (0,256)
* **`Random Seed` ($2)** (int) : défaut = **0**  (0,65535)
* **`Per-Channel Shift` ($3)** (bool) : par défaut = Faux (0)
(Note) : <span color="#EE5500">Horizontal Stripes:</span>
* **`Height (%)` ($4)** (float) : défaut = **10**  (0,100)
* **`Random Shift Amplitude (%)` ($5)** (float) : défaut = **20**  (0,100)
(Note) : <span color="#EE5500">Vertical Stripes:</span>
* **`Width (%)` ($6)** (float) : défaut = **10**  (0,100)
* **`Random Shift Amplitude (%)` ($7)** (float) : défaut = **20**  (0,100)
* **`Boundary` ($8)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
* **`Channel(s)` ($9)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2025/12/01.
