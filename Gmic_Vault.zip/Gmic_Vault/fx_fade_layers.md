---
tags: [gmic, filter]
command: fx_fade_layers
---

# Filtre G'MIC : fx_fade_layers

## Structure de la commande
```text
fx_fade_layers:
    inter_frames = $1
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Creates a transition opacity across multiple layers. 
* **`Inter-Frames` ($1)** (int) : défaut = **10**  (2,100)
(Note) : Note: This filter needs at least two layers to work properly. Set the Input layers option to handle multiple input layers. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2012/08/04.
