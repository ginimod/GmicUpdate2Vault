---
tags: [gmic, filter]
command: fx_breaks
---

# Filtre G'MIC : fx_breaks

## Structure de la commande
```text
fx_breaks:
    type = $1
    amplitude = $2
    frequency = $3
    smoothness = $4
    boundary = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Displaces image slices to create a "broken" glass effect. 
* **`Type` ($1)** (choice) : choix possibles => Flat, Relief
* **`Amplitude` ($2)** (float) : défaut = **30**  (0,300)
* **`Frequency (%)` ($3)** (float) : défaut = **30**  (0,100)
* **`Smoothness` ($4)** (float) : défaut = **0.5**  (0,10)
* **`Boundary` ($5)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2021/09/09.
