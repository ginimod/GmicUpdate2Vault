---
tags: [gmic, filter]
command: fx_gcd_blur_deblur_texture
---

# Filtre G'MIC : fx_gcd_blur_deblur_texture

## Structure de la commande
```text
fx_gcd_blur_deblur_texture:
    iters = $1
    sigma = $2
    edges = $3
    action = $4
    channels = $5
    percentage_sigma = $6
    preview_type = $7
    preview_split_x = $8
    preview_split_y = $9
```
## Définition des variables
(Note) : Variance-based edge preserving deblur or smooth
* **`Iters` ($1)** (int) : défaut = **4**  (1,20)
* **`Sigma` ($2)** (float) : défaut = **1**  (0,4)
* **`Edges` ($3)** (float) : défaut = **0.5**  (0,1)
* **`Action` ($4)** (choice) : choix possibles => Deblur, Smooth
* **`Channels` ($5)** (choice) : choix possibles => RGB, Linear RGB, Luma, Chroma
* **`Percentage Sigma` ($6)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($7)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($8)** (point) : position = 0,0
(Note) : Author : Garagecoder.      Latest update : 2018/09/02.
(Note) : 
<u>Notes</u>
(Note) : Iters: overall amount, increases computation time.
(Note) : Sigma: detail scale.
(Note) : Edges: amount of edge preservation.
(Note) : Percentage sigma: make detail scale relative to image size.
