---
tags: [gmic, filter]
command: Annular_Steiner_Chain_Round_Tile
---

# Filtre G'MIC : Annular_Steiner_Chain_Round_Tile

## Structure de la commande
```text
Annular_Steiner_Chain_Round_Tile:
    dimension_en_pixels = $1
    supprimer_calque_delete_layer = $2
    position_x_origine = $3
    position_y_origine = $4
    dimension = $5
    angle_decalage_image_contour = $6
    image_contour_dimension = $7
    nb_cercles_exterieurs_circles_surrounding = $8
    angle_inclinaison_tilt = $9
    activer_couleurs_formes = $10
    affichage_display_contours = $15
    couleurs_aleatoires_random_colors = $24
```
## Définition des variables
(Note) : <span foreground="orangered">Annular Steiner Chain Round Tiles</span>
(Note) : <span foreground="orangered">Image Finale</span>
* **`Dimension En Pixels` ($1)** (int) : défaut = **800**  (256,1920)
* **`Supprimer Calque / Delete Layer` ($2)** (bool) : par défaut = Faux (0)
(Note) : <span foreground="orangered">Image</span>
* **`Position X Origine (%)` ($3)** (float) : défaut = **0**  (0,100)
* **`Position Y Origine (%)` ($4)** (float) : défaut = **0**  (0,100)
* **`Dimension (%)` ($5)** (float) : défaut = **100**  (1,100)
* **`Angle Décalage Image Contour` ($6)** (float) : défaut = **0**  (0,360)
* **`Image Contour Dimension` ($7)** (float) : défaut = **100**  (1,100)
* **`Nb Cercles Extérieurs / Circles Surrounding` ($8)** (int) : défaut = **12**  (3,180)
* **`Angle Inclinaison / Tilt` ($9)** (float) : défaut = **0**  (0,360)
(Note) : <span foreground="orangered">Couleurs Formes</span>
* **`Activer Couleurs Formes` ($10)** (bool) : par défaut = Faux (0)
* **`Contours` ($11)** (color) : défaut = 0,0,0,255
* **`Affichage / Display Contours` ($12)** (choice) : choix possibles => Sans, A, B, C, D, E, F, G
* **`Cercle / Circle C` ($13)** (color) : défaut = 255,255,0,127
* **`Cercle / Circle D` ($14)** (color) : défaut = 0,0,255,127
* **`Couleurs Aléatoires / Random Colors` ($15)** (bool) : par défaut = Faux (0)
(Note) : samj - Dernière mise à jour : 2020/10/24.
