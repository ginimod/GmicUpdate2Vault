---
tags: [gmic, filter]
command: fx_crazy_texture
---

# Filtre G'MIC : fx_crazy_texture

## Structure de la commande
```text
fx_crazy_texture:
    1_radius = $2
    2_max_sampling_attempts = $3
    3_smoothness = $4
    4_threshold = $5
    5_scale = $6
    6_thickness = $7
    7_negative_colors = $8
    8_strength = $9
    9_interpolation = $10
    10_matrix_density = $11
    11_matrix_interpolation = $12
    12_matrix_contrast = $13
    13_strength = $14
    14_interpolation = $15
    15_matrix_density = $16
    16_matrix_interpolation = $17
    17_matrix_contrast = $18
    18_accurate_boundaries = $19
    19_crop_strength = $20
```
## Définition des variables
(Note) : Generates black and white textures using deformed edge offsets applied to Poisson-disk noise. The textures can range from smoothly-deformed and trippy to gnarled and wood-like.
(Note) : Poisson-Disk Noise
* **`1. Radius` ($1)** (float) : défaut = **75**  (1,1000)
* **`2. Max Sampling Attempts` ($2)** (int) : défaut = **30**  (1,200)
(Note) : Edge Offsets
* **`3. Smoothness` ($3)** (float) : défaut = **0**  (0,10)
* **`4. Threshold` ($4)** (float) : défaut = **15**  (0,50)
* **`5. Scale` ($5)** (int) : défaut = **6**  (0,64)
* **`6. Thickness` ($6)** (int) : défaut = **3**  (0,32)
* **`7. Negative Colors` ($7)** (bool) : par défaut = Faux (0)
(Note) : Deform 1
(Note) : Set matrix density to 1 for automatic size (coarse)
* **`8. Strength` ($8)** (float) : défaut = **15**  (0,30)
* **`9. Interpolation` ($9)** (choice) : choix possibles => None, Bilinear, Bicubic
* **`10. Matrix Density (%)` ($10)** (float) : défaut = **1**  (1,100)
* **`11. Matrix Interpolation (%)` ($11)** (choice) : choix possibles => Bilinear, Bicubic
* **`12. Matrix Contrast` ($12)** (float) : défaut = **0**  (-100,100)
(Note) : Deform 2
(Note) : Set matrix density to 1 for automatic size (fine)
* **`13. Strength` ($13)** (float) : défaut = **1.5**  (0,30)
* **`14. Interpolation` ($14)** (choice) : choix possibles => None, Bilinear, Bicubic
* **`15. Matrix Density (%)` ($15)** (float) : défaut = **1**  (1,100)
* **`16. Matrix Interpolation (%)` ($16)** (choice) : choix possibles => Bilinear, Bicubic
* **`17. Matrix Contrast` ($17)** (float) : défaut = **0**  (-100,100)
(Note) : This can slow things down a lot if both deform strengths are high!
* **`18. Accurate Boundaries` ($18)** (bool) : par défaut = Faux (0)
* **`19. Crop Strength` ($19)** (float) : défaut = **1**  (0,1)
