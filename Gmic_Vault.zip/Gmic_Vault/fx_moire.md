---
tags: [gmic, filter]
command: fx_moire
---

# Filtre G'MIC : fx_moire

## Structure de la commande
```text
fx_moire:
    stripe_orientation = $1
    input_transparency = $2
    output_format = $3
    auto_reduce_number_of_frames = $4
    landscape = $5
    margin = $6
    print_frame_numbers = $7
    size_of_frame_numbers = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Convert an animation to a single image showing Moiré patterns. 
* **`Stripe Orientation` ($1)** (choice) : choix possibles => Horizontal, Vertical
* **`Input Transparency` ($2)** (choice) : choix possibles => Replace With White, Reconstruct From Previous Frames
* **`Output Format` ($3)** (choice) : choix possibles => Same as Input, A4 / 75 PPI, A4 / 100 PPI (Recommended), A4 / 150 PPI, A4 / 300 PPI
* **`Auto-Reduce Number of Frames` ($4)** (bool) : par défaut = Faux (0)
* **`Landscape` ($5)** (bool) : par défaut = Faux (0)
* **`Margin (%)` ($6)** (float) : défaut = **2**  (0,30)
* **`Print Frame Numbers` ($7)** (choice) : choix possibles => Disable, Top Left, Top Right, Bottom Left, Bottom Right
* **`Size of Frame Numbers (%)` ($8)** (float) : défaut = **5**  (0,30)
(Note) : <span color="#EE5500">Instructions:</span>

 This filter renders Moire Animations, as shown on <a href="https://www.youtube.com/watch?v=f5plDb_JRq4">this video</a>.
 To make the animation visible:

 &bull; Before running the filter, ensure that all frames are aligned and have the same size (and preferably without alpha)!
 &bull; Run the filter. It is recommended to keep the number of frames &lt;=6.
 &bull; Print the first layer (merged frames) on a A4 blank paper, at 300 PPI.
 &bull; Print the second layer (mask) on a A4 transparent sheet, at 300 PPI.
 &bull; Drag the transparent layer over the A4 paper to render the animation effect. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2020/03/02.
