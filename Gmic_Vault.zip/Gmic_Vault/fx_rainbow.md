---
tags: [gmic, filter]
command: fx_rainbow
---

# Filtre G'MIC : fx_rainbow

## Structure de la commande
```text
fx_rainbow:
    left_position = $1
    right_position = $2
    left_slope = $3
    right_slope = $4
    thinness = $5
    opacity = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Draws a rainbow arc. 
* **`Left Position` ($1)** (float) : défaut = **80**  (0,100)
* **`Right Position` ($2)** (float) : défaut = **80**  (0,100)
* **`Left Slope` ($3)** (float) : défaut = **175**  (0,400)
* **`Right Slope` ($4)** (float) : défaut = **175**  (0,400)
* **`Thinness` ($5)** (float) : défaut = **3**  (0.1,8)
* **`Opacity` ($6)** (float) : défaut = **80**  (0,199)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
