---
tags: [gmic, filter]
command: afre_sharpenfft
---

# Filtre G'MIC : afre_sharpenfft

## Structure de la commande
```text
afre_sharpenfft:
    strength = $1
    size = $2
```
## Définition des variables
(Note) : <strong>Sharpen with Fourier transform.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2019-2020 Jan18.</strong>


* **`Strength` ($1)** (int) : défaut = **15**  (1,50)
* **`Size` ($2)** (int) : défaut = **1**  (1,10)
