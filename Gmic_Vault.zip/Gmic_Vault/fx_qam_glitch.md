---
tags: [gmic, filter]
command: fx_qam_glitch
---

# Filtre G'MIC : fx_qam_glitch

## Structure de la commande
```text
fx_qam_glitch:
    1_amplitude = $1
    2_period = $2
    3_phase_offset = $3
    4_angle = $4
    5_amplitude_offset = $5
    6_wave_offset = $6
    7_colour_space = $7
    8_channel_0 = $8
    9_channel_1 = $9
    10_channel_2 = $10
    11_alpha = $11
    12_glitch_negation = $12
    13_amplitude = $13
    14_bandwidth = $14
    15_shape = $15
    16_angle_offset = $16
    17_offset = $17
    18_blur = $18
    19_amplitude_modulation = $19
    20_phase_modulation = $20
    21_23_preview_type = $21
    preview_split_x = $22
    preview_split_y = $23
```
## Définition des variables
(Note) : Tries to emulate the effect of a faulty Quadrature Amplitude Modulator.
(Note) : Channel Modulation
* **`1. Amplitude` ($1)** (float) : défaut = **2**  (0,10)
* **`2. Period` ($2)** (float) : défaut = **20**  (0,100)
* **`3. Phase Offset` ($3)** (float) : défaut = **0**  (-180,180)
* **`4. Angle` ($4)** (float) : défaut = **0**  (-180,180)
* **`5. Amplitude Offset` ($5)** (float) : défaut = **1**  (-10,10)
* **`6. Wave Offset` ($6)** (float) : défaut = **127.5**  (0,255)
* **`7. Colour Space` ($7)** (choice) : choix possibles => RGBA, SRGBA, HSVA8, HSVA, HSLA8, HSLA, HSIA8, HSIA, LCHA8, LCHA, LabA8, LabA, YCbCrA, YCbCrAGLIC, YCbCrAJPEG, YIQA8, YIQA, YUVA8, YUVA, HCYA, XYZA8, XYZA, RYBA, CMYA
* **`8. Channel 0` ($8)** (bool) : par défaut = Faux (0)
* **`9. Channel 1` ($9)** (bool) : par défaut = Faux (0)
* **`10. Channel 2` ($10)** (bool) : par défaut = Faux (0)
* **`11. Alpha` ($11)** (bool) : par défaut = Faux (0)
* **`12. Glitch Negation` ($12)** (bool) : par défaut = Faux (0)
(Note) : Scanlines
* **`13. Amplitude` ($13)** (float) : défaut = **20**  (0,255)
* **`14. Bandwidth` ($14)** (float) : défaut = **5**  (0,20)
* **`15. Shape` ($15)** (choice) : choix possibles => Bloc, Triangle, Sine, Sine+, Random
* **`16. Angle Offset` ($16)** (float) : défaut = **0**  (-180,180)
* **`17. Offset` ($17)** (float) : défaut = **0**  (0,500)
* **`18. Blur` ($18)** (float) : défaut = **2**  (0,10)
* **`19. Amplitude Modulation` ($19)** (float) : défaut = **0.6**  (0,1)
* **`20. Phase Modulation` ($20)** (float) : défaut = **0.05**  (0,1)
* **`21-23. Preview Type` ($21)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($22)** (point) : position = 0,0
