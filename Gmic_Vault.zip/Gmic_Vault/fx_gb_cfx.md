---
tags: [gmic, filter]
command: fx_gb_cfx
---

# Filtre G'MIC : fx_gb_cfx

## Structure de la commande
```text
fx_gb_cfx:
    grain = $1
    noon_for_midnight = $2
    genekelly = $3
    rayharryhausen = $4
    carygrant = $5
    preview_type = $6
```
## Définition des variables
* **`Grain` ($1)** (float) : défaut = **10**  (0,25)
* **`Noon for Midnight` ($2)** (bool) : par défaut = Faux (0)
* **`GeneKelly` ($3)** (bool) : par défaut = Faux (0)
* **`RayHarryhausen` ($4)** (bool) : par défaut = Faux (0)
* **`CaryGrant` ($5)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($6)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : 
Usage Notes:  Set Output mode to 'New Layer'.  After running filter, I recommend setting the newly created layer blend mode to 'hard light' when using 'noon for midnight' and 'soft light' for other images.  This filter looks best on well lit scenes.
