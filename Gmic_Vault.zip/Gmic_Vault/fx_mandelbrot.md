---
tags: [gmic, filter]
command: fx_mandelbrot
---

# Filtre G'MIC : fx_mandelbrot

## Structure de la commande
```text
fx_mandelbrot:
    fractal_set = $5
    iterations = $6
    x_seed_julia = $7
    y_seed_julia = $8
    number_of_colors = $9
    smoothness = $10
    seed = $11
    zoom_center_x = $12
    zoom_center_y = $13
    zoom_factor = $14
    display_coordinates = $18
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Renders Mandelbrot and Julia set fractals. 
(Note) : Fractal Type:
* **`Fractal Set` ($1)** (choice) : choix possibles => Mandelbrot, Julia
* **`Iterations` ($2)** (int) : défaut = **1024**  (16,65535)
* **`X-Seed (Julia)` ($3)** (float) : défaut = **0.317**  (-2,2)
* **`Y-Seed (Julia)` ($4)** (float) : défaut = **0.03**  (-2,2)
(Note) : Colormap:
* **`Number of Colors` ($5)** (int) : défaut = **16**  (2,2048)
* **`Smoothness` ($6)** (int) : défaut = **8**  (1,256)
* **`Seed` ($7)** (int) : défaut = **255**  (0,65536)
(Note) : Navigation:
* **`Zoom Center` ($8)** (point) : position = 0,0
* **`Zoom Factor` ($9)** (float) : défaut = **0.75**  (0,1)
* **`Display Coordinates` ($10)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2018/06/27.
