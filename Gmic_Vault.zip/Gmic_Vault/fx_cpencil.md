---
tags: [gmic, filter]
command: fx_cpencil
---

# Filtre G'MIC : fx_cpencil

## Structure de la commande
```text
fx_cpencil:
    size = $1
    amplitude = $2
    quantize_colors = $3
    color_smoothness = $4
    mixer_mode = $5
    color_intensity = $6
    preview_type = $7
```
## Définition des variables
* **`Size` ($1)** (float) : défaut = **1.3**  (0,5)
* **`Amplitude` ($2)** (float) : défaut = **50**  (0,200)
* **`Quantize Colors` ($3)** (int) : défaut = **20**  (2,255)
* **`Color Smoothness` ($4)** (float) : défaut = **2**  (0,30)
* **`Mixer Mode` ($5)** (choice) : choix possibles => Color Doping, Darken, Hard Light, Grain Merge, Lightness, Multiply, Soft Light, Value
* **`Color Intensity` ($6)** (float) : défaut = **1**  (0,1)
* **`Preview Type` ($7)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author: PhotoComiX.      Latest update : 2010/29/12.
