---
tags: [gmic, filter]
command: fx_pencil_portraitbw
---

# Filtre G'MIC : fx_pencil_portraitbw

## Structure de la commande
```text
fx_pencil_portraitbw:
    stroke_length = $1
    stroke_angle = $2
    contour_threshold = $3
    opacity = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Optimized pencil sketch effect for portraits. 
* **`Stroke Length` ($1)** (float) : défaut = **30**  (0,500)
* **`Stroke Angle` ($2)** (float) : défaut = **120**  (0,180)
* **`Contour Threshold` ($3)** (float) : défaut = **1**  (0,10)
* **`Opacity` ($4)** (float) : défaut = **0.5**  (0,1)
* **`Color` ($5)** (color) : défaut = 144,79,21
(Note) : Authors: Jamac4k and <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.       Latest Update: 2015/06/29.
