---
tags: [gmic, filter]
command: fx_karo_cimg_nlmeans
---

# Filtre G'MIC : fx_karo_cimg_nlmeans

## Structure de la commande
```text
fx_karo_cimg_nlmeans:
    add_gauss_noise = $1
    add_uniform_noise = $2
    add_salt_pepper_noise = $3
    half_size_of_patch = $4
    band_width_lambda = $5
    noise_sd_sigma = $6
    neighborhood_size_alpha = $7
    sampling_step_size = $8
    preview_type = $9
    preview_split_x = $10
    preview_split_y = $11
```
## Définition des variables
* **`Add Gauss Noise` ($1)** (float) : défaut = **0.0**  (0.0,30.0)
* **`Add Uniform Noise` ($2)** (float) : défaut = **0.0**  (0.0,30.0)
* **`Add Salt & Pepper Noise` ($3)** (float) : défaut = **0.0**  (0.0,30.0)
* **`Half Size of Patch` ($4)** (int) : défaut = **1**  (1,15)
* **`Band Width Lambda` ($5)** (float) : défaut = **-1**  (-1,25)
* **`Noise SD Sigma` ($6)** (float) : défaut = **-1**  (-1,25)
* **`Neighborhood Size Alpha` ($7)** (int) : défaut = **3**  (1,15)
* **`Sampling Step Size` ($8)** (int) : défaut = **2**  (1,5)
* **`Preview Type` ($9)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($10)** (point) : position = 0,0
(Note) : Smoothing using CImg example plugin use_nlmeans.
(Note) : CImg nlmeans: use_nlmeans in search PATH
(Note) : Author : KaRo. Latest update : 2019/09/03.
