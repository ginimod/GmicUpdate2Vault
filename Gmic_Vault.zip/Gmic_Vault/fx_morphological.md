---
tags: [gmic, filter]
command: fx_morphological
---

# Filtre G'MIC : fx_morphological

## Structure de la commande
```text
fx_morphological:
    action = $1
    kernel = $2
    size = $3
    negative = $5
    process_transparency = $6
    channel_s = $7
    value_action = $8
    preview_type = $9
    preview_split_x = $10
    preview_split_y = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Applies morphological operations (erosion, dilation, etc.). 
* **`Action` ($1)** (choice) : choix possibles => Erosion, Dilation, Opening, Closing, Original - Erosion, Dilation - Original, Original - Opening, Closing - Original, Original - (Opening + Closing)/2, Closing - Opening
* **`Kernel` ($2)** (choice) : choix possibles => Square, Octagonal, Circular, Custom
* **`Size` ($3)** (int) : défaut = **5**  (2,60)
(Note) : Parameter Size is inactive for Custom kernel.
* **`Negative` ($4)** (bool) : par défaut = Faux (0)
* **`Process Transparency` ($5)** (bool) : par défaut = Faux (0)
* **`Channel(s)` ($6)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
* **`Value Action` ($7)** (choice) : choix possibles => None, Cut, Stretch
* **`Preview Type` ($8)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($9)** (point) : position = 0,0
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/06/22.
