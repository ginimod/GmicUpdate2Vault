---
tags: [gmic, filter]
command: afre_details
---

# Filtre G'MIC : afre_details

## Structure de la commande
```text
afre_details:
    scales = $1
```
## Définition des variables
(Note) : <strong>Split image into detail scales.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2020 Aug10.</strong>


* **`Scales` ($1)** (int) : défaut = **2**  (2,6)
(Note) : 

<strong>Instructions</strong>

Drag preview image to examine different regions of interest.
(Note) : 

<strong>Note</strong>

G'MIC's preview is inaccurate. Apply the filter and review the results in your host editor.
