---
tags: [gmic, filter]
command: fx_inpaint_patch
---

# Filtre G'MIC : fx_inpaint_patch

## Structure de la commande
```text
fx_inpaint_patch:
    patch_size = $1
    lookup_size = $2
    lookup_factor = $3
    blend_size = $4
    blend_threshold = $5
    blend_decay = $6
    blend_scales = $7
    allow_outer_blending = $8
    mask_dilation = $13
    process_by_blocks_of_size = $14
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Inpaints mask content by copy/pasting from similar image parts. 
* **`Patch Size` ($1)** (int) : défaut = **7**  (1,64)
* **`Lookup Size` ($2)** (float) : défaut = **16**  (1,32)
* **`Lookup Factor` ($3)** (float) : défaut = **0.1**  (0,1)
* **`Blend Size` ($4)** (float) : défaut = **1.2**  (0,5)
* **`Blend Threshold` ($5)** (float) : défaut = **0**  (0,1)
* **`Blend Decay` ($6)** (float) : défaut = **0.05**  (0,0.5)
* **`Blend Scales` ($7)** (int) : défaut = **10**  (1,20)
* **`Allow Outer Blending` ($8)** (bool) : par défaut = Faux (0)
* **`Mask Color` ($9)** (color) : défaut = 255,0,0,255
* **`Mask Dilation` ($10)** (int) : défaut = **0**  (0,32)
* **`Process by Blocks of Size` ($11)** (choice) : choix possibles => 100%, 75%, 50%, 25%, 10%, 5%, 2%, 1%
(Note) : A quick tutorial on how to use this filter can be found here:
(Note) : Authors: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a> and Maxime Daisy.       Latest Update: 2015/11/25.
