---
tags: [gmic, filter]
command: fx_gcd_crmt_tile
---

# Filtre G'MIC : fx_gcd_crmt_tile

## Structure de la commande
```text
fx_gcd_crmt_tile:
    inpaint = $4
```
## Définition des variables
(Note) : Tiling by Clone, Rotate, Mirror, Translate method.
* **`Inpaint` ($1)** (bool) : par défaut = Faux (0)
(Note) : Implementation : Garagecoder.     Latest update : 2019/05/10.
(Note) : Author: G. Bachelier
(Note) : 
Warning: alpha version, don't expect perfection!
