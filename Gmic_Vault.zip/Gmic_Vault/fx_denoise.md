---
tags: [gmic, filter]
command: fx_denoise
---

# Filtre G'MIC : fx_denoise

## Structure de la commande
```text
fx_denoise:
    automatic_noise_level_estimation = $1
    noise_level = $2
    opacity = $3
    iterations = $4
    preview = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Removes noise using a Convolutional Neural Network. 
* **`Automatic Noise Level Estimation` ($1)** (bool) : par défaut = Faux (0)
* **`Noise Level (%)` ($2)** (float) : défaut = **50**  (0,100)
* **`Opacity (%)` ($3)** (float) : défaut = **100**  (0,100)
* **`Iterations` ($4)** (int) : défaut = **1**  (1,5)
* **`Preview` ($5)** (bool) : par défaut = Faux (0)
(Note) :  <span color="#EE5500">Note:</span> This filter uses a convolutional neural network (CNN) to denoise images. This filter does not take advantage of GPU computing, so expect it to be quite slow if you don't have many CPU cores available. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2025/10/13.
