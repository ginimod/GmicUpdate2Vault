---
tags: [gmic, filter]
command: fx_AbstractFlood
---

# Filtre G'MIC : fx_AbstractFlood

## Structure de la commande
```text
fx_AbstractFlood:
    preprocess_with_bilateral_filtering = $1
    spatial_variance = $2
    value_variance = $3
    iterations = $4
    activate_flood = $5
    repeats = $6
    flood_tolerance = $7
    flood_base_step = $8
    activate_cubism = $13
    cubism_iterations = $14
    bloc_size = $15
    angle = $16
    opacity = $17
    smoothness = $18
    opacity_tolerance = $19
    preview_type = $20
```
## Définition des variables
(Note) : Warning: Really really slow filter especially with Cubism enabled. Use a maximum of 1 megapixel image. Random walk algorihm is used to select new areas to flood. If Cubism is enabled the filter has to run cubims for every succesful repeat defined in the flood settings section.
* **`Preprocess with Bilateral Filtering` ($1)** (bool) : par défaut = Faux (0)
* **`Spatial Variance` ($2)** (float) : défaut = **10**  (0,100)
* **`Value Variance` ($3)** (float) : défaut = **7**  (0,100)
* **`Iterations` ($4)** (int) : défaut = **2**  (1,10)
(Note) : Flood settings
* **`Activate Flood` ($5)** (bool) : par défaut = Faux (0)
* **`Repeats` ($6)** (int) : défaut = **10**  (1,1000)
* **`Flood Tolerance` ($7)** (int) : défaut = **5**  (0,100)
* **`Flood Base Step` ($8)** (int) : défaut = **3**  (1,10)
* **`Canvas Color` ($9)** (color) : défaut = 255,255,255,255
(Note) : Abstraction setting, Consider disabling preview if using high flood repeats!
* **`Activate Cubism` ($10)** (bool) : par défaut = Faux (0)
* **`Cubism Iterations` ($11)** (int) : défaut = **300**  (1,2000)
* **`Bloc Size` ($12)** (float) : défaut = **10**  (0,40)
* **`Angle` ($13)** (float) : défaut = **90**  (0,360)
* **`Opacity` ($14)** (float) : défaut = **0.7**  (0.01,1)
* **`Smoothness` ($15)** (float) : défaut = **0**  (0,5)
(Note) : Opacity threshold used to make decision about flooding. Use 0 if Cubism is not enabled.
* **`Opacity Tolerance` ($16)** (int) : défaut = **0**  (0,254)
* **`Preview Type` ($17)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author : Arto Huotari.      Latest update : 2013/09/28.
