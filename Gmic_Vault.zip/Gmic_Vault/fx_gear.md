---
tags: [gmic, filter]
command: fx_gear
---

# Filtre G'MIC : fx_gear

## Structure de la commande
```text
fx_gear:
    size = $1
    number_of_teeth = $2
    elevation = $3
    angle = $4
    inner_radius = $5
    smoothness = $6
    antialiasing = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Renders a gear/cog silhouette. 
* **`Size (%)` ($1)** (float) : défaut = **75**  (0,100)
* **`Number of Teeth` ($2)** (int) : défaut = **12**  (1,96)
* **`Elevation (%)` ($3)** (float) : défaut = **15**  (0,100)
* **`Angle (%)` ($4)** (float) : défaut = **0**  (0,100)
* **`Inner Radius (%)` ($5)** (float) : défaut = **40**  (0,100)
* **`Smoothness` ($6)** (float) : défaut = **0**  (0,10)
* **`Color` ($7)** (color) : défaut = 255,255,255,255
* **`Antialiasing` ($8)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2018/01/08.
