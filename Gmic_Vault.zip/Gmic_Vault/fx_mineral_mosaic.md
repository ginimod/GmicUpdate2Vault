---
tags: [gmic, filter]
command: fx_mineral_mosaic
---

# Filtre G'MIC : fx_mineral_mosaic

## Structure de la commande
```text
fx_mineral_mosaic:
    density = $1
    area = $2
    smoothness = $3
    shade_strength = $4
    shade_angle = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Creates a mosaic looking like mineral cross-sections. 
* **`Density` ($1)** (float) : défaut = **1**  (0,3)
* **`Area` ($2)** (float) : défaut = **2**  (0,32)
* **`Smoothness` ($3)** (float) : défaut = **1**  (0,10)
* **`Shade Strength` ($4)** (float) : défaut = **100**  (0,255)
* **`Shade Angle` ($5)** (float) : défaut = **0**  (0,360)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2013/02/01.
