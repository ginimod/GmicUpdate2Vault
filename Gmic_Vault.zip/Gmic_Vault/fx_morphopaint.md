---
tags: [gmic, filter]
command: fx_MorphoPaint
---

# Filtre G'MIC : fx_MorphoPaint

## Structure de la commande
```text
fx_MorphoPaint:
    method = $1
    morphostrenght = $2
    shape = $3
    black_point = $4
    expand_shadows = $5
    compress_highlights = $6
    spread_amount = $7
    blur_strength = $8
    edge_threshold = $9
    smoothness = $10
    abstraction = $11
    details_scale = $12
    smoothness = $13
    merge_layers = $14
    enable_paintstroke = $15
    stroke_strength = $16
    enable_segmentation = $17
    segments_strength = $18
    enable_morphology = $19
    morphology_strength = $20
    normalize = $21
    preview_type = $22
```
## Définition des variables
(Note) : Creates a painting using Morphology-, Segmentation- and Painting- filters. CPU intensive filter that may take long.
(Note) : Morphology settings
* **`Method` ($1)** (choice) : choix possibles => Erosion, Dilation, Opening, Closing
* **`MorphoStrenght` ($2)** (int) : défaut = **18**  (2,60)
* **`Shape` ($3)** (choice) : choix possibles => Square, Octagonal, Circular
(Note) : Lightness for Morpholayer
* **`Black Point` ($4)** (int) : défaut = **25**  (0,50)
* **`Expand Shadows` ($5)** (int) : défaut = **100**  (50,255)
* **`Compress Highlights` ($6)** (int) : défaut = **230**  (200,255)
(Note) : Smoothing strength
* **`Spread Amount` ($7)** (int) : défaut = **8**  (0,20)
* **`Blur Strength` ($8)** (int) : défaut = **3**  (0,10)
(Note) : Segmentation settings
* **`Edge Threshold` ($9)** (float) : défaut = **4**  (0,15)
* **`Smoothness` ($10)** (float) : défaut = **0.5**  (0,5)
(Note) : Painting Settings
* **`Abstraction` ($11)** (int) : défaut = **2**  (1,10)
* **`Details Scale` ($12)** (float) : défaut = **0.5**  (0,5)
* **`Smoothness` ($13)** (float) : défaut = **200**  (0,1000)
* **`Merge Layers?` ($14)** (bool) : par défaut = Faux (0)
(Note) : When unchecked the filter will output layers separately for manual composing. Set G'Mic output to new layers.
* **`Enable Paintstroke` ($15)** (bool) : par défaut = Faux (0)
* **`Stroke Strength` ($16)** (float) : défaut = **1**  (0,1)
* **`Enable Segmentation` ($17)** (bool) : par défaut = Faux (0)
* **`Segments Strength` ($18)** (float) : défaut = **1**  (0,1)
* **`Enable Morphology` ($19)** (bool) : par défaut = Faux (0)
* **`Morphology Strength` ($20)** (float) : défaut = **1**  (0,1)
* **`Normalize` ($21)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($22)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author : Arto Huotari.      Latest update : 2013/09/28.
