---
tags: [gmic, filter]
command: fx_draw_whirl
---

# Filtre G'MIC : fx_draw_whirl

## Structure de la commande
```text
fx_draw_whirl:
    amplitude = $1
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Overlay a pattern using whirling strokes. 
* **`Amplitude` ($1)** (float) : défaut = **20**  (0,100)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
