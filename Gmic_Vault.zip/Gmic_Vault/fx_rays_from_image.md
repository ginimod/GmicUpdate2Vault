---
tags: [gmic, filter]
command: fx_rays_from_image
---

# Filtre G'MIC : fx_rays_from_image

## Structure de la commande
```text
fx_rays_from_image:
    power = $1
    centre_x = $2
    centre_y = $3
    channel_s = $4
    value_action = $5
```
## Définition des variables
(Note) : Creates rays from the colours of an image. If the power is 5, the lines radiate outwards as if the image is being exploded from the chosen point.
* **`Power` ($1)** (float) : défaut = **5**  (0,10)
* **`Centre` ($2)** (point) : position = 0,0
* **`Channel(s)` ($3)** (choice) : choix possibles => All, RGBA [all], RGB [all], RGB [red], RGB [green], RGB [blue], RGBA [alpha], Linear RGB [all], Linear RGB [red], Linear RGB [green], Linear RGB [blue], YCbCr [luminance], YCbCr [blue-Red Chrominances], YCbCr [blue Chrominance], YCbCr [red Chrominance], YCbCr [green Chrominance], Lab [lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [hue], HSV [saturation], HSV [value], HSI [intensity], HSL [lightness], CMYK [cyan], CMYK [magenta], CMYK [yellow], CMYK [key], YIQ [luma], YIQ [chromas]
* **`Value Action` ($4)** (choice) : choix possibles => None, Cut, Normalize
