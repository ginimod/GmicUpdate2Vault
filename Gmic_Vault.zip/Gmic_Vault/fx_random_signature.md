---
tags: [gmic, filter]
command: fx_random_signature
---

# Filtre G'MIC : fx_random_signature

## Structure de la commande
```text
fx_random_signature:
    seed = $1
    complexity = $2
    top_left_corner_x = $3
    top_left_corner_y = $4
    bottom_right_corner_x = $5
    bottom_right_corner_y = $6
    thickness = $7
    tilt_deg = $8
    tilt_strength = $9
    anti_alias = $14
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a random scribble looking like a signature. 
* **`Seed` ($1)** (int) : défaut = **16**  (0,65536)
* **`Complexity` ($2)** (int) : défaut = **16**  (2,32)
* **`Top-Left Corner` ($3)** (point) : position = 0,0
* **`Bottom-Right Corner` ($4)** (point) : position = 0,0
* **`Thickness (%)` ($5)** (float) : défaut = **1.5**  (0,10)
* **`Tilt (deg.)` ($6)** (float) : défaut = **0**  (-180,180)
* **`Tilt Strength (%)` ($7)** (float) : défaut = **75**  (0,100)
* **`Color` ($8)** (color) : défaut = 0,0,0,255
* **`Anti-Alias` ($9)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2024/01/04.
