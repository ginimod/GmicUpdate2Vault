---
tags: [gmic, filter]
command: fx_blur_multidirectional
---

# Filtre G'MIC : fx_blur_multidirectional

## Structure de la commande
```text
fx_blur_multidirectional:
    number_of_orientations = $1
    reference_angle_deg = $2
    angle_range_deg = $3
    smoothness = $4
    kernel_type = $5
    boundary = $6
    sharpness = $7
    blend_mode = $8
    boost_contrast = $9
    channel_s = $10
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Blurs in multiple directions simultaneously. 
* **`Number of Orientations` ($1)** (int) : défaut = **5**  (1,16)
* **`Reference Angle (deg.)` ($2)** (float) : défaut = **0**  (0,360)
* **`Angle Range (deg.)` ($3)** (float) : défaut = **360**  (0,360)
* **`Smoothness` ($4)** (float) : défaut = **150**  (0,1024)
* **`Kernel Type` ($5)** (choice) : choix possibles => Mono-Directional, Bi-Directional
* **`Boundary` ($6)** (choice) : choix possibles => Dirichlet, Neumann, Periodic, Mirror
* **`Sharpness` ($7)** (float) : défaut = **0**  (0,1000)
* **`Blend Mode` ($8)** (choice) : choix possibles => Min, Max, Average, Edges-0.5 (beware: Memory-Consuming!), Edges-1 (beware: Memory-Consuming!), Edges-2 (beware: Memory-Consuming!), Median (beware: Memory-Consuming!)
* **`Boost Contrast` ($9)** (float) : défaut = **2**  (0,32)
* **`Channel(s)` ($10)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2020/09/11.
