---
tags: [gmic, filter]
command: fx_houghsketchbw
---

# Filtre G'MIC : fx_houghsketchbw

## Structure de la commande
```text
fx_houghsketchbw:
    smoothness = $1
    density = $2
    radius = $3
    threshold = $4
    opacity = $5
    color_model = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Sketches the image using lines detected by the Hough transform. 
* **`Smoothness` ($1)** (float) : défaut = **1.25**  (0,10)
* **`Density (%)` ($2)** (float) : défaut = **10**  (0,100)
* **`Radius` ($3)** (int) : défaut = **5**  (0,30)
* **`Threshold` ($4)** (float) : défaut = **80**  (0,100)
* **`Opacity` ($5)** (float) : défaut = **0.1**  (0,1)
* **`Color Model` ($6)** (choice) : choix possibles => Black on White, White on Black, Black on Transparent White, White on Transparent Black, Color on White
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2023/05/29.
