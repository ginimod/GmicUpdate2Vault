---
tags: [gmic, filter]
command: fx_import_image_16
---

# Filtre G'MIC : fx_import_image_16

## Structure de la commande
```text
fx_import_image_16:
    process_selection = $2
    gamma = $3
    brightness = $4
    contrast = $5
    equalize = $6
    saturation = $7
    a_r_g = $8
    b_y_b = $9
    cut_highlight_values = $10
    cut_dark_values = $11
```
## Définition des variables
(Note) : Filter can be used to import and adjust 16 bit images to Gimp. Plugin may have limited set of import formats available depending on compilation. At minimum only .png should work reliably.
(Note) : 1. Create new empty image to Gimp
(Note) : 2. Open G'Mic from filters menu
(Note) : 3. Set G'Mic output to "new layers
(Note) : 4. Select 16 bit image from folder
(Note) : 5. Make adjustments using sliders
(Note) : 6. Image will be outputted to Gimp
(Note) : By default a scaled down image is processed. Before processing full size disable preview window from gui.
(Note) : LAB adjustment often yields more aesthetic results than RGB adjustment.
* **`Process Selection` ($1)** (choice) : choix possibles => Preview Only, Histogram, Logarithmic Histogram, Full Resolution
* **`Gamma` ($2)** (float) : défaut = **2.2**  (0,5)
(Note) : LAB adjustment
* **`Brightness` ($3)** (float) : défaut = **0**  (-1,1)
* **`Contrast` ($4)** (float) : défaut = **1**  (0,3)
* **`Equalize` ($5)** (float) : défaut = **0**  (0,1)
* **`Saturation` ($6)** (float) : défaut = **0**  (-1,10)
* **`A(R-G)` ($7)** (float) : défaut = **0**  (-1,1)
* **`B(Y-B)` ($8)** (float) : défaut = **0**  (-1,1)
(Note) : RGB cut and normalize histogram by percentage
* **`Cut Highlight Values` ($9)** (float) : défaut = **100**  (0,100)
* **`Cut Dark Values` ($10)** (float) : défaut = **0**  (0,100)
(Note) : Author: Arto Huotari;.      Latest update: 2014/04/02.
