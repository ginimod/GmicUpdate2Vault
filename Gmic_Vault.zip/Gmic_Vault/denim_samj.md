---
tags: [gmic, filter]
command: Denim_samj
---

# Filtre G'MIC : Denim_samj

## Structure de la commande
```text
Denim_samj:
    dimension_motif_base = $1
    dilatation_motif_pattern = $2
    retourner_motif_flip_pattern = $3
    deformation_1 = $4
    deformation_2 = $5
    denim_bruit_noise = $6
    usure_bruit_noise = $7
    nettete_sharpness = $8
```
## Définition des variables
(Note) : <span foreground="orangered">Texture</span>
* **`Dimension Motif Base` ($1)** (int) : défaut = **5**  (2,30)
* **`Dilatation Motif / Pattern` ($2)** (int) : défaut = **2**  (0,5)
* **`Retourner Motif / Flip Pattern` ($3)** (bool) : par défaut = Faux (0)
* **`Déformation 1` ($4)** (int) : défaut = **40**  (0,200)
* **`Déformation 2` ($5)** (int) : défaut = **40**  (0,200)
* **`Denim [bruit/noise]` ($6)** (int) : défaut = **25**  (0,100)
* **`Usure [bruit/noise]` ($7)** (int) : défaut = **50**  (0,100)
* **`Netteté / Sharpness` ($8)** (float) : défaut = **0**  (0,500)
(Note) : <span foreground="orangered">Couleur</span>
* **`Couleur Denim` ($9)** (color) : défaut = 43,108,126,255
(Note) : samj - Version : 2024/11/16.
