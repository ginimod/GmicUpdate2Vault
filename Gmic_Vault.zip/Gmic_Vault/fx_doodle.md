---
tags: [gmic, filter]
command: fx_doodle
---

# Filtre G'MIC : fx_doodle

## Structure de la commande
```text
fx_doodle:
    precision = $1
    smoothness = $2
    coherence = $3
    contour_threshold = $4
    spacing = $5
    minimal_stroke_length = $6
    preview_progression_while_running = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Turns the image into a simple line doodle. 
* **`Precision (%)` ($1)** (float) : défaut = **30**  (0,100)
* **`Smoothness` ($2)** (float) : défaut = **2**  (0,10)
* **`Coherence` ($3)** (float) : défaut = **2**  (0,10)
* **`Contour Threshold` ($4)** (float) : défaut = **1.5**  (0,10)
* **`Spacing` ($5)** (int) : défaut = **2**  (0,20)
* **`Minimal Stroke Length` ($6)** (float) : défaut = **70**  (0,255)
* **`Preview Progression While Running` ($7)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2020/07/08.
