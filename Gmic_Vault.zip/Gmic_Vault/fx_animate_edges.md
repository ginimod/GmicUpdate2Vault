---
tags: [gmic, filter]
command: fx_animate_edges
---

# Filtre G'MIC : fx_animate_edges

## Structure de la commande
```text
fx_animate_edges:
    frames = $1
    output_frames = $2
    output_files = $3
    negative_colors = $5
    smoothness = $6
    edge_threshold = $7
    smoothness = $8
    edge_threshold = $9
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Animates edge detection. 
* **`Frames` ($1)** (int) : défaut = **10**  (2,100)
* **`Output Frames` ($2)** (bool) : par défaut = Faux (0)
* **`Output Files` ($3)** (bool) : par défaut = Faux (0)
(Note) : 
Global Parameters :
* **`Negative Colors` ($4)** (bool) : par défaut = Faux (0)
(Note) : 
Starting Parameters :
* **`Smoothness` ($5)** (float) : défaut = **0**  (0,10)
* **`Edge Threshold` ($6)** (float) : défaut = **10**  (0,30)
(Note) : 
Ending Parameters :
* **`Smoothness` ($7)** (float) : défaut = **0**  (0,10)
* **`Edge Threshold` ($8)** (float) : défaut = **30**  (0,30)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
