---
tags: [gmic, filter]
command: fx_polygonize_delaunay
---

# Filtre G'MIC : fx_polygonize_delaunay

## Structure de la commande
```text
fx_polygonize_delaunay:
    density = $1
    edges = $2
    boundaries = $3
    smoothness = $4
    filling = $5
    outline = $6
    anti_aliasing = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Triangulates the image based on Delaunay tessellation. 
* **`Density (%)` ($1)** (float) : défaut = **40**  (0,100)
* **`Edges` ($2)** (float) : défaut = **5**  (0,100)
* **`Boundaries (%)` ($3)** (float) : défaut = **75**  (0,100)
* **`Smoothness` ($4)** (float) : défaut = **0.5**  (0,8)
* **`Filling` ($5)** (choice) : choix possibles => Black, White, Random, Average, Linear
* **`Outline (%)` ($6)** (float) : défaut = **50**  (0,100)
* **`Outline Color` ($7)** (color) : défaut = 0,0,0,255
* **`Anti-Aliasing` ($8)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2018/06/05.
