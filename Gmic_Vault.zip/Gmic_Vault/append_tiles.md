---
tags: [gmic, filter]
command: append_tiles
---

# Filtre G'MIC : append_tiles

## Structure de la commande
```text
append_tiles:
    x_tiles = $1
    y_tiles = $2
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Arranges all layers into a single tiled image. 
* **`X-Tiles` ($1)** (int) : défaut = **0**  (0,256)
* **`Y-Tiles` ($2)** (int) : défaut = **0**  (0,256)
(Note) : For both parameters, 0 means automatic.
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
