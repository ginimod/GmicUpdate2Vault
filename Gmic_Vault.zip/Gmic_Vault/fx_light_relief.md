---
tags: [gmic, filter]
command: fx_light_relief
---

# Filtre G'MIC : fx_light_relief

## Structure de la commande
```text
fx_light_relief:
    ambient_lightness = $1
    specular_lightness = $2
    specular_size = $3
    darkness = $4
    light_smoothness = $5
    xy_light_x = $6
    xy_light_y = $7
    z_light = $8
    z_scale = $9
    opacity_as_heightmap = $10
    image_smoothness = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates light shining on a relief surface. 
* **`Ambient Lightness` ($1)** (float) : défaut = **0.3**  (0,5)
* **`Specular Lightness` ($2)** (float) : défaut = **0.2**  (0,2)
* **`Specular Size` ($3)** (float) : défaut = **0.2**  (0,1)
* **`Darkness` ($4)** (float) : défaut = **0**  (0,1)
* **`Light Smoothness` ($5)** (float) : défaut = **1**  (0,5)
* **`XY-Light` ($6)** (point) : position = 0,0
* **`Z-Light` ($7)** (float) : défaut = **5**  (0,20)
* **`Z-Scale` ($8)** (float) : défaut = **0.5**  (0,3)
* **`Opacity as Heightmap` ($9)** (bool) : par défaut = Faux (0)
* **`Image Smoothness` ($10)** (float) : défaut = **0**  (0,10)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
