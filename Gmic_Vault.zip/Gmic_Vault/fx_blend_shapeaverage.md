---
tags: [gmic, filter]
command: fx_blend_shapeaverage
---

# Filtre G'MIC : fx_blend_shapeaverage

## Structure de la commande
```text
fx_blend_shapeaverage:
    preserve_shading = $1
    transparency = $2
    revert_layers = $3
```
## Définition des variables
* **`Preserve Shading` ($1)** (bool) : par défaut = Faux (0)
* **`Transparency` ($2)** (bool) : par défaut = Faux (0)
* **`Revert Layers` ($3)** (bool) : par défaut = Faux (0)
(Note) : Note: This filter needs two layers to work properly. Set the Input layers option to handle multiple input layers. 
(Note) : Author: David Tschumperlé/i>.      Latest update: 2011/19/10.
