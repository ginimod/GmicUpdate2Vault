---
tags: [gmic, filter]
command: fx_dodgeburn
---

# Filtre G'MIC : fx_dodgeburn

## Structure de la commande
```text
fx_dodgeburn:
    highlights_selection = $1
    highlights_abstraction = $2
    dodge_strength = $3
    dodge_blur = $4
    shadows_selection = $5
    shadows_abstraction = $6
    burn_strength = $7
    burn_blur = $8
    keep_layers_separate = $9
    keep_original_layer = $10
    blur_dodge_and_burn_layer = $11
    preview_type = $12
```
## Définition des variables
(Note) : automatic dodging and burning
* **`Highlights Selection` ($1)** (float) : défaut = **15**  (0,100)
* **`Highlights Abstraction` ($2)** (float) : défaut = **1.5**  (0,10)
* **`Dodge Strength` ($3)** (float) : défaut = **25**  (0,256)
* **`Dodge Blur` ($4)** (float) : défaut = **10**  (0,20)
* **`Shadows Selection` ($5)** (float) : défaut = **40**  (0,100)
* **`Shadows Abstraction` ($6)** (float) : défaut = **1.5**  (0,10)
* **`Burn Strength` ($7)** (float) : défaut = **25**  (0,256)
* **`Burn Blur` ($8)** (float) : défaut = **10**  (0,20)
(Note) : Advanved: output dodge and burn layer separate
* **`Keep Layers Separate` ($9)** (bool) : par défaut = Faux (0)
* **`Keep Original Layer` ($10)** (bool) : par défaut = Faux (0)
* **`Blur Dodge and Burn Layer` ($11)** (float) : défaut = **10**  (0,20)
* **`Preview Type` ($12)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author: Tom Keil.      Latest update: 2011/15/02.
