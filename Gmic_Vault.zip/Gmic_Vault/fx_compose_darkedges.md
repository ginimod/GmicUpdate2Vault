---
tags: [gmic, filter]
command: fx_compose_darkedges
---

# Filtre G'MIC : fx_compose_darkedges

## Structure de la commande
```text
fx_compose_darkedges:
    opacity = $1
    edges_smoothness = $2
    revert_layers = $3
    opacity_2 = $4
```
## Définition des variables
* **`Opacity` ($1)** (float) : défaut = **1**  (0,1)
* **`Edges Smoothness` ($2)** (float) : défaut = **0.5**  (0,5)
* **`Revert Layers` ($3)** (bool) : par défaut = Faux (0)
* **`Opacity 2` ($4)** (float) : défaut = **0.7**  (0,1)
(Note) : Author: PhotoComiX.      Latest update : 2011/13/11.
