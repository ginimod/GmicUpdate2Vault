---
tags: [gmic, filter]
command: fx_jr_bilinear
---

# Filtre G'MIC : fx_jr_bilinear

## Structure de la commande
```text
fx_jr_bilinear:
    overall_iterations = $1
    bilateral_sub_iterations = $2
    spatial_variance = $3
    value_variance = $4
    amplitude = $5
    channel_s = $6
    preview_type = $7
    preview_split_x = $8
    preview_split_y = $9
```
## Définition des variables
* **`Overall Iterations` ($1)** (int) : défaut = **1**  (1,10)
* **`Bilateral Sub-Iterations` ($2)** (int) : défaut = **3**  (1,10)
* **`Spatial Variance` ($3)** (float) : défaut = **10**  (0,100)
* **`Value Variance` ($4)** (float) : défaut = **10**  (0,100)
* **`Amplitude` ($5)** (float) : défaut = **1**  (-10,10)
* **`Channel(s)` ($6)** (choice) : choix possibles => All, RGBA [All], RGB [All], RGB [Red], RGB [Green], RGB [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [Hue], HSV [Saturation], HSV [Value], HSI [Intensity], HSL [Lightness], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
* **`Preview Type` ($7)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($8)** (point) : position = 0,0
