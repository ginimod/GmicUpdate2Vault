---
tags: [gmic, filter]
command: fx_lylejk_stencil
---

# Filtre G'MIC : fx_lylejk_stencil

## Structure de la commande
```text
fx_lylejk_stencil:
    amplitude = $1
    sharpness = $2
    radius = $3
    channel_s = $4
```
## Définition des variables
* **`Amplitude` ($1)** (int) : défaut = **5**  (1,10)
* **`Sharpness` ($2)** (float) : défaut = **10**  (0,100)
* **`Radius` ($3)** (float) : défaut = **3**  (0,10)
* **`Channel(s)` ($4)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CYMK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Authors: Lyle Kroll, David Tschumperlé.      Latest update: 2010/29/12.
