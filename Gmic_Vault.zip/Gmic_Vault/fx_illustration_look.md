---
tags: [gmic, filter]
command: fx_illustration_look
---

# Filtre G'MIC : fx_illustration_look

## Structure de la commande
```text
fx_illustration_look:
    strength = $1
    tone_mapping = $2
    desaturate = $3
    vintage_tone = $4
    output_as_multiple_layers = $5
    preview_type = $6
```
## Définition des variables
* **`Strength (%)` ($1)** (float) : défaut = **100**  (0,100)
* **`Tone Mapping (%)` ($2)** (float) : défaut = **100**  (0,100)
* **`Desaturate (%)` ($3)** (float) : défaut = **0**  (0,100)
* **`Vintage Tone (%)` ($4)** (float) : défaut = **0**  (0,100)
* **`Output as Multiple Layers` ($5)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($6)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Authors: Sébastien Guyader and <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest update: 2017/05/01.
