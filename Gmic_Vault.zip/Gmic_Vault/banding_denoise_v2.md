---
tags: [gmic, filter]
command: banding_denoise_v2
---

# Filtre G'MIC : banding_denoise_v2

## Structure de la commande
```text
banding_denoise_v2:
    v_cutoff = $1
    h_cutoff = $2
    space = $3
    value = $4
    size_of_tiles = $5
    preview_difference = $6
    preview_type = $7
    preview_split_x = $8
    preview_split_y = $9
```
## Définition des variables
* **`V Cutoff` ($1)** (float) : défaut = **5**  (0,50)
* **`H Cutoff` ($2)** (float) : défaut = **5**  (0,50)
* **`Space` ($3)** (float) : défaut = **5**  (0,20)
* **`Value` ($4)** (float) : défaut = **10**  (0,100)
* **`Size of Tiles` ($5)** (choice) : choix possibles => No Tiling, 64px, 128px, 256px, 512px, 1024px, 2048px
* **`Preview Difference` ($6)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($7)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($8)** (point) : position = 0,0
(Note) : Authors: Iain Fergusson and <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>       Latest Update: 2023/02/23.
