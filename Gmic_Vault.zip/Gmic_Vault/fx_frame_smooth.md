---
tags: [gmic, filter]
command: fx_frame_smooth
---

# Filtre G'MIC : fx_frame_smooth

## Structure de la commande
```text
fx_frame_smooth:
    width = $1
    height = $2
    roundness = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds a smooth, vignetted frame. 
* **`Width (%)` ($1)** (int) : défaut = **5**  (0,100)
* **`Height (%)` ($2)** (int) : défaut = **5**  (0,100)
* **`Roundness` ($3)** (float) : défaut = **0.25**  (0,1)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/04/25.
