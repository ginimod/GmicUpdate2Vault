---
tags: [gmic, filter]
command: fx_frame_round_old
---

# Filtre G'MIC : fx_frame_round_old

## Structure de la commande
```text
fx_frame_round_old:
    sharpness = $1
    size = $2
    smoothness = $3
    shade = $4
    blur_frame = $9
    blur_shade = $10
    blur_amplitude = $11
```
## Définition des variables
* **`Sharpness` ($1)** (float) : défaut = **6**  (0.1,40)
* **`Size (%)` ($2)** (float) : défaut = **20**  (0,100)
* **`Smoothness` ($3)** (float) : défaut = **0.1**  (0,15)
* **`Shade` ($4)** (float) : défaut = **0**  (0,1)
* **`Color` ($5)** (color) : défaut = 255,255,255,255
* **`Blur Frame` ($6)** (float) : défaut = **0**  (0,100)
* **`Blur Shade` ($7)** (float) : défaut = **0.1**  (0,1)
* **`Blur Amplitude` ($8)** (float) : défaut = **3**  (0,10)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/29/12.
