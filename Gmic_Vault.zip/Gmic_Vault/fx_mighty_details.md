---
tags: [gmic, filter]
command: fx_mighty_details
---

# Filtre G'MIC : fx_mighty_details

## Structure de la commande
```text
fx_mighty_details:
    amplitude = $1
    details_amount = $2
    details_scale = $3
    details_smoothness = $4
    channel_s = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Another algorithm for strong local detail enhancement. 
* **`Amplitude` ($1)** (float) : défaut = **25**  (0,100)
* **`Details Amount` ($2)** (float) : défaut = **1**  (0,2)
* **`Details Scale` ($3)** (float) : défaut = **25**  (1,100)
* **`Details Smoothness` ($4)** (int) : défaut = **1**  (0,10)
* **`Channel(s)` ($5)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2014/08/08.
