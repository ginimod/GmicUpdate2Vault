---
tags: [gmic, filter]
command: afre_vigcirc
---

# Filtre G'MIC : afre_vigcirc

## Structure de la commande
```text
afre_vigcirc:
    size = $1
    strength = $2
    left_right = $3
    up_down = $4
```
## Définition des variables
(Note) : <strong>Add circular vignette.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2019.</strong>
<hr /> <strong>Instructions:</strong>

 * Negative strength brightens the periphery.


* **`Size` ($1)** (int) : défaut = **90**  (50,150)
* **`Strength` ($2)** (int) : défaut = **75**  (-500,500)
* **`Left-Right` ($3)** (int) : défaut = **50**  (0,100)
* **`Up-Down` ($4)** (int) : défaut = **50**  (0,100)
