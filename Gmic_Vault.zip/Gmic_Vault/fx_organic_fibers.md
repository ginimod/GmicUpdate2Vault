---
tags: [gmic, filter]
command: fx_organic_fibers
---

# Filtre G'MIC : fx_organic_fibers

## Structure de la commande
```text
fx_organic_fibers:
    agent_density = $1
    iterations = $2
    orientations = $3
    sensor_distance_px = $4
    sensor_angle_deg = $5
    motion_distance_px = $6
    motion_angle_deg = $7
    moment = $8
    trail_blur_px = $9
    particle_size_px = $10
    particle_thickness = $11
    quantize_orientations = $12
    opacity = $13
    sharpening = $14
    palette = $15
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a texture resembling organic fibers. 
(Note) : <span color="#EE5500">Global Parameters:</span>
* **`Agent Density (%)` ($1)** (float) : défaut = **20**  (0,50)
* **`Iterations` ($2)** (int) : défaut = **20**  (1,256)
* **`Orientations` ($3)** (int) : défaut = **3**  (2,16)
(Note) : <span color="#EE5500">Sensor Parameters:</span>
* **`Sensor Distance (px)` ($4)** (int) : défaut = **15**  (0,400)
* **`Sensor Angle (deg.)` ($5)** (float) : défaut = **15**  (0,180)
(Note) : <span color="#EE5500">Motion Parameters:</span>
* **`Motion Distance (px)` ($6)** (int) : défaut = **3**  (0,400)
* **`Motion Angle (deg.)` ($7)** (float) : défaut = **15**  (0,180)
* **`Moment (%)` ($8)** (float) : défaut = **30**  (0,100)
* **`Trail Blur (px)` ($9)** (float) : défaut = **1**  (0,20)
(Note) : <span color="#EE5500">Rendering Parameters:</span>
* **`Particle Size (px)` ($10)** (int) : défaut = **19**  (1,128)
* **`Particle Thickness (%)` ($11)** (float) : défaut = **10**  (0,100)
* **`Quantize Orientations` ($12)** (int) : défaut = **24**  (1,32)
* **`Opacity (%)` ($13)** (float) : défaut = **50**  (0,100)
* **`Sharpening (%)` ($14)** (float) : défaut = **0**  (0,100)
* **`Palette` ($15)** (choice) : choix possibles => Default, HSV, Lines, Hot, Cool, Jet, Flag, Cube, Rainbow, Parula, Spring, Summer, Autumn, Winter, Bone, Copper, Pink, Vga, Algae, Amp, Balance, Curl, Deep, Delta, Dense, Diff, Gray, Haline, Ice, Matter, Oxy, Phase, Rain, Solar, Speed, Tarn, Tempo, Thermal, Topo, Turbid, Aurora, Hocuspocus, SRB2, Uzebox, Amiga7800, Amiga7800mess, Fornaxvoid1
(Note) : This filter has been inspired by the following web page, written by Etienne Jacob (aka Bleuje):
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2025/07/14.
