---
tags: [gmic, filter]
command: fx_extrude25d
---

# Filtre G'MIC : fx_extrude25d

## Structure de la commande
```text
fx_extrude25d:
    depth = $1
    angle_x = $2
    angle_y = $3
    shear = $4
    negate = $5
    normal_smoothness = $6
    color_shading = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Extrudes 2D shapes to simulate depth (2.5D). 
* **`Depth (%)` ($1)** (float) : défaut = **10**  (0,100)
* **`Angle` ($2)** (point) : position = 0,0
* **`Shear (%)` ($3)** (float) : défaut = **25**  (0,100)
* **`Negate` ($4)** (bool) : par défaut = Faux (0)
* **`Normal Smoothness` ($5)** (float) : défaut = **10**  (0,50)
* **`Color Shading (%)` ($6)** (float) : défaut = **50**  (0,100)
* **`Top Color` ($7)** (color) : défaut = 255,200,0
* **`Right Color` ($8)** (color) : défaut = 255,128,0
* **`Bottom Color` ($9)** (color) : défaut = 128,64,0
* **`Left Color` ($10)** (color) : défaut = 64,0,0
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2025/01/31.
