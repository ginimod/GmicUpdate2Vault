---
tags: [gmic, filter]
command: fx_frame_fuzzy
---

# Filtre G'MIC : fx_frame_fuzzy

## Structure de la commande
```text
fx_frame_fuzzy:
    horizontal_size = $1
    vertical_size = $2
    fuzziness = $3
    smoothness = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds a fuzzy, irregular border. 
* **`Horizontal Size (%)` ($1)** (float) : défaut = **5**  (0,100)
* **`Vertical Size (%)` ($2)** (float) : défaut = **5**  (0,100)
* **`Fuzziness` ($3)** (float) : défaut = **10**  (0,40)
* **`Smoothness` ($4)** (float) : défaut = **1**  (0,5)
* **`Color` ($5)** (color) : défaut = 255,255,255,255
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
