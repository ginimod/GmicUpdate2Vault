---
tags: [gmic, filter]
command: cl_comic
---

# Filtre G'MIC : cl_comic

## Structure de la commande
```text
cl_comic:
    simplification = $1
    flattening_for_edge_bilateral = $2
    edge_method = $3
    edge_desaturation_method = $4
    line_thickness = $5
    line_strength = $6
    line_antialias = $7
    add_colors = $8
    luminosity_increase = $9
    saturation_increase = $10
    final_flattening_bilateral = $11
    color_effect = $12
    flat_color_effect = $13
    colors_to_black_or_white = $14
    relief_effect = $15
    special_effect = $16
    final_antialias = $17
    preview_type = $18
    preview_split_x = $19
    preview_split_y = $20
```
## Définition des variables
(Note) : Note: Photo to cartoon
(Note) :  
* **`Simplification` ($1)** (choice) : choix possibles => None, Light, Light Antialias, Strong Antialias, Median, Iuwt, Thin Brush, Mean Curvature
(Note) : For edges:
* **`Flattening for Edge (bilateral)` ($2)** (int) : défaut = **2**  (0,5)
* **`Edge Method` ($3)** (choice) : choix possibles => Diff. of Gauss., Diff. of BoxBlur, Diff. of Median
* **`Edge Desaturation Method` ($4)** (choice) : choix possibles => Lightness, MaxRGB, MinRGB
* **`Line Thickness` ($5)** (float) : défaut = **1**  (0.5,2)
* **`Line Strength` ($6)** (float) : défaut = **15**  (0,19)
* **`Line Antialias` ($7)** (int) : défaut = **15**  (0,100)
* **`Add Colors` ($8)** (bool) : par défaut = Faux (0)
(Note) : For colors:
* **`Luminosity Increase` ($9)** (int) : défaut = **10**  (0,50)
* **`Saturation Increase` ($10)** (int) : défaut = **20**  (0,50)
* **`Final Flattening (bilateral)` ($11)** (int) : défaut = **6**  (0,10)
* **`Color Effect` ($12)** (choice) : choix possibles => None, Deep Black, Local Contrast Enhancement, Colorful
* **`Flat Color Effect` ($13)** (choice) : choix possibles => None, Rainbow, Hard Rainbow, Posterize Softly, Super Flat
* **`Colors to Black or White` ($14)** (choice) : choix possibles => No, Soft Threshold, Threshold with Soft Antialias, Lines and Black
* **`Relief Effect` ($15)** (choice) : choix possibles => None, Groove, Bump
* **`Special Effect` ($16)** (choice) : choix possibles => None, Dream, Past, Sketch of Future
* **`Final Antialias` ($17)** (choice) : choix possibles => None, Simple, Double
* **`Preview Type` ($18)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($19)** (point) : position = 0,0
(Note) : Author: Claude Lion.      Latest Update: 2022/05/10.
(Note) : It uses filters of David Tschumperlé and a few filters of Jérôme Boulanger.
