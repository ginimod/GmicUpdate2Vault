---
tags: [gmic, filter]
command: fx_colorize_interactive
---

# Filtre G'MIC : fx_colorize_interactive

## Structure de la commande
```text
fx_colorize_interactive:
    input_type = $1
    output_type = $2
    view_resolution = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds color to B&W images using user-placed color control points. 
* **`Input Type` ($1)** (choice) : choix possibles => B&W Photograph, Lineart
* **`Output Type` ($2)** (choice) : choix possibles => Colorized Image (1 Layer), Colors Only (1 Layer), Image + Colors (2 Layers), Image + Colors (Multi-Layers)
* **`View Resolution` ($3)** (choice) : choix possibles => Small (Faster), Medium, High (Slower), Very High (Even Slower)
(Note) : Description:
 This filter lets you quickly colorize a B&W image or lineart. Click on the Apply or OK buttons below to open the G'MIC interactive window and start adding color control points. When you're done, exit the interactive window: your colored result will be transferred back to the host software.

 If you are not satisfied with the result, Undo it (CTRL+Z), and click on Apply once again to modify your control points defined previously. To clear all control points, click on the Reset button above. 
(Note) : Interactions:
 Use the following actions in the interactive window to manage your colorization:

 - Left mouse button creates a new color control point (or move an existing one).
 - Right mouse button or key X over a control point deletes it.
 - Right mouse button or key P anywhere else picks a color from the image.
 - Mouse wheel, or keys CTRL+arrows up/down zoom view in/out.
 - CTRL+mouse wheel, SHIFT+wheel or arrow keys move image in zoomed view.
 - Key SPACE updates the extrapolated color field.
 - Key TAB toggles markers view modes.
 - Key BACKSPACE deletes the last control point added.
 - Key PAGE UP increases image contrast.
 - Key PAGE DOWN decreases image contrast.
 - Key R enters/exits color replace mode.
 - Keys CTRL+D increase window size.
 - Keys CTRL+C decrease window size.
 - Keys CTRL+R resets window size.
 - Keys ESC, Q or RETURN exit the interactive window. 
(Note) : You can find more information on how to use this filter here:
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/07/12.
