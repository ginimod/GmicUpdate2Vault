---
tags: [gmic, filter]
command: afre_texture
---

# Filtre G'MIC : afre_texture

## Structure de la commande
```text
afre_texture:
    coarse = $1
    medium = $2
    fine = $3
```
## Définition des variables
(Note) : <strong>Enhance texture with detail scales.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2020 Aug10-18.</strong>


(Note) : <strong>Detail Scale</strong>
* **`Coarse` ($1)** (int) : défaut = **0**  (-100,100)
* **`Medium` ($2)** (int) : défaut = **0**  (-100,100)
* **`Fine` ($3)** (int) : défaut = **0**  (-100,100)
(Note) : 

<strong>Note</strong>

G'MIC's preview is inaccurate. Apply the filter and review the results in your host editor.
