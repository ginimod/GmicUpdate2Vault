---
tags: [gmic, filter]
command: fx_mix_ycbcr
---

# Filtre G'MIC : fx_mix_ycbcr

## Structure de la commande
```text
fx_mix_ycbcr:
    luminance_factor = $1
    luminance_shift = $2
    luminance_smoothness = $3
    blue_chroma_factor = $4
    blue_chroma_shift = $5
    blue_chroma_smoothness = $6
    red_chroma_factor = $7
    red_chroma_shift = $8
    red_chroma_smoothness = $9
    tones_range = $10
    tones_smoothness = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Mixes channels using the YCbCr color model. 
* **`Luminance Factor` ($1)** (float) : défaut = **1**  (0,4)
* **`Luminance Shift` ($2)** (float) : défaut = **0**  (-255,255)
* **`Luminance Smoothness` ($3)** (float) : défaut = **0**  (0,10)
* **`Blue Chroma Factor` ($4)** (float) : défaut = **1**  (0,4)
* **`Blue Chroma Shift` ($5)** (float) : défaut = **0**  (-255,255)
* **`Blue Chroma Smoothness` ($6)** (float) : défaut = **0**  (0,10)
* **`Red Chroma Factor` ($7)** (float) : défaut = **1**  (0,4)
* **`Red Chroma Shift` ($8)** (float) : défaut = **0**  (-255,255)
* **`Red Chroma Smoothness` ($9)** (float) : défaut = **0**  (0,10)
* **`Tones Range` ($10)** (choice) : choix possibles => All Tones, Shadows, Mid-Tones, Highlights
* **`Tones Smoothness` ($11)** (float) : défaut = **2**  (0,10)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/06/20.
