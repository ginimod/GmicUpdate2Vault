---
tags: [gmic, filter]
command: fx_fire_edges
---

# Filtre G'MIC : fx_fire_edges

## Structure de la commande
```text
fx_fire_edges:
    edges = $1
    attenuation = $2
    smoothness = $3
    threshold = $4
    number_of_frames = $5
    starting_frame = $6
    frame_skip = $7
    preview_type = $8
    preview_split_x = $9
    preview_split_y = $10
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Creates an animation of edges burning. 
* **`Edges` ($1)** (float) : défaut = **0.7**  (0,3)
* **`Attenuation` ($2)** (float) : défaut = **0.25**  (0,1)
* **`Smoothness` ($3)** (float) : défaut = **0.5**  (0,5)
* **`Threshold` ($4)** (float) : défaut = **25**  (0,100)
* **`Number of Frames` ($5)** (int) : défaut = **20**  (1,999)
* **`Starting Frame` ($6)** (int) : défaut = **20**  (0,199)
* **`Frame Skip` ($7)** (int) : défaut = **0**  (0,20)
* **`Preview Type` ($8)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($9)** (point) : position = 0,0
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2011/07/06.
