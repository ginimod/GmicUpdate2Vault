---
tags: [gmic, filter]
command: fx_metalgrain
---

# Filtre G'MIC : fx_metalgrain

## Structure de la commande
```text
fx_metalgrain:
    intensity = $1
    swap_layers = $2
    preview_type = $3
```
## Définition des variables
(Note) : add a metallic grain adapt to pictorial and special effects
(Note) : dependent from 'Couleurs Metalliques' by Samj
* **`Intensity` ($1)** (float) : défaut = **0.5**  (0.1,1)
* **`Swap Layers` ($2)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($3)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author: PhotoComix,a hack of a Samj filter.      Latest update : 2012/29/02.
