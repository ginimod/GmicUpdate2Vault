---
tags: [gmic, filter]
command: fx_dreamsmooth
---

# Filtre G'MIC : fx_dreamsmooth

## Structure de la commande
```text
fx_dreamsmooth:
    iterations = $1
    equalize_at_each_step = $2
    merging_option = $3
    opacity = $4
    reverse_order = $5
    smoothness = $6
    parallel_processing = $7
    spatial_overlap = $8
    preview_type = $9
```
## Définition des variables
(Note) : Updated for 1.5.4.0
(Note) : A relatively slow filter that uses anisotropic filtering to smooth an image. More iterations produces softer image as does lower opacity values. Practical modes for merging are Alpha and Average. Note that results are resolution dependent.
(Note) : General settings
* **`Iterations` ($1)** (int) : défaut = **3**  (1,10)
* **`Equalize at Each Step` ($2)** (bool) : par défaut = Faux (0)
(Note) : Merging of iterations
* **`Merging Option` ($3)** (choice) : choix possibles => Add, Alpha, And, Average, Blue, Burn, Darken, Difference, Divide, Dodge, Exclusion, Freeze, Grainextract, Grainmerge, Green, Hardlight, Hardmix, Hue, Interpolation, Lighten, Lightness, Linearburn, Linearlight, Luminance, Multiply, Negation, Or, Overlay, Pinlight, Red, Reflect, Saturation, Screen, Shapeaverage, Softburn, Softdodge, Softlight, Stamp, Subtract, Value, Vividlight, Xor, Edges
* **`Opacity` ($4)** (float) : défaut = **0.8**  (0,1)
* **`Reverse Order` ($5)** (bool) : par défaut = Faux (0)
(Note) : Settings for layer mode edges
* **`Smoothness` ($6)** (float) : défaut = **0.8**  (0,5)
(Note) : Parallel processing settings. Increase spatial overlap if vertical bands appear.
* **`Parallel Processing` ($7)** (choice) : choix possibles => Auto, One Thread, Two Threads, Four Threads, Eight Threads, Sixteen Threads
* **`Spatial Overlap` ($8)** (int) : défaut = **24**  (0,256)
* **`Preview Type` ($9)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) :  Author: Arto Huotari Latest update : 2014/02/20.
