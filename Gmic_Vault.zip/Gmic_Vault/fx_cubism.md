---
tags: [gmic, filter]
command: fx_cubism
---

# Filtre G'MIC : fx_cubism

## Structure de la commande
```text
fx_cubism:
    iterations = $1
    density = $2
    thickness = $3
    angle = $4
    opacity = $5
    smoothness = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Transforms the image into a cubist-style composition of rotated rectangles. 
* **`Iterations` ($1)** (int) : défaut = **2**  (0,10)
* **`Density` ($2)** (float) : défaut = **50**  (0,200)
* **`Thickness` ($3)** (float) : défaut = **10**  (0,50)
* **`Angle` ($4)** (float) : défaut = **90**  (0,360)
* **`Opacity` ($5)** (float) : défaut = **0.7**  (0.01,1)
* **`Smoothness` ($6)** (float) : défaut = **0**  (0,5)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2013/06/05.
