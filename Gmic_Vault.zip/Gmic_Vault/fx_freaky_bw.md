---
tags: [gmic, filter]
command: fx_freaky_bw
---

# Filtre G'MIC : fx_freaky_bw

## Structure de la commande
```text
fx_freaky_bw:
    strength = $1
    oddness = $2
    brightness = $3
    contrast = $4
    gamma = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Creates a high-contrast, dramatic black and white effect. 
* **`Strength (%)` ($1)** (float) : défaut = **90**  (0,100)
* **`Oddness (%)` ($2)** (float) : défaut = **20**  (0,100)
* **`Brightness (%)` ($3)** (float) : défaut = **0**  (-100,100)
* **`Contrast (%)` ($4)** (float) : défaut = **0**  (-100,100)
* **`Gamma (%)` ($5)** (float) : défaut = **0**  (-100,100)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/09/30.
