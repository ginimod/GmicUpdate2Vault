---
tags: [gmic, filter]
command: fx_crayongraffiti2
---

# Filtre G'MIC : fx_crayongraffiti2

## Structure de la commande
```text
fx_crayongraffiti2:
    amplitude = $1
    density = $2
    smoothness = $3
    opacity = $4
    edge = $5
    fast_approximation = $6
    color_smoothness = $7
    mixer_style = $8
    preview_type = $9
```
## Définition des variables
* **`Amplitude` ($1)** (float) : défaut = **300**  (0,4000)
* **`Density` ($2)** (float) : défaut = **50**  (0,100)
* **`Smoothness` ($3)** (float) : défaut = **1**  (0,10)
* **`Opacity` ($4)** (float) : défaut = **0.4**  (0,1)
* **`Edge` ($5)** (float) : défaut = **12**  (0,50)
* **`Fast Approximation` ($6)** (bool) : par défaut = Faux (0)
* **`Color Smoothness` ($7)** (float) : défaut = **2**  (1,30)
* **`Mixer Style` ($8)** (choice) : choix possibles => Lightness, Value, Color Doping
* **`Preview Type` ($9)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author: PhotoComiX.      Latest update : 2011/07/12.
