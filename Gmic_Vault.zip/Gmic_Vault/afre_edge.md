---
tags: [gmic, filter]
command: afre_edge
---

# Filtre G'MIC : afre_edge

## Structure de la commande
```text
afre_edge:
    method = $1
    thinning = $2
    recovery = $3
    brightness = $4
    details = $5
```
## Définition des variables
(Note) : <strong>Compute edge.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2019-2020 May3.</strong>


* **`Method` ($1)** (choice) : choix possibles => Gradient, Standard Deviation
* **`Thinning` ($2)** (int) : défaut = **1**  (1,10)
* **`Recovery` ($3)** (float) : défaut = **1**  (0.5,4)
* **`Brightness` ($4)** (float) : défaut = **1**  (0.5,4)
* **`Details` ($5)** (float) : défaut = **1**  (0.5,4)
