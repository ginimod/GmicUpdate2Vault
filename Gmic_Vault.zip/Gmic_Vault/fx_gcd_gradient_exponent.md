---
tags: [gmic, filter]
command: fx_gcd_gradient_exponent
---

# Filtre G'MIC : fx_gcd_gradient_exponent

## Structure de la commande
```text
fx_gcd_gradient_exponent:
    exponent = $1
    channels = $2
```
## Définition des variables
(Note) : Adjust global gradient ratios
* **`Exponent` ($1)** (float) : défaut = **0.5**  (0,2)
* **`Channels` ($2)** (choice) : choix possibles => RGB, HSI, HSV, YCbCr, Lab
(Note) : Author : Garagecoder.      Latest update : 2022/09/02.
