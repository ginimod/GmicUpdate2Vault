---
tags: [gmic, filter]
command: fx_elevation3d
---

# Filtre G'MIC : fx_elevation3d

## Structure de la commande
```text
fx_elevation3d:
    factor = $1
    smoothness = $2
    width = $3
    height = $4
    size = $5
    x_angle = $6
    y_angle = $7
    z_angle = $8
    fov = $9
    x_light = $10
    y_light = $11
    z_light = $12
    specular_lightness = $13
    specular_shininess = $14
    rendering = $15
    antialiasing = $16
    top_layer_defines_object_texture = $17
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Renders the image as a 3D terrain heightmap. 
* **`Factor` ($1)** (float) : défaut = **100**  (-1000,1000)
* **`Smoothness` ($2)** (float) : défaut = **1**  (0,10)
* **`Width` ($3)** (int) : défaut = **1024**  (8,4096)
* **`Height` ($4)** (int) : défaut = **1024**  (8,4096)
* **`Size` ($5)** (float) : défaut = **0.8**  (0,3)
* **`X-Angle` ($6)** (float) : défaut = **25**  (0,360)
* **`Y-Angle` ($7)** (float) : défaut = **0**  (0,360)
* **`Z-Angle` ($8)** (float) : défaut = **21**  (0,360)
* **`FOV` ($9)** (float) : défaut = **45**  (1,90)
* **`X-Light` ($10)** (float) : défaut = **0**  (-100,100)
* **`Y-Light` ($11)** (float) : défaut = **0**  (-100,100)
* **`Z-Light` ($12)** (float) : défaut = **-100**  (-100,0)
* **`Specular Lightness` ($13)** (float) : défaut = **0.5**  (0,1)
* **`Specular Shininess` ($14)** (float) : défaut = **0.7**  (0,3)
* **`Rendering` ($15)** (choice) : choix possibles => Dots, Wireframe, Flat, Flat-Shaded, Gouraud, Phong
* **`Antialiasing` ($16)** (bool) : par défaut = Faux (0)
* **`Top Layer Defines Object Texture` ($17)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2021/11/10.
