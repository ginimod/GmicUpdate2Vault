---
tags: [gmic, filter]
command: fx_animate_extrude3d
---

# Filtre G'MIC : fx_animate_extrude3d

## Structure de la commande
```text
fx_animate_extrude3d:
    frames = $1
    output_as_frames = $2
    output_as_files = $3
    depth = $5
    resolution = $6
    smoothness = $7
    width = $8
    height = $9
    rendering = $10
    size = $11
    x_angle = $12
    y_angle = $13
    z_angle = $14
    fov = $15
    x_light = $16
    y_light = $17
    z_light = $18
    specular_lightness = $19
    specular_shininess = $20
    size = $21
    x_angle = $22
    y_angle = $23
    z_angle = $24
    fov = $25
    x_light = $26
    y_light = $27
    z_light = $28
    specular_lightness = $29
    specular_shininess = $30
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Creates an animation of a 3D extruded image. 
* **`Frames` ($1)** (int) : défaut = **10**  (2,100)
* **`Output as Frames` ($2)** (bool) : par défaut = Faux (0)
* **`Output as Files` ($3)** (bool) : par défaut = Faux (0)
(Note) : 
Global parameters :
* **`Depth` ($4)** (float) : défaut = **10**  (1,256)
* **`Resolution` ($5)** (int) : défaut = **512**  (1,1024)
* **`Smoothness` ($6)** (float) : défaut = **0.6**  (0,3)
* **`Width` ($7)** (int) : défaut = **1024**  (8,4096)
* **`Height` ($8)** (int) : défaut = **1024**  (8,4096)
* **`Rendering` ($9)** (choice) : choix possibles => Dots, Wireframe, Flat, Flat-Shaded, Gouraud, Phong
(Note) : 
Starting parameters :
* **`Size` ($10)** (float) : défaut = **0.8**  (0,3)
* **`X-Angle` ($11)** (float) : défaut = **35**  (0,360)
* **`Y-Angle` ($12)** (float) : défaut = **0**  (0,360)
* **`Z-Angle` ($13)** (float) : défaut = **0**  (0,360)
* **`FOV` ($14)** (float) : défaut = **45**  (1,90)
* **`X-Light` ($15)** (float) : défaut = **0**  (-100,100)
* **`Y-Light` ($16)** (float) : défaut = **0**  (-100,100)
* **`Z-Light` ($17)** (float) : défaut = **-100**  (-100,0)
* **`Specular Lightness` ($18)** (float) : défaut = **0.5**  (0,1)
* **`Specular Shininess` ($19)** (float) : défaut = **0.7**  (0,3)
(Note) : 
Ending parameters :
* **`Size` ($20)** (float) : défaut = **0.8**  (0,3)
* **`X-Angle` ($21)** (float) : défaut = **35**  (0,1440)
* **`Y-Angle` ($22)** (float) : défaut = **360**  (0,1440)
* **`Z-Angle` ($23)** (float) : défaut = **0**  (0,1440)
* **`FOV` ($24)** (float) : défaut = **45**  (1,90)
* **`X-Light` ($25)** (float) : défaut = **0**  (-100,100)
* **`Y-Light` ($26)** (float) : défaut = **0**  (-100,100)
* **`Z-Light` ($27)** (float) : défaut = **-100**  (-100,0)
* **`Specular Lightness` ($28)** (float) : défaut = **0.5**  (0,1)
* **`Specular Shininess` ($29)** (float) : défaut = **0.7**  (0,3)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
