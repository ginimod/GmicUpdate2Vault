---
tags: [gmic, filter]
command: fisheye
---

# Filtre G'MIC : fisheye

## Structure de la commande
```text
fisheye:
    center_x = $1
    center_y = $2
    radius = $3
    amplitude = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Applies a fish-eye lens effect. 
* **`Center (%)` ($1)** (point) : position = 0,0
* **`Radius` ($2)** (float) : défaut = **70**  (0,100)
* **`Amplitude` ($3)** (float) : défaut = **1**  (0,2)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
