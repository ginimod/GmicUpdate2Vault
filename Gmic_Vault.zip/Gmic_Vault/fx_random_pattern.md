---
tags: [gmic, filter]
command: fx_random_pattern
---

# Filtre G'MIC : fx_random_pattern

## Structure de la commande
```text
fx_random_pattern:
    size = $1
    min_detail_level = $2
    seed = $3
    brightness = $5
    contrast = $6
    gamma = $7
    hue = $8
    saturation = $9
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a random noise-based pattern. 
* **`Size` ($1)** (int) : défaut = **1024**  (16,8192)
* **`Min Detail Level` ($2)** (float) : défaut = **2**  (0,20)
* **`Seed` ($3)** (float) : défaut = **4038**  (0,100000)
* **`Brightness (%)` ($4)** (float) : défaut = **0**  (-100,100)
* **`Contrast (%)` ($5)** (float) : défaut = **0**  (-100,100)
* **`Gamma (%)` ($6)** (float) : défaut = **0**  (-100,100)
* **`Hue (%)` ($7)** (float) : défaut = **0**  (-100,100)
* **`Saturation (%)` ($8)** (float) : défaut = **0**  (-100,100)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2020/10/08.
