---
tags: [gmic, filter]
command: fx_lissajous
---

# Filtre G'MIC : fx_lissajous

## Structure de la commande
```text
fx_lissajous:
    resolution = $1
    x_size = $2
    y_size = $3
    z_size = $4
    x_multiplier = $5
    y_multiplier = $6
    z_multiplier = $7
    x_offset = $8
    y_offset = $9
    z_offset = $10
    x_angle = $11
    y_angle = $12
    z_angle = $13
    thickness = $14
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Draws Lissajous curves. 
* **`Resolution` ($1)** (int) : défaut = **4096**  (2,8192)
* **`X-Size` ($2)** (float) : défaut = **0.9**  (0,2)
* **`Y-Size` ($3)** (float) : défaut = **0.9**  (0,2)
* **`Z-Size` ($4)** (float) : défaut = **3**  (1,10)
* **`X-Multiplier` ($5)** (float) : défaut = **8**  (0,32)
* **`Y-Multiplier` ($6)** (float) : défaut = **7**  (0,32)
* **`Z-Multiplier` ($7)** (float) : défaut = **0**  (0,32)
* **`X-Offset` ($8)** (float) : défaut = **0**  (0,1)
* **`Y-Offset` ($9)** (float) : défaut = **0**  (0,1)
* **`Z-Offset` ($10)** (float) : défaut = **0**  (0,1)
* **`X-Angle` ($11)** (float) : défaut = **0**  (0,360)
* **`Y-Angle` ($12)** (float) : défaut = **0**  (0,360)
* **`Z-Angle` ($13)** (float) : défaut = **0**  (0,360)
* **`Thickness` ($14)** (float) : défaut = **4**  (0,50)
* **`Color` ($15)** (color) : défaut = 255,255,255,255
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2011/04/18.
