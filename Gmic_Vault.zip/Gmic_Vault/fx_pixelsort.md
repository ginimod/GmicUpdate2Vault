---
tags: [gmic, filter]
command: fx_pixelsort
---

# Filtre G'MIC : fx_pixelsort

## Structure de la commande
```text
fx_pixelsort:
    order = $1
    axis = $2
    sorting_criterion = $3
    mask_by = $4
    lower_mask_threshold = $5
    higher_mask_threshold = $6
    mask_smoothness = $7
    invert_mask = $8
    preview_mask = $9
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Sorts pixels (Glitch art). 
(Note) : Sorting parameters:
* **`Order` ($1)** (choice) : choix possibles => Decreasing, Increasing
* **`Axis` ($2)** (choice) : choix possibles => X-Axis, Y-Axis, X-Axis Then Y-Axis, Y-Axis Then X-Axis
* **`Sorting Criterion` ($3)** (choice) : choix possibles => Red, Green, Blue, Intensity, Luminance, Lightness, Hue, Saturation, Minimum, Maximum, Random
(Note) : Masking parameters:
* **`Mask By` ($4)** (choice) : choix possibles => Bottom Layer, Criterion, Contours, Random
* **`Lower Mask Threshold (%)` ($5)** (float) : défaut = **0**  (0,100)
* **`Higher Mask Threshold (%)` ($6)** (float) : défaut = **100**  (0,100)
* **`Mask Smoothness (%)` ($7)** (float) : défaut = **0**  (0,5)
* **`Invert Mask` ($8)** (bool) : par défaut = Faux (0)
* **`Preview Mask` ($9)** (bool) : par défaut = Faux (0)
(Note) : Note: This filter implements one version of the algorithm described here: 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2021/10/29.
