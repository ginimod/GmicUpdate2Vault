---
tags: [gmic, filter]
command: fx_contrast_swm
---

# Filtre G'MIC : fx_contrast_swm

## Structure de la commande
```text
fx_contrast_swm:
    blur_the_mask = $1
    skip_to_use_the_mask_to_boost = $2
    intensity = $3
```
## Définition des variables
* **`Blur the Mask` ($1)** (float) : défaut = **2**  (0.5,10)
(Note) : Contrast Mask need the negative of the mask
* **`Skip to Use the Mask to Boost` ($2)** (bool) : par défaut = Faux (0)
(Note) : Uncheck for Contrast Mask,Check for Contrast Boost
(Note) : Merge the Mask
* **`Intensity` ($3)** (float) : défaut = **1**  (0,1)
(Note) : Author: PhotoComiX.      Latest Update: 2011/01/01.
