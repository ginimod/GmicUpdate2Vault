---
tags: [gmic, filter]
command: eckert_iv_projection
---

# Filtre G'MIC : eckert_iv_projection

## Structure de la commande
```text
eckert_iv_projection:
    roll = $1
    pitch = $2
    yaw = $3
    central_longitude = $4
```
## Définition des variables
(Note) : Rotate an equirectangular map or panorama around three axises in order and output it as an Eckert IV projection.
* **`Roll` ($1)** (float) : défaut = **0**  (-360,360)
* **`Pitch` ($2)** (float) : défaut = **0**  (-360,360)
* **`Yaw` ($3)** (float) : défaut = **0**  (-360,360)
* **`Central Longitude` ($4)** (float) : défaut = **0**  (-180,180)
(Note) : Author: <a href="https://www.cartographersguild.com/showthread.php?t=47591">Kristian Järventaus</a>.      Latest Update: 2024/03/05.
