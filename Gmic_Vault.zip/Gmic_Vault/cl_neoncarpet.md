---
tags: [gmic, filter]
command: cl_neonCarpet
---

# Filtre G'MIC : cl_neonCarpet

## Structure de la commande
```text
cl_neonCarpet:
    sequence_number = $1
    item_number = $2
    invert = $3
```
## Définition des variables
* **`Sequence Number` ($1)** (int) : défaut = **0**  (0,200)
* **`Item Number` ($2)** (int) : défaut = **0**  (0,100)
* **`Invert` ($3)** (bool) : par défaut = Faux (0)
(Note) : Note: Some combinations of parameters give a completely black result
(Note) : Author: Claude Lion. Latest Update: 2024/12/11.
(Note) : It uses filters of David Tschumperlé and Andy Kelday (garagecoder)
