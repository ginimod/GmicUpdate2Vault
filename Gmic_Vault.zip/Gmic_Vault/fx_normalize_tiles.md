---
tags: [gmic, filter]
command: fx_normalize_tiles
---

# Filtre G'MIC : fx_normalize_tiles

## Structure de la commande
```text
fx_normalize_tiles:
    x_tile_size_px = $1
    y_tile_size_px = $2
    minimal_value = $3
    maximal_value = $4
    x_overlap = $5
    y_overlap = $6
    channel_s = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Normalizes the contrast of each tile in a grid individually. 
* **`X-Tile Size (px)` ($1)** (int) : défaut = **32**  (1,256)
* **`Y-Tile Size (px)` ($2)** (int) : défaut = **32**  (1,256)
* **`Minimal Value` ($3)** (float) : défaut = **0**  (0,255)
* **`Maximal Value` ($4)** (float) : défaut = **255**  (0,255)
* **`X-Overlap (%)` ($5)** (int) : défaut = **0**  (0,75)
* **`Y-Overlap (%)` ($6)** (int) : défaut = **0**  (0,75)
* **`Channel(s)` ($7)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2024/12/17.
