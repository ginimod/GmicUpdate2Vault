---
tags: [gmic, filter]
command: fx_bwfilmsimulate
---

# Filtre G'MIC : fx_bwfilmsimulate

## Structure de la commande
```text
fx_bwfilmsimulate:
    film_type_rgb_balance = $1
    red_level = $2
    red_smoothness = $3
    green_level = $4
    green_smoothness = $5
    blue_level = $6
    blue_smoothness = $7
    gamma = $8
    contrast = $9
    brightness = $10
    hue = $11
    saturation = $12
    grain_shadows = $13
    grain_midtones = $14
    grain_highlights = $15
    grain_tone_fading = $16
    grain_scale = $17
    grain_type = $18
    local_contrast = $19
    radius = $20
    contrast_smoothness = $21
    preview_type = $22
```
## Définition des variables
* **`Film Type / RGB Balance` ($1)** (choice) : choix possibles => Manual, Agfa 200X, Agfapan 25, Agfapan 100, Agfapan 400, Iford Delta 100, Iford Delta 400, Iford Delta 400 Pro & 3200, Ilford FP4, Ilford HP4, Ilford Pan F, Ilford SFX, Ilford XP2 Super, Kodak Tmax 100, Kodak Tmax 400, Kodak Tri-X
(Note) : Simpler version available in main tree. This filter will be removed in future from testing. PM me if you need this for some reason.
(Note) : RGB sliders work only with manual selection
* **`Red Level` ($2)** (float) : défaut = **0.299**  (0,1)
* **`Red Smoothness` ($3)** (float) : défaut = **0**  (0,10)
* **`Green Level` ($4)** (float) : défaut = **0.587**  (0,1)
* **`Green Smoothness` ($5)** (float) : défaut = **0**  (0,10)
* **`Blue Level` ($6)** (float) : défaut = **0.114**  (0,1)
* **`Blue Smoothness` ($7)** (float) : défaut = **0**  (0,10)
* **`Gamma` ($8)** (float) : défaut = **1**  (0.01,5)
* **`Contrast` ($9)** (float) : défaut = **1**  (0,4)
* **`Brightness` ($10)** (float) : défaut = **0**  (-255,255)
* **`Hue` ($11)** (float) : défaut = **0**  (0,360)
* **`Saturation` ($12)** (float) : défaut = **0**  (0,1)
* **`Grain (Shadows)` ($13)** (float) : défaut = **0**  (0,200)
* **`Grain (Midtones)` ($14)** (float) : défaut = **0**  (0,200)
* **`Grain (Highlights)` ($15)** (float) : défaut = **0**  (0,200)
* **`Grain Tone Fading` ($16)** (float) : défaut = **2**  (0,10)
* **`Grain Scale` ($17)** (float) : défaut = **0**  (0,3)
* **`Grain Type` ($18)** (choice) : choix possibles => Gaussian, Uniform, Salt and Pepper, Poisson
* **`Local Contrast` ($19)** (float) : défaut = **0**  (0,60)
* **`Radius` ($20)** (int) : défaut = **16**  (1,512)
* **`Contrast Smoothness` ($21)** (float) : défaut = **4**  (0,10)
* **`Preview Type` ($22)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author : David Tschumperl&#233, Arto Huotari;.      Latest update : 2019/09/28.
