---
tags: [gmic, filter]
command: afre_brightness
---

# Filtre G'MIC : afre_brightness

## Structure de la commande
```text
afre_brightness:
    amount = $1
    smooth = $2
```
## Définition des variables
(Note) : <strong>Enhance luminance brightness.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2020-2021 Jan8.</strong>


* **`Amount` ($1)** (int) : défaut = **50**  (-300,300)
* **`Smooth` ($2)** (int) : défaut = **0**  (0,50)
(Note) : 

<strong>Note</strong>

G'MIC's preview is inaccurate. Apply the filter and review the results in your host editor.
