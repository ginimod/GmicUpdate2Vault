---
tags: [gmic, filter]
command: fx_jfif_xt
---

# Filtre G'MIC : fx_jfif_xt

## Structure de la commande
```text
fx_jfif_xt:
    1_quality = $1
    2_size_x = $2
    3_size_y = $3
```
## Définition des variables
(Note) : A poorly-implemented JFIF encoder with extras, all designed to screw with images. Quite slow and very aggressive.
* **`1. Quality (%)` ($1)** (float) : défaut = **50**  (0,100)
* **`2. Size X` ($2)** (int) : défaut = **8**  (1,100)
* **`3. Size Y` ($3)** (int) : défaut = **8**  (1,100)
