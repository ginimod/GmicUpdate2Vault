---
tags: [gmic, filter]
command: fx_cracks
---

# Filtre G'MIC : fx_cracks

## Structure de la commande
```text
fx_cracks:
    density = $1
    relief = $2
    channel_s = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates procedural crack patterns. 
* **`Density (%)` ($1)** (float) : défaut = **30**  (0,100)
* **`Relief` ($2)** (bool) : par défaut = Faux (0)
* **`Color` ($3)** (color) : défaut = 255,255,255,128
* **`Channel(s)` ($4)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/07/20.
