---
tags: [gmic, filter]
command: fx_gcd_blend_multiscale
---

# Filtre G'MIC : fx_gcd_blend_multiscale

## Structure de la commande
```text
fx_gcd_blend_multiscale:
    scales = $1
```
## Définition des variables
(Note) : Alpha blend with multiscale laplacian filter
(Note) : * Set Input layers to Active & below for two layers
* **`Scales` ($1)** (int) : défaut = **5**  (1,10)
(Note) : Author : Garagecoder.      Latest update : 2022/05/29.
(Note) : 
<u>Notes</u>
(Note) : Top layer must have an opacity channel
(Note) : Blending occurs at the edges of an opaque region
(Note) : Higher scales increase blend distance and cpu cost
