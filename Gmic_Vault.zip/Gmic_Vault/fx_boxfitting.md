---
tags: [gmic, filter]
command: fx_boxfitting
---

# Filtre G'MIC : fx_boxfitting

## Structure de la commande
```text
fx_boxfitting:
    minimal_size = $1
    maximal_size = $2
    initial_density = $3
    minimal_spacing = $4
    transparency = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Fills the image with non-overlapping colored boxes. 
* **`Minimal Size` ($1)** (int) : défaut = **3**  (1,32)
* **`Maximal Size` ($2)** (int) : défaut = **0**  (0,32)
(Note) : Note: Set Maximal size to 0 to allow any size for the squares.
* **`Initial Density` ($3)** (float) : défaut = **0.25**  (0,1)
* **`Minimal Spacing` ($4)** (int) : défaut = **2**  (1,16)
* **`Transparency` ($5)** (bool) : par défaut = Faux (0)
(Note) : Note: This filter has been highly inspired by the work of Jared Tarbell, described on the page:
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2013/06/06.
