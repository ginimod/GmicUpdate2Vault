---
tags: [gmic, filter]
command: fx_fourier_picture_watermark
---

# Filtre G'MIC : fx_fourier_picture_watermark

## Structure de la commande
```text
fx_fourier_picture_watermark:
    relative_size = $1
```
## Définition des variables
* **`Relative Size` ($1)** (float) : défaut = **0.2**  (0.1,0.5)
(Note) : Note : To make the watermark visible afterwards, use the 'Fourier Analysis' filter. 
