---
tags: [gmic, filter]
command: fx_pencilbw
---

# Filtre G'MIC : fx_pencilbw

## Structure de la commande
```text
fx_pencilbw:
    size = $1
    amplitude = $2
    hue = $3
    saturation = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates a standard pencil drawing. 
* **`Size` ($1)** (float) : défaut = **0.3**  (0,5)
* **`Amplitude` ($2)** (float) : défaut = **60**  (0,200)
* **`Hue` ($3)** (float) : défaut = **0**  (0,360)
* **`Saturation` ($4)** (float) : défaut = **0**  (0,1)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2013/03/05.
