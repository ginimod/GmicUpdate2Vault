---
tags: [gmic, filter]
command: fx_frame_blur
---

# Filtre G'MIC : fx_frame_blur

## Structure de la commande
```text
fx_frame_blur:
    horizontal_size = $1
    vertical_size = $2
    crop = $3
    blur = $4
    roundness = $5
    apply_color_balance = $6
    normalization = $10
    outline_size = $11
    x_shadow = $15
    y_shadow = $16
    shadow_smoothness = $17
    shadow_contrast = $18
    x_centering = $19
    y_centering = $20
    angle = $21
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds a blurred border derived from the image content. 
* **`Horizontal Size (%)` ($1)** (float) : défaut = **30**  (0,100)
* **`Vertical Size (%)` ($2)** (float) : défaut = **30**  (0,100)
* **`Crop` ($3)** (float) : défaut = **0**  (0,100)
* **`Blur` ($4)** (float) : défaut = **5**  (0,10)
* **`Roundness` ($5)** (float) : défaut = **0**  (0,1)
* **`Apply Color Balance` ($6)** (bool) : par défaut = Faux (0)
* **`Balance Color` ($7)** (color) : défaut = 128,128,128
* **`Normalization` ($8)** (choice) : choix possibles => None, Stretch, Equalize
* **`Outline Size` ($9)** (float) : défaut = **5**  (0,50)
* **`Outline Color` ($10)** (color) : défaut = 255,255,255
* **`X-Shadow` ($11)** (float) : défaut = **2**  (-10,10)
* **`Y-Shadow` ($12)** (float) : défaut = **2**  (-10,10)
* **`Shadow Smoothness` ($13)** (float) : défaut = **1**  (0,5)
* **`Shadow Contrast` ($14)** (float) : défaut = **0**  (0,100)
* **`X-Centering` ($15)** (float) : défaut = **0.5**  (0,1)
* **`Y-Centering` ($16)** (float) : défaut = **0.5**  (0,1)
* **`Angle` ($17)** (float) : défaut = **0**  (-180,180)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2014/01/19.
