---
tags: [gmic, filter]
command: fx_charcoal
---

# Filtre G'MIC : fx_charcoal

## Structure de la commande
```text
fx_charcoal:
    granularity = $1
    lowlights_crossover_point = $2
    highlights_crossover_point = $3
    boost_contrast = $4
    resize_image_for_optimum_effect = $5
    add_chalk_highlights = $6
    minimal_highlights = $7
    maximal_highlights = $8
    invert_background_foreground = $15
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates a charcoal drawing. 
* **`Granularity` ($1)** (int) : défaut = **65**  (0,800)
* **`Lowlights Crossover Point` ($2)** (int) : défaut = **70**  (0,255)
* **`Highlights Crossover Point` ($3)** (int) : défaut = **170**  (0,255)
* **`Boost Contrast` ($4)** (bool) : par défaut = Faux (0)
* **`Resize Image for Optimum Effect` ($5)** (bool) : par défaut = Faux (0)
* **`Add Chalk Highlights` ($6)** (bool) : par défaut = Faux (0)
* **`Minimal Highlights` ($7)** (int) : défaut = **50**  (0,255)
* **`Maximal Highlights` ($8)** (int) : défaut = **70**  (0,255)
* **`Background Color` ($9)** (color) : défaut = 255,255,255
* **`Foreground Color` ($10)** (color) : défaut = 0,0,0
* **`Invert Background / Foreground` ($11)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2011/03/17.
(Note) : Inspired from the Charcoal script by micomicon.
