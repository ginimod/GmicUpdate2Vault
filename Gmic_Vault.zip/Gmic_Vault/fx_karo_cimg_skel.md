---
tags: [gmic, filter]
command: fx_karo_cimg_skel
---

# Filtre G'MIC : fx_karo_cimg_skel

## Structure de la commande
```text
fx_karo_cimg_skel:
    auto_threshold = $1
    threshold = $2
    size_median = $3
    invert = $4
    threshold_on_flux = $5
    medial_curve = $6
    torsello_correction = $7
    discrete_step = $8
    preview_type = $9
    preview_split_x = $10
    preview_split_y = $11
```
## Définition des variables
* **`Auto-Threshold` ($1)** (bool) : par défaut = Faux (0)
* **`Threshold (%)` ($2)** (float) : défaut = **50**  (0,100)
* **`Size Median` ($3)** (int) : défaut = **0**  (0,15)
* **`Invert` ($4)** (bool) : par défaut = Faux (0)
* **`Threshold on Flux` ($5)** (float) : défaut = **-0.3**  (-5,5)
* **`Medial Curve` ($6)** (bool) : par défaut = Faux (0)
* **`Torsello Correction` ($7)** (bool) : par défaut = Faux (0)
* **`Discrete Step` ($8)** (int) : défaut = **1**  (1,15)
* **`Preview Type` ($9)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($10)** (point) : position = 0,0
(Note) : Skeleton using CImg example plugin use_skeleton.
(Note) : CImg Skeleton: use_skeleton in search PATH
(Note) : Author : KaRo. Latest update : 2012/10/26.
