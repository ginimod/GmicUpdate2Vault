---
tags: [gmic, filter]
command: fx_layer_cake_2
---

# Filtre G'MIC : fx_layer_cake_2

## Structure de la commande
```text
fx_layer_cake_2:
    layer_density = $1
    angle_value = $2
    angle_mode = $3
    centre_x = $4
    centre_y = $5
    interpolation = $6
    boundary = $7
    blur = $8
    blur_mode = $9
    output_mode = $10
```
## Définition des variables
* **`Layer Density` ($1)** (float) : défaut = **4**  (1,100)
* **`Angle Value` ($2)** (float) : défaut = **360**  (-2880,2880)
* **`Angle Mode` ($3)** (choice) : choix possibles => Divided by Density, Per Layer
* **`Centre` ($4)** (point) : position = 0,0
* **`Interpolation` ($5)** (choice) : choix possibles => None, Linear, Bicubic
* **`Boundary` ($6)** (choice) : choix possibles => None, Nearest, Periodic, Mirror
* **`Blur` ($7)** (float) : défaut = **50**  (0,100)
* **`Blur Mode` ($8)** (choice) : choix possibles => Anti-Alias, Layer Smoothing
* **`Output Mode` ($9)** (choice) : choix possibles => Full, Filled Layers, Hollow Layers
