---
tags: [gmic, filter]
command: fx_imagegrid_triangular
---

# Filtre G'MIC : fx_imagegrid_triangular

## Structure de la commande
```text
fx_imagegrid_triangular:
    pattern_width = $1
    pattern_height = $2
    pattern_type = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Converts the image into a pixelated triangular grid. 
* **`Pattern Width` ($1)** (int) : défaut = **10**  (8,128)
* **`Pattern Height` ($2)** (int) : défaut = **18**  (8,128)
* **`Pattern Type` ($3)** (choice) : choix possibles => Horizontal, Vertical, Crossed, Cube, Decreasing, Increasing
* **`Outline Color` ($4)** (color) : défaut = 0,0,0,128
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/07/08.
