---
tags: [gmic, filter]
command: afre_halfhalf
---

# Filtre G'MIC : afre_halfhalf

## Structure de la commande
```text
afre_halfhalf:
    match_size = $1
```
## Définition des variables
(Note) : <strong>Stitch left and right halves of 2 images, respectively.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2020-Feb21.</strong>

 * Remember to set <strong>Input layers</strong>.
 * <strong>Match size</strong> doesn't work in Krita.


* **`Match Size` ($1)** (bool) : par défaut = Faux (0)
