---
tags: [gmic, filter]
command: fx_fourier_transform
---

# Filtre G'MIC : fx_fourier_transform

## Structure de la commande
```text
fx_fourier_transform:
    discard_transparency = $1
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Computes the Forward/Inverse Fourier Transform. 
* **`Discard Transparency` ($1)** (bool) : par défaut = Faux (0)
(Note) : Note: Apply this filter once to get the direct FFT, and once again to get the reverse transform.
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2022/04/26.
