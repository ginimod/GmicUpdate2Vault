---
tags: [gmic, filter]
command: fx_pahlsson_descreen
---

# Filtre G'MIC : fx_pahlsson_descreen

## Structure de la commande
```text
fx_pahlsson_descreen:
    circle_radius = $1
    cross_length = $2
    cross_width = $3
    preview_type = $4
```
## Définition des variables
* **`Circle Radius (%)` ($1)** (float) : défaut = **7**  (0,100)
* **`Cross Length (%)` ($2)** (float) : défaut = **40**  (0,100)
* **`Cross Width (%)` ($3)** (float) : défaut = **1**  (0,100)
* **`Preview Type` ($4)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author: Andreas Påhlsson.      Latest update: 2026/04/08.
