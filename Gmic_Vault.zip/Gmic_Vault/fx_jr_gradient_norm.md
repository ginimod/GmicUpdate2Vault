---
tags: [gmic, filter]
command: fx_jr_gradient_norm
---

# Filtre G'MIC : fx_jr_gradient_norm

## Structure de la commande
```text
fx_jr_gradient_norm:
    smoothness = $1
    contrast = $2
    min_threshold = $3
    max_threshold = $4
    negative = $5
    include_orientation = $6
    scale_x = $7
    scale_y = $8
    interpolation = $9
    alpha = $10
    preview_type = $11
    preview_split_x = $12
    preview_split_y = $13
```
## Définition des variables
* **`Smoothness` ($1)** (float) : défaut = **0**  (0,10)
* **`Contrast` ($2)** (float) : défaut = **0.45**  (0,1.5)
* **`Min Threshold` ($3)** (float) : défaut = **40**  (0,100)
* **`Max Threshold` ($4)** (float) : défaut = **60**  (0,100)
* **`Negative` ($5)** (bool) : par défaut = Faux (0)
* **`Include Orientation` ($6)** (choice) : choix possibles => Off, On, On (Extrapolate If Negative)
* **`Scale X` ($7)** (float) : défaut = **1**  (0,5)
* **`Scale Y` ($8)** (float) : défaut = **1**  (0,5)
* **`Interpolation` ($9)** (choice) : choix possibles => Nearest, Average, Bilinear, Bicubic
* **`Alpha` ($10)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($11)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($12)** (point) : position = 0,0
(Note) : Author: <a href="http://ow.ly/wpsV30fzhdI">David Tschumperlé</a>.      Latest update: 2010/29/12.
