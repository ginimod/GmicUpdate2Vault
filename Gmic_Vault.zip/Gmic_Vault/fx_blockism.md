---
tags: [gmic, filter]
command: fx_blockism
---

# Filtre G'MIC : fx_blockism

## Structure de la commande
```text
fx_blockism:
    relative_size = $1
    ratio = $2
    size_variance = $3
    relative_block_count = $4
    opacity = $5
    flip_tolerance = $6
    reverse_flip = $7
    colorspace = $8
    preview_type = $9
```
## Définition des variables
(Note) : Renders rectangles on to the image.
(Note) : Parameters
* **`Relative Size` ($1)** (float) : défaut = **3**  (0,20)
* **`Ratio` ($2)** (float) : défaut = **1.6**  (1,10)
* **`Size Variance` ($3)** (float) : défaut = **0.5**  (0,10)
* **`Relative Block Count` ($4)** (int) : défaut = **50**  (0,500)
* **`Opacity` ($5)** (float) : défaut = **0.5**  (0,1)
* **`Flip Tolerance` ($6)** (int) : défaut = **64**  (0,255)
* **`Reverse Flip` ($7)** (bool) : par défaut = Faux (0)
* **`Colorspace` ($8)** (choice) : choix possibles => Lab, RGB
* **`Preview Type` ($9)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) :  Author: Arto Huotari Latest update : 2012/10/07.
