---
tags: [gmic, filter]
command: fx_engrave
---

# Filtre G'MIC : fx_engrave

## Structure de la commande
```text
fx_engrave:
    radius = $1
    density = $2
    edges = $3
    coherence = $4
    threshold = $5
    minimal_area = $6
    flat_regions_removal = $7
    add_color_background = $8
    quantization = $9
    shading = $10
    hue = $11
    saturation = $12
    lightness = $13
    anti_aliasing = $14
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates an engraving style. 
(Note) : Black & White foreground:
* **`Radius` ($1)** (float) : défaut = **0.5**  (0,2)
* **`Density` ($2)** (float) : défaut = **50**  (0,200)
* **`Edges` ($3)** (float) : défaut = **0**  (0,10)
* **`Coherence` ($4)** (float) : défaut = **8**  (0,40)
* **`Threshold (%)` ($5)** (float) : défaut = **40**  (0,100)
* **`Minimal Area` ($6)** (int) : défaut = **0**  (-256,256)
* **`Flat Regions Removal` ($7)** (float) : défaut = **0**  (0,10)
(Note) : Color background:
* **`Add Color Background` ($8)** (bool) : par défaut = Faux (0)
* **`Quantization` ($9)** (float) : défaut = **10**  (0,40)
* **`Shading` ($10)** (int) : défaut = **1**  (0,5)
* **`Hue` ($11)** (float) : défaut = **0**  (-180,180)
* **`Saturation (%)` ($12)** (float) : défaut = **0**  (-100,100)
* **`Lightness (%)` ($13)** (float) : défaut = **0**  (-100,100)
* **`Anti-Aliasing` ($14)** (choice) : choix possibles => Disabled, X1.5, X2, X3
(Note) : Authors: Lyle Kroll and <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.       Latest Update: 2015/03/13.
