---
tags: [gmic, filter]
command: fx_heart
---

# Filtre G'MIC : fx_heart

## Structure de la commande
```text
fx_heart:
    size = $1
    smoothness = $2
    antialiasing = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Renders a heart silhouette. 
* **`Size (%)` ($1)** (float) : défaut = **75**  (0,100)
* **`Smoothness` ($2)** (float) : défaut = **0**  (0,10)
* **`Color` ($3)** (color) : défaut = 255,255,255,255
* **`Antialiasing` ($4)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2018/01/08.
