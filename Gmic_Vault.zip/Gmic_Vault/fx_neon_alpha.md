---
tags: [gmic, filter]
command: fx_neon_alpha
---

# Filtre G'MIC : fx_neon_alpha

## Structure de la commande
```text
fx_neon_alpha:
    1_smoothness = $1
    2_linearity = $2
    3_min_threshold = $3
    4_max_threshold = $4
    5_negative = $5
    6_blur_original = $6
    7_saturation = $7
    8_size = $8
    9_intensity = $9
    10_darken = $10
    11_saturation = $11
    12_size = $12
    13_intensity = $13
    14_darken = $14
    15_saturation = $15
    16_size = $16
    17_intensity = $17
```
## Définition des variables
(Note) : An attempt to make the Neon filter work with alpha channels. Low-quality, comes with some artefacts.
(Note) : Gradient norm
* **`1. Smoothness` ($1)** (float) : défaut = **0**  (0,10)
* **`2. Linearity` ($2)** (float) : défaut = **0.45**  (0,1.5)
* **`3. Min Threshold` ($3)** (float) : défaut = **40**  (0,100)
* **`4. Max Threshold` ($4)** (float) : défaut = **60**  (0,100)
* **`5. Negative` ($5)** (bool) : par défaut = Faux (0)
* **`6. Blur Original` ($6)** (float) : défaut = **2**  (0,20)
* **`7. Saturation` ($7)** (float) : défaut = **1.15**  (0,4)
(Note) : Colour Glow 1
* **`8. Size` ($8)** (float) : défaut = **20**  (0,100)
* **`9. Intensity` ($9)** (float) : défaut = **0.4**  (0,3)
* **`10. Darken` ($10)** (float) : défaut = **0.1**  (0,1)
* **`11. Saturation` ($11)** (float) : défaut = **2.25**  (0,4)
(Note) : Colour Glow 2
* **`12. Size` ($12)** (float) : défaut = **5**  (0,100)
* **`13. Intensity` ($13)** (float) : défaut = **0.2**  (0,3)
* **`14. Darken` ($14)** (float) : défaut = **0.1**  (0,1)
* **`15. Saturation` ($15)** (float) : défaut = **2.25**  (0,4)
(Note) : Boost Glow
* **`16. Size` ($16)** (float) : défaut = **2**  (0,5)
* **`17. Intensity` ($17)** (float) : défaut = **1**  (0,2)
