---
tags: [gmic, filter]
command: fx_diffusiontensors
---

# Filtre G'MIC : fx_diffusiontensors

## Structure de la commande
```text
fx_diffusiontensors:
    resolution = $1
    size = $2
    color_mode = $3
    outline = $4
    sharpness = $5
    anisotropy = $6
    gradient_smoothness = $7
    tensor_smoothness = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Visualizes the diffusion tensors of the image structure. 
* **`Resolution (%)` ($1)** (float) : défaut = **10**  (0,20)
* **`Size` ($2)** (float) : défaut = **5**  (0,16)
* **`Color Mode` ($3)** (choice) : choix possibles => Monochrome, Grayscale, Orientation, Color
* **`Outline` ($4)** (int) : défaut = **1**  (0,16)
* **`Sharpness` ($5)** (float) : défaut = **0.15**  (0,1)
* **`Anisotropy` ($6)** (float) : défaut = **1**  (0,1)
* **`Gradient Smoothness` ($7)** (float) : défaut = **0**  (0,10)
* **`Tensor Smoothness` ($8)** (float) : défaut = **3**  (0,10)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/10/19.
