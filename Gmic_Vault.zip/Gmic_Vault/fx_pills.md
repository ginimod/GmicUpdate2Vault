---
tags: [gmic, filter]
command: fx_pills
---

# Filtre G'MIC : fx_pills

## Structure de la commande
```text
fx_pills:
    mode = $1
    cycles = $2
    angle = $3
    cycles = $4
    angle = $5
    cycles = $6
    angle = $7
    cycles = $8
    angle = $9
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a pattern resembling pills or capsules. 
* **`Mode` ($1)** (choice) : choix possibles => Gray, RGB
(Note) : <span color="#EE5500">Gray Settings:</span>
* **`Cycles` ($2)** (float) : défaut = **4**  (0,32)
* **`Angle` ($3)** (float) : défaut = **0**  (0,360)
(Note) : <span color="#EE5500">Red Settings:</span>
* **`Cycles` ($4)** (float) : défaut = **4**  (0,32)
* **`Angle` ($5)** (float) : défaut = **0**  (0,360)
(Note) : <span color="#EE5500">Green Settings:</span>
* **`Cycles` ($6)** (float) : défaut = **4**  (0,32)
* **`Angle` ($7)** (float) : défaut = **0**  (0,360)
(Note) : <span color="#EE5500">Blue Settings:</span>
* **`Cycles` ($8)** (float) : défaut = **4**  (0,32)
* **`Angle` ($9)** (float) : défaut = **0**  (0,360)
(Note) : Note: This filter evaluates the awesome math formula proposed by Miloslav Číž (a.k.a. DrummyFish) on <a href="https://commons.wikimedia.org/wiki/File:2D_function_pills.png">this Wikipedia page</a>. 
(Note) : Authors: Miloslav Číž and <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.       Latest Update: 2022/11/08.
