---
tags: [gmic, filter]
command: fx_gcd_upscale_solver2x
---

# Filtre G'MIC : fx_gcd_upscale_solver2x

## Structure de la commande
```text
fx_gcd_upscale_solver2x:
    kernel = $1
    enabled = $2
    radius = $3
    amount = $4
```
## Définition des variables
(Note) : <u>Anisotropic 2x upscale with optional unsharpening</u>
(Note) : 
Quality Options
* **`Kernel` ($1)** (int) : défaut = **4**  (1,6)
(Note) : 
Unsharp Options
* **`Enabled` ($2)** (bool) : par défaut = Faux (0)
* **`Radius` ($3)** (float) : défaut = **1**  (0,30)
* **`Amount` ($4)** (float) : défaut = **1**  (0,5)
(Note) : Author : Garagecoder.      Latest update : 2022/12/20.
(Note) : 
<u>Usage</u>
(Note) : Preview is fixed to lowest quality kernel.
(Note) : Very small images tend to require a small kernel.
(Note) : Enable unsharpening to counteract prominent halos.
(Note) : 
Warning: large kernels are slow to compute.
(Note) : Image size also affects computation time significantly.
