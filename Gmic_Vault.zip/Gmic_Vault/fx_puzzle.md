---
tags: [gmic, filter]
command: fx_puzzle
---

# Filtre G'MIC : fx_puzzle

## Structure de la commande
```text
fx_puzzle:
    x_tiles = $1
    y_tiles = $2
    curvature = $3
    connectors_centering = $4
    connectors_variability = $5
    relief_smoothness = $6
    relief_contrast = $7
    outline_smoothness = $8
    outline_contrast = $9
    scale = $10
    scale_variations = $11
    angle = $12
    angle_variations = $13
    shuffle_pieces = $14
    additional_outline = $15
    output_each_piece_on_a_different_layer = $16
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Applies a jigsaw puzzle pattern overlay. 
(Note) : Pattern parameters:
* **`X-Tiles` ($1)** (int) : défaut = **5**  (2,32)
* **`Y-Tiles` ($2)** (int) : défaut = **5**  (2,32)
* **`Curvature` ($3)** (float) : défaut = **0.5**  (0,1.5)
* **`Connectors Centering` ($4)** (float) : défaut = **0**  (0,1)
* **`Connectors Variability` ($5)** (float) : défaut = **0**  (0,2)
(Note) : Blending parameters:
* **`Relief Smoothness` ($6)** (float) : défaut = **0.3**  (0,3)
* **`Relief Contrast` ($7)** (float) : défaut = **100**  (0,255)
* **`Outline Smoothness` ($8)** (float) : défaut = **0.2**  (0,3)
* **`Outline Contrast` ($9)** (float) : défaut = **255**  (0,255)
(Note) : Recomposition parameters:
* **`Scale` ($10)** (float) : défaut = **100**  (0,150)
* **`Scale Variations` ($11)** (float) : défaut = **0**  (0,100)
* **`Angle` ($12)** (float) : défaut = **0**  (-180,180)
* **`Angle Variations` ($13)** (float) : défaut = **0**  (0,180)
* **`Shuffle Pieces` ($14)** (bool) : par défaut = Faux (0)
* **`Additional Outline` ($15)** (bool) : par défaut = Faux (0)
* **`Output Each Piece on a Different Layer` ($16)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2014/01/06.
