---
tags: [gmic, filter]
command: fx_inpaint_morpho
---

# Filtre G'MIC : fx_inpaint_morpho

## Structure de la commande
```text
fx_inpaint_morpho:
    mask_dilation = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Inpaints mask content using morphological operations. 
* **`Mask Color` ($1)** (color) : défaut = 255,0,0,255
* **`Mask Dilation` ($2)** (int) : défaut = **0**  (0,32)
(Note) : Note: It is strongly suggested to apply this filter only on a selection around the region to inpaint, to save computation time!
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/11/25.
