---
tags: [gmic, filter]
command: fx_array_random
---

# Filtre G'MIC : fx_array_random

## Structure de la commande
```text
fx_array_random:
    source_x_tiles = $1
    source_y_tiles = $2
    destination_x_tiles = $3
    destination_y_tiles = $4
    seed = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Creates a grid of random patches of the image. 
* **`Source X-Tiles` ($1)** (int) : défaut = **5**  (1,128)
* **`Source Y-Tiles` ($2)** (int) : défaut = **5**  (1,128)
* **`Destination X-Tiles` ($3)** (int) : défaut = **7**  (1,128)
* **`Destination Y-Tiles` ($4)** (int) : défaut = **7**  (1,128)
* **`Seed` ($5)** (int) : défaut = **0**  (0,65535)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
