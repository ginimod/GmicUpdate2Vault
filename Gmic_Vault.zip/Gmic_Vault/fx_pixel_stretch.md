---
tags: [gmic, filter]
command: fx_pixel_stretch
---

# Filtre G'MIC : fx_pixel_stretch

## Structure de la commande
```text
fx_pixel_stretch:
    trail_type = $1
    number_of_control_points = $2
    starting_point_x = $3
    starting_point_y = $4
    op_x = $5
    op_y = $6
    sl_x = $7
    sl_y = $8
    sr_x = $9
    sr_y = $10
    mid_point_1_x = $11
    mid_point_1_y = $12
    om1_x = $13
    om1_y = $14
    m1l_x = $15
    m1l_y = $16
    m1r_x = $17
    m1r_y = $18
    mid_point_2_x = $19
    mid_point_2_y = $20
    om2_x = $21
    om2_y = $22
    m2l_x = $23
    m2l_y = $24
    m2r_x = $25
    m2r_y = $26
    mid_point_3_x = $27
    mid_point_3_y = $28
    om3_x = $29
    om3_y = $30
    m3l_x = $31
    m3l_y = $32
    m3r_x = $33
    m3r_y = $34
    mid_point_4_x = $35
    mid_point_4_y = $36
    om4_x = $37
    om4_y = $38
    m4l_x = $39
    m4l_y = $40
    m4r_x = $41
    m4r_y = $42
    ending_point_x = $43
    ending_point_y = $44
    oe_x = $45
    oe_y = $46
    el_x = $47
    el_y = $48
    er_x = $49
    er_y = $50
    align_side_points_with_normals = $51
    anti_aliasing = $52
    mode = $53
    slice_start_x = $54
    slice_start_y = $55
    slice_end_x = $56
    slice_end_y = $57
    slice_position_in_curve = $58
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generate a colorful pixel-stretch streak along a user-defined curve. 
(Note) : <span color="#EE5500">Trail Parameters:</span>
* **`Trail Type` ($1)** (choice) : choix possibles => Sharp (Linear), Smooth (Cubic)
* **`Number of Control Points` ($2)** (int) : défaut = **3**  (2,6)
* **`Starting Point (%)` ($3)** (point) : position = 0,0
* **`OP` ($4)** (point) : position = 0,0
* **`SL` ($5)** (point) : position = 0,0
* **`SR` ($6)** (point) : position = 0,0
* **`Mid Point #1 (%)` ($7)** (point) : position = 0,0
* **`OM1` ($8)** (point) : position = 0,0
* **`M1L` ($9)** (point) : position = 0,0
* **`M1R` ($10)** (point) : position = 0,0
* **`Mid Point #2 (%)` ($11)** (point) : position = 0,0
* **`OM2` ($12)** (point) : position = 0,0
* **`M2L` ($13)** (point) : position = 0,0
* **`M2R` ($14)** (point) : position = 0,0
* **`Mid Point #3 (%)` ($15)** (point) : position = 0,0
* **`OM3` ($16)** (point) : position = 0,0
* **`M3L` ($17)** (point) : position = 0,0
* **`M3R` ($18)** (point) : position = 0,0
* **`Mid Point #4 (%)` ($19)** (point) : position = 0,0
* **`OM4` ($20)** (point) : position = 0,0
* **`M4L` ($21)** (point) : position = 0,0
* **`M4R` ($22)** (point) : position = 0,0
* **`Ending Point (%)` ($23)** (point) : position = 0,0
* **`OE` ($24)** (point) : position = 0,0
* **`EL` ($25)** (point) : position = 0,0
* **`ER` ($26)** (point) : position = 0,0
* **`Align Side Points With Normals` ($27)** (bool) : par défaut = Faux (0)
* **`Anti-Aliasing` ($28)** (bool) : par défaut = Faux (0)
(Note) : <span color="#EE5500">Slice Parameters:</span>
* **`Mode` ($29)** (choice) : choix possibles => Custom Slice, Slice of Curve
* **`Slice Start` ($30)** (point) : position = 0,0
* **`Slice End` ($31)** (point) : position = 0,0
* **`Slice Position in Curve (%)` ($32)** (float) : défaut = **100**  (0,100)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2026/06/28.
