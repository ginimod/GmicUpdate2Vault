---
tags: [gmic, filter]
command: fx_karo_pink_bianca
---

# Filtre G'MIC : fx_karo_pink_bianca

## Structure de la commande
```text
fx_karo_pink_bianca:
    asf_smooth_size = $1
    threshold = $2
    watershed_height_min = $3
    opening_radius = $4
    invert = $5
    use_g_instead_of_b = $6
    preview_type = $7
    preview_split_x = $8
    preview_split_y = $9
```
## Définition des variables
* **`ASF Smooth Size` ($1)** (int) : défaut = **5**  (1,10)
* **`Threshold (%)` ($2)** (int) : défaut = **60**  (0,100)
* **`Watershed Height Min` ($3)** (int) : défaut = **5**  (0,20)
* **`Opening Radius` ($4)** (int) : défaut = **1**  (0,10)
* **`Invert` ($5)** (bool) : par défaut = Faux (0)
* **`Use G Instead of B` ($6)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($7)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($8)** (point) : position = 0,0
(Note) : Pink test operator Bianca for RGB image; only B used.
(Note) : Pink executables in search PATH or C:\Pink\bin for Windows
(Note) : Author : KaRo.           Latest update : 2012/10/26.
