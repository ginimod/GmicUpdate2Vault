---
tags: [gmic, filter]
command: fx_apply_multiscale
---

# Filtre G'MIC : fx_apply_multiscale

## Structure de la commande
```text
fx_apply_multiscale:
    number_of_scales = $1
    starting_scale = $2
    ending_scale = $3
    non_linearity = $4
    rescaling = $5
    x_centering = $6
    y_centering = $7
    angle = $8
    enable_interpolated_motion = $9
    ending_x_centering = $10
    ending_y_centering = $11
    ending_angle = $12
    return_scaling = $14
    lock_return_scaling_to_source_layer = $15
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Applies a filter at different scales of the image pyramid. 
* **`Number of Scales` ($1)** (int) : défaut = **4**  (2,16)
* **`Starting Scale (%)` ($2)** (float) : défaut = **25**  (0,400)
* **`Ending Scale (%)` ($3)** (float) : défaut = **100**  (0,400)
* **`Non-Linearity` ($4)** (float) : défaut = **0**  (-1,1)
* **`Rescaling` ($5)** (choice) : choix possibles => Block, Linear, Cubic, Lanczsos
* **`X-Centering` ($6)** (float) : défaut = **0.5**  (0,1)
* **`Y-Centering` ($7)** (float) : défaut = **0.5**  (0,1)
* **`Angle` ($8)** (float) : défaut = **0**  (-180,180)
* **`Enable Interpolated Motion` ($9)** (bool) : par défaut = Faux (0)
* **`Ending X-Centering` ($10)** (float) : défaut = **0.5**  (0,1)
* **`Ending Y-Centering` ($11)** (float) : défaut = **0.5**  (0,1)
* **`Ending Angle` ($12)** (float) : défaut = **0**  (-180,180)
* **`Return Scaling` ($13)** (choice) : choix possibles => None, Block, Linear, Cubic, Lanczos
* **`Lock Return Scaling to Source Layer` ($14)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/03/30.
