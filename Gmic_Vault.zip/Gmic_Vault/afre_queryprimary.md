---
tags: [gmic, filter]
command: afre_queryprimary
---

# Filtre G'MIC : afre_queryprimary

## Structure de la commande
```text
afre_queryprimary:
    mode = $1
    skip_last_channel = $2
```
## Définition des variables
(Note) : <strong>Query pixel minima, maxima or medians.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2021 Jul14.</strong>


* **`Mode` ($1)** (choice) : choix possibles => Minima, Maxima, Medians
* **`Skip Last Channel` ($2)** (bool) : par défaut = Faux (0)
(Note) : * Disable if image does not have an alpha or transparency channel.


