---
tags: [gmic, filter]
command: fx_animate_glow
---

# Filtre G'MIC : fx_animate_glow

## Structure de la commande
```text
fx_animate_glow:
    frames = $1
    output_as_frames = $2
    output_as_files = $3
    amplitude = $5
    amplitude = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Animates a glowing pulse. 
* **`Frames` ($1)** (int) : défaut = **10**  (2,100)
* **`Output as Frames` ($2)** (bool) : par défaut = Faux (0)
* **`Output as Files` ($3)** (bool) : par défaut = Faux (0)
(Note) : 
Starting Parameters :
* **`Amplitude` ($4)** (float) : défaut = **0**  (0,8)
(Note) : 
Ending Parameters :
* **`Amplitude` ($5)** (float) : défaut = **3**  (0,8)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
