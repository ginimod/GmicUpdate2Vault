---
tags: [gmic, filter]
command: fx_crystal
---

# Filtre G'MIC : fx_crystal

## Structure de la commande
```text
fx_crystal:
    density = $1
    smoothness = $2
    edges = $3
    fast_fill = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a crystalline polygon pattern. 
* **`Density` ($1)** (float) : défaut = **50**  (0,100)
* **`Smoothness` ($2)** (float) : défaut = **0.2**  (0,2)
* **`Edges` ($3)** (float) : défaut = **20**  (0,100)
* **`Fast Fill` ($4)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/01/19.
