---
tags: [gmic, filter]
command: fx_lylejk_painting
---

# Filtre G'MIC : fx_lylejk_painting

## Structure de la commande
```text
fx_lylejk_painting:
    iterations = $1
    abstraction = $2
    radius = $3
    canvas = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> A painterly effect script by user Lylejk. 
* **`Iterations` ($1)** (int) : défaut = **10**  (1,20)
* **`Abstraction` ($2)** (int) : défaut = **2**  (1,20)
* **`Radius` ($3)** (int) : défaut = **4**  (1,30)
* **`Canvas` ($4)** (float) : défaut = **10**  (0,100)
(Note) : Authors: Lyle Kroll and <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.       Latest Update: 2015/02/23.
