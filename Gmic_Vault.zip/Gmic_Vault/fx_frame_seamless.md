---
tags: [gmic, filter]
command: fx_frame_seamless
---

# Filtre G'MIC : fx_frame_seamless

## Structure de la commande
```text
fx_frame_seamless:
    frame_size = $1
    patch_size = $2
    blend_size = $3
    frame_type = $4
    equalize_light = $5
    preview_original = $6
    tiled_preview = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Makes the image tileable using a patch-based synthesis method. 
* **`Frame Size` ($1)** (int) : défaut = **32**  (0,256)
* **`Patch Size` ($2)** (int) : défaut = **9**  (3,64)
* **`Blend Size` ($3)** (int) : défaut = **0**  (0,64)
* **`Frame Type` ($4)** (choice) : choix possibles => Inner, Outer
* **`Equalize Light` ($5)** (float) : défaut = **100**  (0,100)
* **`Preview Original` ($6)** (bool) : par défaut = Faux (0)
* **`Tiled Preview` ($7)** (choice) : choix possibles => None, 2x1, 1x2, 2x2, 3x3, 4x4
(Note) : Note: This filter helps in converting your input pattern as a seamless (i.e. periodic) texture.
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/12/15.
