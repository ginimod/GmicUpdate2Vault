---
tags: [gmic, filter]
command: fx_extract_objects
---

# Filtre G'MIC : fx_extract_objects

## Structure de la commande
```text
fx_extract_objects:
    background_point_x = $1
    background_point_y = $2
    color_tolerance = $3
    opacity_threshold = $4
    minimal_area = $5
    connectivity = $6
    output_as = $7
    preview_guides = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Automatically segments and crops objects onto several layers. 
* **`Background Point (%)` ($1)** (point) : position = 0,0
* **`Color Tolerance` ($2)** (int) : défaut = **20**  (0,256)
* **`Opacity Threshold (%)` ($3)** (int) : défaut = **50**  (0,100)
* **`Minimal Area` ($4)** (float) : défaut = **0.3**  (0,5)
* **`Connectivity` ($5)** (choice) : choix possibles => Low, High
* **`Output As` ($6)** (choice) : choix possibles => Crop, Segmentation
* **`Preview Guides` ($7)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/02/23.
