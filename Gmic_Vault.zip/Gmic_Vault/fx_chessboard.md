---
tags: [gmic, filter]
command: fx_chessboard
---

# Filtre G'MIC : fx_chessboard

## Structure de la commande
```text
fx_chessboard:
    first_size = $1
    second_size = $2
    first_offset = $3
    second_offset = $4
    angle = $5
    opacity = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Overlays a chessboard pattern. 
* **`First Size` ($1)** (int) : défaut = **64**  (1,512)
* **`Second Size` ($2)** (int) : défaut = **64**  (1,512)
* **`First Offset` ($3)** (int) : défaut = **0**  (0,512)
* **`Second Offset` ($4)** (int) : défaut = **0**  (0,512)
* **`Angle` ($5)** (float) : défaut = **0**  (0,180)
* **`Opacity` ($6)** (float) : défaut = **0.25**  (0,1)
* **`First Color` ($7)** (color) : défaut = 0,0,0,255
* **`Second Color` ($8)** (color) : défaut = 255,255,255,255
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
