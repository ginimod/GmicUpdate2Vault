---
tags: [gmic, filter]
command: fx_gcd_etch
---

# Filtre G'MIC : fx_gcd_etch

## Structure de la commande
```text
fx_gcd_etch:
    threshold_low = $1
    threshold_mid = $2
    threshold_high = $3
    threshold_max = $4
    blur_amount = $5
    horizontal_amount = $6
    cross_hatch_amount = $7
    vertical_1_amount = $8
    vertical_2_amount = $9
    horizontal_length = $10
    vertical_1_length = $11
    vertical_2_length = $12
    flip_cross_hatch = $13
    curve_amount = $14
    gamma = $15
    fast_resize = $16
    color_image = $17
    preview_type = $18
```
## Définition des variables
(Note) : <u>Replace tones with noise generated lines</u>
(Note) : 
Input Image Settings
* **`Threshold Low` ($1)** (int) : défaut = **125**  (10,255)
* **`Threshold Mid` ($2)** (int) : défaut = **153**  (10,255)
* **`Threshold High` ($3)** (int) : défaut = **171**  (10,255)
* **`Threshold Max` ($4)** (int) : défaut = **185**  (10,255)
* **`Blur Amount` ($5)** (float) : défaut = **0.1**  (0,2)
(Note) : 
Output Etch Settings
* **`Horizontal Amount` ($6)** (int) : défaut = **50**  (0,100)
* **`Cross-Hatch Amount` ($7)** (int) : défaut = **80**  (0,100)
* **`Vertical 1 Amount` ($8)** (int) : défaut = **50**  (0,100)
* **`Vertical 2 Amount` ($9)** (int) : défaut = **10**  (0,100)
* **`Horizontal Length` ($10)** (int) : défaut = **15**  (0,50)
* **`Vertical 1 Length` ($11)** (int) : défaut = **12**  (0,50)
* **`Vertical 2 Length` ($12)** (int) : défaut = **20**  (0,50)
* **`Flip Cross-Hatch` ($13)** (bool) : par défaut = Faux (0)
* **`Curve Amount` ($14)** (int) : défaut = **1**  (0,20)
* **`Gamma` ($15)** (float) : défaut = **0.3**  (0.01,1)
* **`Fast Resize` ($16)** (bool) : par défaut = Faux (0)
* **`Color Image` ($17)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($18)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author : Garagecoder.      Latest update : 2013/02/09.
