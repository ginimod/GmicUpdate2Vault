---
tags: [gmic, filter]
command: fx_gcd_layeretch
---

# Filtre G'MIC : fx_gcd_layeretch

## Structure de la commande
```text
fx_gcd_layeretch:
    total_layers = $1
    white_layers = $2
    etch_tones = $3
    tone_blur = $4
    noise_level = $5
    dark_length = $6
    bright_length = $7
    start_angle = $8
    random_angle = $9
    max_curve = $10
    gamma = $11
    spread_angles = $12
    fast_resize = $13
```
## Définition des variables
(Note) : <u>Etch with selectable number of layers</u>
(Note) : Warning: With high number of layers this can be VERY slow!
* **`Total Layers` ($1)** (int) : défaut = **11**  (2,16)
* **`White Layers` ($2)** (int) : défaut = **4**  (1,15)
* **`Etch Tones` ($3)** (int) : défaut = **12**  (2,32)
* **`Tone Blur` ($4)** (float) : défaut = **0.12**  (0,1)
* **`Noise Level` ($5)** (int) : défaut = **100**  (5,200)
* **`Dark Length` ($6)** (float) : défaut = **8.5**  (0,20)
* **`Bright Length` ($7)** (float) : défaut = **5**  (0,20)
* **`Start Angle` ($8)** (int) : défaut = **0**  (0,180)
* **`Random Angle` ($9)** (int) : défaut = **0**  (0,45)
* **`Max Curve` ($10)** (int) : défaut = **3**  (0,20)
* **`Gamma` ($11)** (float) : défaut = **1**  (0.01,2)
* **`Spread Angles` ($12)** (bool) : par défaut = Faux (0)
* **`Fast Resize` ($13)** (bool) : par défaut = Faux (0)
(Note) : Author : Garagecoder.      Latest update : 2012/12/21.
