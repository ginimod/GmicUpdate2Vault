---
tags: [gmic, filter]
command: fx_fix_HDR_black
---

# Filtre G'MIC : fx_fix_HDR_black

## Structure de la commande
```text
fx_fix_HDR_black:
    x_coord_1 = $1
    y_coord_1 = $2
    x_coord_2 = $3
    y_coord_2 = $4
    show_mask = $5
    preview_type = $6
```
## Définition des variables
(Note) : Filter to remove blue, magenta and red noise from the black areas of HDR images. Filter is designed specifically for HDR night shots but may work on other images as well. Bilateral filtering and Haar Wavelets are used to filter the noise from the image and mask is used to apply the noise removal only to dark areas.
(Note) : Mask opacity settings, Black values must be lower than Highlight values. Tick Show mask to view mask and to see the effect of the sliders.
(Note) : Black cutoff
* **`X-Coord(1)` ($1)** (int) : défaut = **20**  (0,255)
* **`Y-Coord(1)` ($2)** (int) : défaut = **25**  (0,255)
(Note) : Highlight raising
* **`X-Coord(2)` ($3)** (int) : défaut = **50**  (0,255)
* **`Y-Coord(2)` ($4)** (int) : défaut = **200**  (0,255)
* **`Show Mask` ($5)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($6)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) :  Author: Arto Huotari Latest update : 2013/11/02.
