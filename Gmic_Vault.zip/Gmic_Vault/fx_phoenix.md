---
tags: [gmic, filter]
command: fx_phoenix
---

# Filtre G'MIC : fx_phoenix

## Structure de la commande
```text
fx_phoenix:
    radius = $1
    amplitude = $2
    iterations = $3
    steam_pressure = $4
    lubrication = $5
    bw_or_colours = $6
    swap_layers = $7
    merging_options = $8
    opacity = $9
    intensity = $10
    preview_type = $11
```
## Définition des variables
(Note) : Controls for 'Pencil' applied on a copy of original
* **`Radius` ($1)** (float) : défaut = **0.95**  (0,4)
* **`Amplitude` ($2)** (float) : défaut = **14**  (0,200)
(Note) : Controls for 'Steam' applied on the Pencil layer
* **`Iterations` ($3)** (int) : défaut = **2**  (1,7)
* **`Steam Pressure` ($4)** (int) : défaut = **2**  (1,7)
* **`Lubrication` ($5)** (float) : défaut = **0.9**  (0,1.9)
(Note) : To exit here or merge with the original
* **`BW or Colours` ($6)** (choice) : choix possibles => Black and White, Colours
(Note) : to activate the Merging Options below chose 'Colours'
* **`Swap Layers` ($7)** (bool) : par défaut = Faux (0)
* **`Merging Options` ($8)** (choice) : choix possibles => Value, Lightness, Luminance, *Colors Doping*, *Comix Colors*, Graphic Colors*, *Dark Edges*, *Vivid Edges*, Multiply, Color Burn, Darken, Lighten, Hard Light, Soft Light, Overlay, Grain Merge, Edges, Interpolation
* **`Opacity` ($9)** (float) : défaut = **1**  (0,1)
* **`*Intensity*` ($10)** (float) : défaut = **1**  (0,1)
* **`Preview Type` ($11)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author: PhotoComiX.      Last update : 2011/11/14 .
