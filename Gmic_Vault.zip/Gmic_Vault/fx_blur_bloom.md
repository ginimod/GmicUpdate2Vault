---
tags: [gmic, filter]
command: fx_blur_bloom
---

# Filtre G'MIC : fx_blur_bloom

## Structure de la commande
```text
fx_blur_bloom:
    amplitude = $1
    ratio = $2
    iterations = $3
    operator = $4
    kernel = $5
    normalize_scales = $6
    anisotropy = $7
    angle = $8
    channel_s = $9
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Creates a soft, glowing light effect. 
* **`Amplitude` ($1)** (float) : défaut = **1**  (0,10)
* **`Ratio` ($2)** (float) : défaut = **2**  (0,5)
* **`Iterations` ($3)** (int) : défaut = **5**  (0,100)
* **`Operator` ($4)** (choice) : choix possibles => Add, Max, Min
* **`Kernel` ($5)** (choice) : choix possibles => Deriche, Gaussian, Box, Triangle, Quadratic
* **`Normalize Scales` ($6)** (bool) : par défaut = Faux (0)
* **`Anisotropy` ($7)** (float) : défaut = **0**  (0,1)
* **`Angle` ($8)** (float) : défaut = **0**  (-180,180)
(Note) : Parameter Angle is only active when Anisotropy&gt;0
* **`Channel(s)` ($9)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/03/02.
