---
tags: [gmic, filter]
command: fx_flip_blocks
---

# Filtre G'MIC : fx_flip_blocks

## Structure de la commande
```text
fx_flip_blocks:
    x_size_px = $1
    y_size_px = $2
    flip = $3
    rotate = $4
    channel_s = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Randomly flips and rotates small blocks of the image. 
* **`X-Size (px)` ($1)** (int) : défaut = **4**  (1,128)
* **`Y-Size (px)` ($2)** (int) : défaut = **4**  (1,128)
* **`Flip` ($3)** (choice) : choix possibles => None, X-Axis, Y-Axis, XY-Axes
* **`Rotate` ($4)** (choice) : choix possibles => -90 Deg., 0 Deg., 90 Deg.
* **`Channel(s)` ($5)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/09/01.
