---
tags: [gmic, filter]
command: fx_OldSquiggly
---

# Filtre G'MIC : fx_OldSquiggly

## Structure de la commande
```text
fx_OldSquiggly:
    spread_noise_amount = $1
    segmentation_edge_threshold = $2
    segmentation_smoothness = $3
    gradiennormsmoothness = $4
    gradiennormlinearity = $5
    increasechroma1 = $6
    tone_threshold = $7
    tone_gamma = $8
    paper_grayness = $9
    paper_whiteness = $10
    squiggle_gamma = $11
    squiggle_multiplier = $12
```
## Définition des variables
(Note) : Development version. This version will be removed in future from sources so if you prefer this then copy and save the source to your local .gmic file
* **`Spread Noise Amount` ($1)** (float) : défaut = **2**  (0,20)
* **`Segmentation Edge Threshold` ($2)** (float) : défaut = **12**  (0,15)
* **`Segmentation Smoothness` ($3)** (float) : défaut = **0.8**  (0,5)
* **`GradienNormSmoothness` ($4)** (float) : défaut = **0**  (0,10)
* **`GradienNormLinearity` ($5)** (float) : défaut = **0.5**  (0,1.5)
* **`IncreaseChroma1` ($6)** (float) : défaut = **3**  (1,4)
* **`Tone Threshold` ($7)** (float) : défaut = **0.2**  (0,1)
* **`Tone Gamma` ($8)** (float) : défaut = **0.4**  (0,1)
* **`Paper Grayness` ($9)** (int) : défaut = **50**  (0,255)
* **`Paper Whiteness` ($10)** (int) : défaut = **245**  (0,255)
* **`Squiggle Gamma` ($11)** (int) : défaut = **45**  (1,128)
* **`Squiggle Multiplier` ($12)** (float) : défaut = **0.5**  (0,1)
