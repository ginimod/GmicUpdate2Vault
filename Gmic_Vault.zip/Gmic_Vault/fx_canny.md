---
tags: [gmic, filter]
command: fx_canny
---

# Filtre G'MIC : fx_canny

## Structure de la commande
```text
fx_canny:
    sigma = $1
    lower_threshold = $2
    upper_threshold = $3
    monochrome = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Implements the Canny edge detection algorithm. 
* **`Sigma` ($1)** (float) : défaut = **5**  (0,20)
* **`Lower Threshold` ($2)** (float) : défaut = **0.05**  (0,1)
* **`Upper Threshold` ($3)** (float) : défaut = **0.15**  (0,1)
* **`Monochrome` ($4)** (bool) : par défaut = Faux (0)
(Note) : Author: Garagecoder and <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2023/12/04.
