---
tags: [gmic, filter]
command: fx_noise
---

# Filtre G'MIC : fx_noise

## Structure de la commande
```text
fx_noise:
    amplitude = $1
    noise_type = $2
    channel_s = $3
    value_action = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds standard random noise (Gaussian, Uniform, etc.). 
* **`Amplitude` ($1)** (float) : défaut = **10**  (0,200)
* **`Noise Type` ($2)** (choice) : choix possibles => Gaussian, Uniform, Salt and Pepper, Poisson
* **`Channel(s)` ($3)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
* **`Value Action` ($4)** (choice) : choix possibles => None, Cut, Normalize
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
