---
tags: [gmic, filter]
command: cylindrical_equal_area
---

# Filtre G'MIC : cylindrical_equal_area

## Structure de la commande
```text
cylindrical_equal_area:
    roll = $1
    pitch_north_and_south = $2
    yaw_east_and_west = $3
    standard_parallels = $4
    named_specializations = $5
```
## Définition des variables
(Note) : Rotate an equirectangular map or panorama around three axises in order and output it as a cylindrical equal-area projection.
* **`Roll` ($1)** (float) : défaut = **0**  (-360,360)
* **`Pitch ("North and South")` ($2)** (float) : défaut = **0**  (-360,360)
* **`Yaw ("East and West")` ($3)** (float) : défaut = **0**  (-360,360)
* **`Standard Parallels` ($4)** (float) : défaut = **45**  (0,80)
* **`Named Specializations` ($5)** (choice) : choix possibles => [Standard Parallels ↑], Lambert 0° π:1, Behrmann 30°, Smyth/Craster ≈37°04′17″ 2:1, Trystan Edwards 37°24′, Hobo-Dyer 37°30′, Gall-Peters 45°, Balthasar 50°, Tobler ≈55°39′14″ 1:1, [Custom Formula ↓]
(Note) : Author: <a href="https://www.cartographersguild.com/showthread.php?t=47591">Kristian Järventaus</a>.      Latest Update: 2024/03/05.
