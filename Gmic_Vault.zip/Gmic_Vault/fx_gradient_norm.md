---
tags: [gmic, filter]
command: fx_gradient_norm
---

# Filtre G'MIC : fx_gradient_norm

## Structure de la commande
```text
fx_gradient_norm:
    smoothness = $1
    linearity = $2
    min_threshold = $3
    max_threshold = $4
    negative_colors = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Computes the magnitude of the image gradient. 
* **`Smoothness` ($1)** (float) : défaut = **0**  (0,10)
* **`Linearity` ($2)** (float) : défaut = **0.5**  (0,1.5)
* **`Min Threshold` ($3)** (float) : défaut = **0**  (0,100)
* **`Max Threshold` ($4)** (float) : défaut = **100**  (0,100)
* **`Negative Colors` ($5)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
