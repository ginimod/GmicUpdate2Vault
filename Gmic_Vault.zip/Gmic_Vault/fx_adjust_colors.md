---
tags: [gmic, filter]
command: fx_adjust_colors
---

# Filtre G'MIC : fx_adjust_colors

## Structure de la commande
```text
fx_adjust_colors:
    brightness = $1
    contrast = $2
    gamma = $3
    hue = $4
    saturation = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Controls brightness, contrast, hue, and saturation. 
* **`Brightness (%)` ($1)** (float) : défaut = **0**  (-100,100)
* **`Contrast (%)` ($2)** (float) : défaut = **0**  (-100,100)
* **`Gamma (%)` ($3)** (float) : défaut = **0**  (-100,100)
* **`Hue (%)` ($4)** (float) : défaut = **0**  (-100,100)
* **`Saturation (%)` ($5)** (float) : défaut = **0**  (-100,100)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/06/16.
