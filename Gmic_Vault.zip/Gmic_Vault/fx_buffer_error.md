---
tags: [gmic, filter]
command: fx_buffer_error
---

# Filtre G'MIC : fx_buffer_error

## Structure de la commande
```text
fx_buffer_error:
    1_width = $1
    2_height = $2
    3_buffer_selection_start = $3
    4_buffer_selection_length = $4
    5_buffer_selection_shift = $5
    6_repeat_buffer = $6
    preview_type = $7
    preview_split_x = $8
    preview_split_y = $9
```
## Définition des variables
(Note) : Resizes an image without changing the positions of pixels in a specified selection of a simulated image buffer. Buffer shift scales with the buffer length.
* **`1. Width` ($1)** (float) : défaut = **50**  (0,200)
* **`2. Height` ($2)** (float) : défaut = **50**  (0,200)
* **`3. Buffer Selection Start (%)` ($3)** (float) : défaut = **0**  (0,100)
* **`4. Buffer Selection Length (%)` ($4)** (float) : défaut = **100**  (0,400)
* **`5. Buffer Selection Shift (%)` ($5)** (float) : défaut = **0**  (0,100)
* **`6. Repeat Buffer` ($6)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($7)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($8)** (point) : position = 0,0
