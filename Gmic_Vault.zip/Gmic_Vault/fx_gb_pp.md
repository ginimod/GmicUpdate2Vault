---
tags: [gmic, filter]
command: fx_gb_pp
---

# Filtre G'MIC : fx_gb_pp

## Structure de la commande
```text
fx_gb_pp:
```
## Définition des variables
(Note) : 
Usage Notes:  Set Output mode to 'New image' or 'in place' to simply reverse the frames in this image.  Set mode to 'New layers' to add the reversing effect to your current image.
