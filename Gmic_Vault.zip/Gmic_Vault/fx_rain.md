---
tags: [gmic, filter]
command: fx_rain
---

# Filtre G'MIC : fx_rain

## Structure de la commande
```text
fx_rain:
    angle = $1
    speed = $2
    density = $3
    radius = $4
    gamma = $5
    opacity = $6
    preview_type = $7
    preview_split_x = $8
    preview_split_y = $9
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Procedural generator for rain or snow overlays. 
* **`Angle` ($1)** (float) : défaut = **65**  (-180,180)
* **`Speed` ($2)** (float) : défaut = **10**  (0,50)
* **`Density (%)` ($3)** (float) : défaut = **50**  (0,100)
* **`Radius` ($4)** (float) : défaut = **0.1**  (0,3)
* **`Gamma` ($5)** (float) : défaut = **1**  (0,2)
* **`Opacity` ($6)** (float) : défaut = **1**  (0,1)
* **`Preview Type` ($7)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($8)** (point) : position = 0,0
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2024/02/21.
