---
tags: [gmic, filter]
command: cl_implicitEqua
---

# Filtre G'MIC : cl_implicitEqua

## Structure de la commande
```text
cl_implicitEqua:
    width_pixels = $2
    height_pixels = $3
    min_x = $4
    max_x = $5
    min_y = $6
    max_y = $7
    axes = $8
    grid = $9
    grid_cell_size = $10
```
## Définition des variables
(Note) : Plot the equation: f(x,y)=0
(Note) : - The x axis is drawn from left to right
(Note) : - The y axis is drawn from bottom to top
(Note) : - To reverse an axis, just swap min and max
* **`Width (pixels)` ($1)** (int) : défaut = **500**  (10,2000)
* **`Height (pixels)` ($2)** (int) : défaut = **500**  (10,2000)
* **`Min X` ($3)** (float) : défaut = **-6**  (-10000,10000)
* **`Max X` ($4)** (float) : défaut = **6**  (-10000,10000)
* **`Min Y` ($5)** (float) : défaut = **-6**  (-10000,10000)
* **`Max Y` ($6)** (float) : défaut = **6**  (-10000,10000)
* **`Axes` ($7)** (bool) : par défaut = Faux (0)
* **`Grid` ($8)** (bool) : par défaut = Faux (0)
* **`Grid Cell Size` ($9)** (int) : défaut = **1**  (1,5)
(Note) : Author: Claude Lion. Latest Update: 2024/10/22.
