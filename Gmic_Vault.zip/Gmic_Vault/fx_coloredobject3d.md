---
tags: [gmic, filter]
command: fx_coloredobject3d
---

# Filtre G'MIC : fx_coloredobject3d

## Structure de la commande
```text
fx_coloredobject3d:
    type = $1
    size_1 = $6
    size_2 = $7
    size_3 = $8
    x_angle = $9
    y_angle = $10
    z_angle = $11
    fov = $12
    x_light = $13
    y_light = $14
    z_light = $15
    specular_lightness = $16
    specular_shininess = $17
    rendering = $18
    antialiasing = $19
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Renders a custom 3D colored object. 
* **`Type` ($1)** (choice) : choix possibles => Plane, Box, Pyramid, Ellipsoid, Torus, Gyroid, Weird, Cup
* **`Color` ($2)** (color) : défaut = 128,128,128,255
* **`Size-1` ($3)** (float) : défaut = **0.5**  (0,3)
* **`Size-2` ($4)** (float) : défaut = **0.5**  (0,3)
* **`Size-3` ($5)** (float) : défaut = **0.5**  (0,3)
* **`X-Angle` ($6)** (float) : défaut = **57**  (0,360)
* **`Y-Angle` ($7)** (float) : défaut = **41**  (0,360)
* **`Z-Angle` ($8)** (float) : défaut = **21**  (0,360)
* **`FOV` ($9)** (float) : défaut = **45**  (1,90)
* **`X-Light` ($10)** (float) : défaut = **0**  (-100,100)
* **`Y-Light` ($11)** (float) : défaut = **0**  (-100,100)
* **`Z-Light` ($12)** (float) : défaut = **-100**  (-100,0)
* **`Specular Lightness` ($13)** (float) : défaut = **0.5**  (0,1)
* **`Specular Shininess` ($14)** (float) : défaut = **0.7**  (0,3)
* **`Rendering` ($15)** (choice) : choix possibles => Dots, Wireframe, Flat, Flat-Shaded, Gouraud, Phong
* **`Antialiasing` ($16)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2011/05/16.
