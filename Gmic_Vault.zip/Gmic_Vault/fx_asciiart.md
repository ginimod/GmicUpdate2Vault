---
tags: [gmic, filter]
command: fx_asciiart
---

# Filtre G'MIC : fx_asciiart

## Structure de la commande
```text
fx_asciiart:
    charset = $1
    analysis_scale = $3
    analysis_smoothness = $4
    synthesis_scale = $5
    result_type = $6
    gamma = $7
    smoothness = $8
    colors = $9
    output_ascii_file = $10
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Converts the image into a text-based ASCII art representation. 
* **`Charset` ($1)** (choice) : choix possibles => Custom, Binary Digits, Digits, Lowercase Letters, Uppercase Letters, Ascii, Card Suits, Math Symbols
* **`Analysis Scale` ($2)** (int) : défaut = **16**  (8,103)
* **`Analysis Smoothness` ($3)** (float) : défaut = **15**  (0,100)
* **`Synthesis Scale` ($4)** (int) : défaut = **16**  (8,103)
* **`Result Type` ($5)** (choice) : choix possibles => White on Black, Black on White, Colored on Black, Colored on Transparent
* **`Gamma` ($6)** (float) : défaut = **0**  (-3,3)
* **`Smoothness` ($7)** (float) : défaut = **0.2**  (0,5)
* **`Colors` ($8)** (choice) : choix possibles => Full Colors, 2 Colors, 3 Colors, 4 Colors, 8 Colors, 12 Colors, 16 Colors, Grayscale, 2 Grays, 3 Grays, 4 Grays, 8 Grays, 12 Grays, 16 Grays
* **`Output Ascii File` ($9)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2014/03/27.
