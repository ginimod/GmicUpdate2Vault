---
tags: [gmic, filter]
command: fx_blend_average_all
---

# Filtre G'MIC : fx_blend_average_all

## Structure de la commande
```text
fx_blend_average_all:
    color_space = $1
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Averages all visible layers. 
* **`Color Space` ($1)** (choice) : choix possibles => SRGB, Linear RGB, Lab
(Note) : Note: This filter takes multiple layers as input and average them. Set the Input layers option to handle multiple input layers. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2013/08/11.
