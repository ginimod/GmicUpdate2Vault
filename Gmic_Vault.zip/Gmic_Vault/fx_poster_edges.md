---
tags: [gmic, filter]
command: fx_poster_edges
---

# Filtre G'MIC : fx_poster_edges

## Structure de la commande
```text
fx_poster_edges:
    image_smoothness = $1
    edge_threshold = $2
    edge_shade = $3
    edge_thickness = $4
    edge_antialiasing = $5
    posterization_level = $6
    posterization_antialiasing = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Reduces colors and emphasizes edges with dark lines. 
* **`Image Smoothness` ($1)** (float) : défaut = **20**  (0,100)
* **`Edge Threshold` ($2)** (float) : défaut = **60**  (0,100)
* **`Edge Shade` ($3)** (float) : défaut = **5**  (0,30)
* **`Edge Thickness` ($4)** (float) : défaut = **0**  (0,5)
* **`Edge Antialiasing` ($5)** (float) : défaut = **10**  (0,100)
* **`Posterization Level` ($6)** (int) : défaut = **0**  (0,15)
* **`Posterization Antialiasing` ($7)** (float) : défaut = **0**  (0,100)
(Note) : Authors: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a> and David Revoy.       Latest Update: 2012/11/30.
