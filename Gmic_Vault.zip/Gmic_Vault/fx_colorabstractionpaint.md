---
tags: [gmic, filter]
command: fx_ColorAbstractionPaint
---

# Filtre G'MIC : fx_ColorAbstractionPaint

## Structure de la commande
```text
fx_ColorAbstractionPaint:
    abstraction = $1
    ellipse_ratio = $2
    ellipsionism_opacity = $3
    use_as_hue = $4
    painting_opacity = $5
    use_as_saturation = $6
    color_abstraction_opacity = $7
    negative_color_abstraction = $8
    cubism_on_color_abstraction = $9
    kuwahara_on_painting = $10
    soften = $11
    soften_all_channels = $12
    donotmergelayers = $13
    preview_type = $14
```
## Définition des variables
* **`Abstraction` ($1)** (int) : défaut = **5**  (1,10)
* **`Ellipse Ratio` ($2)** (float) : défaut = **10**  (1,100)
(Note) : Opacities, try 0 to see individual effect layers
* **`Ellipsionism Opacity` ($3)** (float) : défaut = **1**  (0,1)
* **`Use as Hue` ($4)** (bool) : par défaut = Faux (0)
* **`Painting Opacity` ($5)** (float) : défaut = **1**  (-1,1)
* **`Use as Saturation` ($6)** (bool) : par défaut = Faux (0)
* **`Color Abstraction Opacity` ($7)** (float) : défaut = **1**  (-1,1)
* **`Negative Color Abstraction` ($8)** (bool) : par défaut = Faux (0)
* **`Cubism on Color Abstraction` ($9)** (bool) : par défaut = Faux (0)
* **`Kuwahara on Painting` ($10)** (bool) : par défaut = Faux (0)
* **`Soften` ($11)** (float) : défaut = **0**  (0,100)
* **`Soften All Channels` ($12)** (bool) : par défaut = Faux (0)
* **`DoNotMergeLayers` ($13)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($14)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author : Arto Huotari.      Latest update : 2014/02/23.
