---
tags: [gmic, filter]
command: fx_blur_dof
---

# Filtre G'MIC : fx_blur_dof

## Structure de la commande
```text
fx_blur_dof:
    blur_amplitude = $1
    blur_precision = $2
    depth_of_field_type = $3
    invert_blur = $4
    center_x = $5
    center_y = $6
    first_radius = $7
    second_radius = $8
    angle = $9
    sharpness = $10
    preview_guides = $11
    gamma = $12
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates camera depth of field blurring. 
* **`Blur Amplitude` ($1)** (float) : défaut = **3**  (0,20)
* **`Blur Precision` ($2)** (int) : défaut = **16**  (2,64)
* **`Depth-Of-Field Type` ($3)** (choice) : choix possibles => Gaussian, User-Defined (Bottom Layer)
* **`Invert Blur` ($4)** (bool) : par défaut = Faux (0)
(Note) : Gaussian depth-of-field:
* **`Center (%)` ($5)** (point) : position = 0,0
* **`First Radius` ($6)** (float) : défaut = **30**  (0,200)
* **`Second Radius` ($7)** (float) : défaut = **30**  (0,200)
* **`Angle` ($8)** (float) : défaut = **0**  (0,180)
* **`Sharpness` ($9)** (float) : défaut = **1**  (0,8)
* **`Preview Guides` ($10)** (bool) : par défaut = Faux (0)
(Note) : User-defined depth-of-field:
* **`Gamma` ($11)** (float) : défaut = **0**  (-2,2)
(Note) : You can specify your own depth-of-field image, as a bottom layer image whose luminance encodes the depth for each pixel. Don't forget to modify the Input layers combo-box to make this layer active for the filter.
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2014/02/25.
