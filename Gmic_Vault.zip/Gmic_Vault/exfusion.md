---
tags: [gmic, filter]
command: exfusion
---

# Filtre G'MIC : exfusion

## Structure de la commande
```text
exfusion:
    width = $1
```
## Définition des variables
* **`Width` ($1)** (float) : défaut = **20**  (0,50)
