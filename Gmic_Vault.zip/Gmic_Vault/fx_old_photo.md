---
tags: [gmic, filter]
command: fx_old_photo
---

# Filtre G'MIC : fx_old_photo

## Structure de la commande
```text
fx_old_photo:
    vignette_strength = $1
    vignette_min_radius = $2
    vignette_max_radius = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds a border and aging effects to look like an old photo. 
* **`Vignette Strength` ($1)** (float) : défaut = **200**  (0,255)
* **`Vignette Min Radius` ($2)** (float) : défaut = **50**  (0,100)
* **`Vignette Max Radius` ($3)** (float) : défaut = **85**  (0,100)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
