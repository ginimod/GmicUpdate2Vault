---
tags: [gmic, filter]
command: fx_mesh_blend
---

# Filtre G'MIC : fx_mesh_blend

## Structure de la commande
```text
fx_mesh_blend:
    process_as = $1
    resize_interpolation = $2
    reverse_blending_layers = $3
    dimensions = $4
    blend_alpha_channels = $5
    keep_mesh = $6
```
## Définition des variables
(Note) : Universal blending algorithm. Resizes an RGB(A) image to a 256x256 image and uses it as an RGBA LUT 'transfer function mesh' to blend two other images together. Based on method shown <a href="https://discuss.pixls.us/t/im-generating-new-blending-modes-for-krita/8104/16">on discuss.pixls.us</a>.
(Note) : [0] is bottom layer, [1] is top layer, [2] is mesh. Mesh origin is at bottom-left. Plugin GUI preview does not accurately show mesh.
* **`Process As` ($1)** (choice) : choix possibles => Three-By-Three, Self-Mesh and Self-Blend for Each Layer
* **`Resize Interpolation` ($2)** (choice) : choix possibles => None, Nearest, Average, Bilinear, Grid, Bicubic
* **`Reverse Blending Layers` ($3)** (bool) : par défaut = Faux (0)
* **`Dimensions` ($4)** (choice) : choix possibles => Bottom Layer, Top Layer
* **`Blend Alpha Channels` ($5)** (bool) : par défaut = Faux (0)
* **`Keep Mesh` ($6)** (bool) : par défaut = Faux (0)
