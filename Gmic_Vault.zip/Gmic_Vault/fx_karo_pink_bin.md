---
tags: [gmic, filter]
command: fx_karo_pink_bin
---

# Filtre G'MIC : fx_karo_pink_bin

## Structure de la commande
```text
fx_karo_pink_bin:
    auto_threshold = $1
    threshold = $2
    pink_operator = $3
    connectivity_dir = $4
    height_rep = $5
    algorithm = $6
    channel_s = $7
    preview_type = $8
    preview_split_x = $9
    preview_split_y = $10
```
## Définition des variables
* **`Auto-Threshold` ($1)** (bool) : par défaut = Faux (0)
* **`Threshold (%)` ($2)** (int) : défaut = **50**  (0,100)
* **`Pink Operator` ($3)** (choice) : choix possibles => Skelpar, Skelend, Skelcurv, Skeleton, Barycentre, Border, Closeball, Openball, Convexhull, Dist, Distc, Label Pla, Lantuejoul
* **`Connectivity / Dir` ($4)** (choice) : choix possibles => Four/x, Eight/y
* **`Height/Rep` ($5)** (int) : défaut = **5**  (-1,25)
* **`Algorithm` ($6)** (int) : défaut = **4**  (0,31)
* **`Channel(s)` ($7)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CYMK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
* **`Preview Type` ($8)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($9)** (point) : position = 0,0
(Note) : Binary operations with Pink externals.
(Note) : Diverse Pink executables in search PATH
(Note) : Author : KaRo.           Latest update : 2014/02/05.
