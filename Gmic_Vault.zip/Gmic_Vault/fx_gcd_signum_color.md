---
tags: [gmic, filter]
command: fx_gcd_signum_color
---

# Filtre G'MIC : fx_gcd_signum_color

## Structure de la commande
```text
fx_gcd_signum_color:
    sigma1 = $1
    sigma2 = $2
    axes1 = $3
    axes2 = $4
```
## Définition des variables
* **`Sigma1` ($1)** (float) : défaut = **0.1**  (0,1)
* **`Sigma2` ($2)** (float) : défaut = **5**  (0,20)
* **`Axes1` ($3)** (choice) : choix possibles => Xy, X, Y
* **`Axes2` ($4)** (choice) : choix possibles => Xy, X, Y
(Note) : Author : Garagecoder.      Latest update : 2022/11/01.
