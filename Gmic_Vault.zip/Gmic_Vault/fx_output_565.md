---
tags: [gmic, filter]
command: fx_output_565
---

# Filtre G'MIC : fx_output_565

## Structure de la commande
```text
fx_output_565:
    reverse_endianness = $2
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Exports the image to raw RGB-565 format. 
* **`Reverse Endianness` ($1)** (bool) : par défaut = Faux (0)
(Note) : Note: This filter saves your selected layer as a raw RGB-565 file. Keep in mind that you have to remember the image dimension if you want to reload the image file afterwards!
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2020/05/03.
