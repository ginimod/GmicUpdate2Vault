---
tags: [gmic, filter]
command: fx_extract_foreground
---

# Filtre G'MIC : fx_extract_foreground

## Structure de la commande
```text
fx_extract_foreground:
    feathering = $1
    dilation = $2
    output_mode = $3
    view_resolution = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Interactively separates foreground from background (Matting). 
* **`Feathering` ($1)** (float) : défaut = **0**  (0,4)
* **`Dilation` ($2)** (int) : défaut = **0**  (-32,32)
* **`Output Mode` ($3)** (choice) : choix possibles => RGBA Image (Full-Transparency / 1 Layer), RGBA Image (Updatable / 1 Layer), RGB Image + Binary Mask (2 Layers), RGBA Foreground + Background (2 Layers)
* **`View Resolution` ($4)** (choice) : choix possibles => Small (Faster), Medium, High (Slower), Very High (Even Slower)
(Note) : Description:
 This filter lets you quickly extract foreground objects from background in opaque RGB images. Click on the Apply or OK buttons below to open the interactive window and start adding foreground and background control points. When you're done, exit the interactive window: your extracted foreground will be transferred back to the host software.

 If you are not satisfied with the result, click on Apply once again to modify your control points defined previously. To remove all control points, click on the Reset button above. 
(Note) : Interactions:
 Use the following actions in the interactive window to build your extraction mask:

 - Left mouse button or key F create a new foreground control point (or move an existing one).
 - Right mouse button or key B create a new background control point (or move an existing one).
 - Mouse wheel, or keys CTRL+arrows UP/DOWN zoom view in/out.
 - Key SPACE updates the extraction mask.
 - Key TAB toggles background view modes.
 - Key M toggles marker view modes.
 - Key BACKSPACE deletes the last control point added.
 - Key PAGE UP increases background opacity.
 - Key PAGE DOWN decreases background opacity.
 - Keys CTRL+D increase window size.
 - Keys CTRL+C decrease window size.
 - Keys CTRL+R reset window size.
 - Keys ESC, Q or RETURN exit the interactive window. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2014/09/29.
