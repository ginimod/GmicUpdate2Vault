---
tags: [gmic, filter]
command: afre_cleantext
---

# Filtre G'MIC : afre_cleantext

## Structure de la commande
```text
afre_cleantext:
    clean = $1
    range = $2
    black = $3
    white = $4
```
## Définition des variables
(Note) : <strong>Clean scanned text.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2019 Jun8.</strong>


* **`Clean` ($1)** (int) : défaut = **8**  (0,10)
* **`Range` ($2)** (float) : défaut = **1**  (0.2,1)
* **`Black` ($3)** (int) : défaut = **80**  (0,100)
* **`White` ($4)** (int) : défaut = **95**  (0,100)
