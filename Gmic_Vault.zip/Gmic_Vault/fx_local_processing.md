---
tags: [gmic, filter]
command: fx_local_processing
---

# Filtre G'MIC : fx_local_processing

## Structure de la commande
```text
fx_local_processing:
    action = $1
    strength = $2
    neighborhood_size = $3
    overlap = $4
    regularization = $5
    process_channels_individually = $6
    channel_s = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Applies processing steps to local image blocks. 
* **`Action` ($1)** (choice) : choix possibles => Normalize, Equalize
* **`Strength (%)` ($2)** (float) : défaut = **75**  (0,100)
* **`Neighborhood Size (%)` ($3)** (float) : défaut = **10**  (1,100)
* **`Overlap (%)` ($4)** (float) : défaut = **50**  (0,75)
* **`Regularization (%)` ($5)** (float) : défaut = **20**  (0,100)
* **`Process Channels Individually` ($6)** (bool) : par défaut = Faux (0)
* **`Channel(s)` ($7)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2018/02/28.
