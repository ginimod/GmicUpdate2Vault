---
tags: [gmic, filter]
command: fx_gcd_cumul_math
---

# Filtre G'MIC : fx_gcd_cumul_math

## Structure de la commande
```text
fx_gcd_cumul_math:
    operation = $1
    amount = $2
    step = $3
    horizontal = $4
    preview_type = $5
```
## Définition des variables
(Note) : Cumulative Math glitch filter
* **`Operation` ($1)** (choice) : choix possibles => Add, Or, Xor, And, Mod
* **`Amount` ($2)** (int) : défaut = **1**  (1,512)
* **`Step` ($3)** (int) : défaut = **1**  (1,256)
* **`Horizontal` ($4)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($5)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author : Garagecoder.      Latest update : 2018/08/18.
