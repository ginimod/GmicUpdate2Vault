---
tags: [gmic, filter]
command: fx_hnorm
---

# Filtre G'MIC : fx_hnorm

## Structure de la commande
```text
fx_hnorm:
    strength = $1
    contrast = $2
    invert = $3
```
## Définition des variables
* **`Strength` ($1)** (float) : défaut = **1**  (0.5,1.5)
* **`Contrast` ($2)** (int) : défaut = **50**  (1,99)
* **`Invert` ($3)** (bool) : par défaut = Faux (0)
(Note) : Filter by <a href="https://discuss.pixls.us/u/afre">afre</a>. Latest update: 2018-05-09.
