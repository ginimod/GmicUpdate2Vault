---
tags: [gmic, filter]
command: fx_drop_shadow
---

# Filtre G'MIC : fx_drop_shadow

## Structure de la commande
```text
fx_drop_shadow:
    x_offset = $1
    y_offset = $2
    smoothness = $3
    x_curvature = $4
    y_curvature = $5
    expand_size = $9
    output_as_separate_layers = $10
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds a standard drop shadow behind the opaque object. 
* **`X-Offset` ($1)** (float) : défaut = **3**  (-20,20)
* **`Y-Offset` ($2)** (float) : défaut = **3**  (-20,20)
* **`Smoothness` ($3)** (float) : défaut = **1.8**  (0,5)
* **`X-Curvature` ($4)** (float) : défaut = **0**  (-2,2)
* **`Y-Curvature` ($5)** (float) : défaut = **0**  (-2,2)
* **`Color` ($6)** (color) : défaut = 0,0,0
* **`Expand Size` ($7)** (bool) : par défaut = Faux (0)
* **`Output as Separate Layers` ($8)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2023/09/02.
