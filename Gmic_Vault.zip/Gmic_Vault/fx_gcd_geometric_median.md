---
tags: [gmic, filter]
command: fx_gcd_geometric_median
---

# Filtre G'MIC : fx_gcd_geometric_median

## Structure de la commande
```text
fx_gcd_geometric_median:
    radius = $1
    iters = $2
    channel_s = $3
    preview_type = $4
    preview_split_x = $5
    preview_split_y = $6
```
## Définition des variables
(Note) : Smooth using windowed geometric median of vectors
* **`Radius` ($1)** (int) : défaut = **3**  (1,9)
* **`Iters` ($2)** (int) : défaut = **12**  (1,20)
* **`Channel(s)` ($3)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CYMK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
* **`Preview Type` ($4)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($5)** (point) : position = 0,0
(Note) : Author : Garagecoder.      Latest update : 2018/07/18.
(Note) : 
<u>Notes</u>
(Note) : This prototype filter can be extremely slow to compute!
(Note) : Only odd window sizes are currently supported.
