---
tags: [gmic, filter]
command: fx_clut_from_ab
---

# Filtre G'MIC : fx_clut_from_ab

## Structure de la commande
```text
fx_clut_from_ab:
    output_mode = $1
    output_clut_resolution = $2
    clut_format = $3
    influence_of_color_samples = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a CLUT based on the difference between two layers. 
* **`Output Mode` ($1)** (choice) : choix possibles => Replace Layer with CLUT, Insert New CLUT Layer, Save CLUT as .cube or .png File
* **`Output CLUT Resolution` ($2)** (choice) : choix possibles => 16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 225, 256
* **`CLUT Format` ($3)** (choice) : choix possibles => Hald CLUT, RGB LUT
* **`Influence of Color Samples (%)` ($4)** (float) : défaut = **50**  (0,100)
(Note) : What is this filter for?

 This filter requires at least two input layers to work properly.
 It assumes you have an input top layer A and a base layer B such that A and B both represent the same image but with only color variations (typically A has been obtained from B using the color curves tool).

 This filter is then able to estimate and outputs a color HaldCLUT H so that applying H on the base layer B gives back A.

 This is useful when you have a color transformation between two images, that you want to recover and re-apply to a bunch of other images. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>. Latest Update: 2019/08/27.
