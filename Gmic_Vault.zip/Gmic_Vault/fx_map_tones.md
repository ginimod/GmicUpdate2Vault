---
tags: [gmic, filter]
command: fx_map_tones
---

# Filtre G'MIC : fx_map_tones

## Structure de la commande
```text
fx_map_tones:
    threshold = $1
    gamma = $2
    smoothness = $3
    iterations = $4
    channel_s = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Compresses dynamic range to reveal shadow/highlight details. 
* **`Threshold` ($1)** (float) : défaut = **0.5**  (0,1)
* **`Gamma` ($2)** (float) : défaut = **0.7**  (0,1)
* **`Smoothness` ($3)** (float) : défaut = **0.1**  (0,10)
* **`Iterations` ($4)** (int) : défaut = **30**  (0,500)
* **`Channel(s)` ($5)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
