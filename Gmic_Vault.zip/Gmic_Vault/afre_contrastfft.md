---
tags: [gmic, filter]
command: afre_contrastfft
---

# Filtre G'MIC : afre_contrastfft

## Structure de la commande
```text
afre_contrastfft:
    strength = $1
    amount = $2
    iterations = $3
```
## Définition des variables
(Note) : <strong>Enhance contrast with Fourier transform.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2019.</strong>


* **`Strength` ($1)** (int) : défaut = **75**  (1,100)
* **`Amount` ($2)** (int) : défaut = **50**  (0,100)
* **`Iterations` ($3)** (int) : défaut = **1**  (1,10)
