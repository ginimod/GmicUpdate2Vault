---
tags: [gmic, filter]
command: fx_graphic_boost
---

# Filtre G'MIC : fx_graphic_boost

## Structure de la commande
```text
fx_graphic_boost:
    radius = $1
    darken = $2
    skip_others_steps = $3
    pencil_size = $4
    pencil_amplitude = $5
    skip_others_steps = $6
    activate_pencil_smoother = $7
    pencil_smoother_sharpness = $8
    pencil_smoother_edge_protection = $9
    pencil_smoother_smoothness = $10
    skip_others_steps = $11
    swap_layers = $12
    merging_option = $13
    intensity = $14
    add_painter_s_touch = $15
    painter_s_touch_sharpness = $16
    painter_s_edge_protection_flow = $17
    painter_s_smoothness = $18
    preview_type = $19
```
## Définition des variables
(Note) : Unsharp Mask controls
* **`Radius` ($1)** (float) : défaut = **1.25**  (0,20)
* **`Darken` ($2)** (float) : défaut = **2**  (0,10)
* **`Skip Others Steps` ($3)** (bool) : par défaut = Faux (0)
(Note) : Check for visual control, UNcheck to reactivate the other controls
(Note) : BW_Pencil Controls
* **`Pencil Size` ($4)** (float) : défaut = **0.15**  (0,4)
* **`Pencil Amplitude` ($5)** (float) : défaut = **14**  (0,200)
* **`Skip Others Steps` ($6)** (bool) : par défaut = Faux (0)
* **`Activate 'Pencil Smoother'` ($7)** (bool) : par défaut = Faux (0)
(Note) : If unchecked the 3 sliders below are disabled
* **`Pencil Smoother Sharpness` ($8)** (float) : défaut = **0.5**  (0,2)
* **`Pencil Smoother Edge Protection` ($9)** (float) : défaut = **0.45**  (0,1)
* **`Pencil Smoother Smoothness` ($10)** (float) : défaut = **2**  (0,10)
* **`Skip Others Steps` ($11)** (bool) : par défaut = Faux (0)
(Note) : Merging Options
* **`Swap Layers` ($12)** (bool) : par défaut = Faux (0)
(Note) : 'Swap' change the effect of Merging and Intensity
* **`Merging Option` ($13)** (choice) : choix possibles => Hard Light, Grain Merge, Multiply, Color Burn, Overlay, Value, Darken, Stamp
* **`Intensity` ($14)** (float) : défaut = **1**  (0,1)
* **`Add Painter's Touch` ($15)** (bool) : par défaut = Faux (0)
(Note) : If unchecked the 3 sliders below are disabled
* **`Painter's Touch Sharpness` ($16)** (float) : défaut = **0.5**  (0,2)
* **`Painter's Edge Protection Flow` ($17)** (float) : défaut = **0.45**  (0,1)
* **`Painter's Smoothness` ($18)** (float) : défaut = **1**  (0,10)
* **`Preview Type` ($19)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author: PhotoComiX.      Latest update : 2011/10/01.
