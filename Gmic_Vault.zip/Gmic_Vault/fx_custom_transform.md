---
tags: [gmic, filter]
command: fx_custom_transform
---

# Filtre G'MIC : fx_custom_transform

## Structure de la commande
```text
fx_custom_transform:
    value_normalization = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Applies a user-defined mathematical formula to image colors. 
* **`Value Normalization` ($1)** (choice) : choix possibles => None, RGB, RGBA
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
