---
tags: [gmic, filter]
command: fx_noisepainting
---

# Filtre G'MIC : fx_noisepainting

## Structure de la commande
```text
fx_noisepainting:
    spread_noise = $1
    additive_noise = $2
    luminance_only = $3
    abstraction = $4
    details_scale = $5
    color = $6
    smoothness = $7
    sharpen_shades = $8
    preview_type = $9
```
## Définition des variables
(Note) : A preprocess suggestion for the painting filter.
(Note) : Pre process for painting
* **`Spread Noise` ($1)** (int) : défaut = **0**  (0,20)
* **`Additive Noise` ($2)** (int) : défaut = **0**  (0,30)
* **`Luminance Only` ($3)** (bool) : par défaut = Faux (0)
(Note) : Painting abstration
* **`Abstraction` ($4)** (int) : défaut = **5**  (1,10)
* **`Details Scale` ($5)** (float) : défaut = **2.5**  (0,5)
* **`Color` ($6)** (float) : défaut = **1.5**  (0,4)
* **`Smoothness` ($7)** (float) : défaut = **50**  (0,1000)
* **`Sharpen Shades` ($8)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($9)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) :  Author: Arto Huotari Latest update : 2012/07/12.
