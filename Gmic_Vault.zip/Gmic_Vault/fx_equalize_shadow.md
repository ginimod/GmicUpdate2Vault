---
tags: [gmic, filter]
command: fx_equalize_shadow
---

# Filtre G'MIC : fx_equalize_shadow

## Structure de la commande
```text
fx_equalize_shadow:
    amplitude = $1
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Boosts brightness in shadow areas. 
* **`Amplitude` ($1)** (float) : défaut = **1**  (0,1)
(Note) : Authors: Francois Grassard and <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.       Latest Update: 2021/03/23.
