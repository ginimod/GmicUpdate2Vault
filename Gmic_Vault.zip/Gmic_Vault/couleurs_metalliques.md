---
tags: [gmic, filter]
command: Couleurs_Metalliques
---

# Filtre G'MIC : Couleurs_Metalliques

## Structure de la commande
```text
Couleurs_Metalliques:
    transparence_transparency = $1
    rendu_rendering = $2
    amplitude = $3
    type_de_bruit_noise_type = $4
    etendue_value_range = $5
    double_effet = $6
    amplitude = $7
    rayon_radius = $8
    lissage_voisinage_neighborhood_smoothness = $9
    lissage_moyenne_average_smoothness = $10
    imposer_valeurs_constrain_values = $11
    canaux_channel_s = $12
    amplitude = $13
    utiliser_use_pc_options = $14
    filtre_pencilbw_taille_size = $15
    filtre_pencilbw_amplitude = $16
    opacite_melange_blend_opacity = $17
    melange_permuter_calques_blend_revert_layers = $18
    type_apercu = $19
```
## Définition des variables
(Note) : Rendu - Rendering
* **`Transparence / Transparency` ($1)** (choice) : choix possibles => Conserver / Preserve, Supprimer / Remove
* **`Rendu / Rendering` ($2)** (choice) : choix possibles => YCbCr [luminance], Lab [lightness], HSV [value], HSL [lightness], Linear RGB [all], RGB [all], RGB [all]
(Note) : Paramètres Filtre Noise - Noise parameters
* **`Amplitude` ($3)** (float) : défaut = **22**  (0,200)
* **`Type De Bruit / Noise Type` ($4)** (choice) : choix possibles => Gaussian, Uniform, Salt and Pepper, Poisson
* **`Étendue / Value Range` ($5)** (choice) : choix possibles => Cut, Normalize
(Note) : Paramètres Filtre Local normalization - Local normalization parameters
* **`Double Effet` ($6)** (bool) : par défaut = Faux (0)
* **`Amplitude` ($7)** (float) : défaut = **0**  (0,60)
* **`Rayon / Radius` ($8)** (int) : défaut = **6**  (1,64)
* **`Lissage Voisinage / Neighborhood Smoothness` ($9)** (float) : défaut = **5**  (0,40)
* **`Lissage Moyenne / Average Smoothness` ($10)** (float) : défaut = **20**  (0,40)
* **`Imposer Valeurs / Constrain Values` ($11)** (bool) : par défaut = Faux (0)
* **`Canaux / Channel(s)` ($12)** (choice) : choix possibles => All, RGBA [all], RGB [all], RGB [red], RGB [green], RGB [blue], RGBA [alpha], Linear RGB [all], Linear RGB [red], Linear RGB [green], Linear RGB [blue], YCbCr [luminance], YCbCr [blue-Red Chrominances], YCbCr [blue Chrominance], YCbCr [red Chrominance], YCbCr [green Chrominance], Lab [lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [hue], HSV [saturation], HSV [value], HSI [intensity], HSL [lightness], CMYK [cyan], CMYK [magenta], CMYK [yellow], CMYK [key]
(Note) : Paramètres Filtre Boost-Fade - Boost-Fade parameters : Siif Amplitude Sup. 0
* **`Amplitude` ($13)** (float) : défaut = **0**  (0,10)
(Note) : PhotoComix Options
* **`Utiliser / Use PC Options` ($14)** (bool) : par défaut = Faux (0)
* **`Filtre Pencilbw Taille / Size` ($15)** (float) : défaut = **0.3**  (0,5)
* **`Filtre Pencilbw Amplitude` ($16)** (float) : défaut = **60**  (0,200)
* **`Opacité Mélange / Blend Opacity` ($17)** (float) : défaut = **1**  (0,1)
* **`Mélange Permuter Calques / Blend Revert Layers` ($18)** (bool) : par défaut = Faux (0)
* **`Type Aperçu` ($19)** (choice) : choix possibles => Tout, Rendu En Bas, Rendu a Droite, Rendu En Haut, Rendu a Gauche
(Note) : samj      Dernière mise à jour : 2015/03/31.
