---
tags: [gmic, filter]
command: fx_mix_cmyk
---

# Filtre G'MIC : fx_mix_cmyk

## Structure de la commande
```text
fx_mix_cmyk:
    cyan_factor = $1
    cyan_shift = $2
    cyan_smoothness = $3
    magenta_factor = $4
    magenta_shift = $5
    magenta_smoothness = $6
    yellow_factor = $7
    yellow_shift = $8
    yellow_smoothness = $9
    key_factor = $10
    key_shift = $11
    key_smoothness = $12
    tones_range = $13
    tones_smoothness = $14
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Mixes channels using the CMYK color model. 
* **`Cyan Factor` ($1)** (float) : défaut = **1**  (0,4)
* **`Cyan Shift` ($2)** (float) : défaut = **0**  (-255,255)
* **`Cyan Smoothness` ($3)** (float) : défaut = **0**  (0,10)
* **`Magenta Factor` ($4)** (float) : défaut = **1**  (0,4)
* **`Magenta Shift` ($5)** (float) : défaut = **0**  (-255,255)
* **`Magenta Smoothness` ($6)** (float) : défaut = **0**  (0,10)
* **`Yellow Factor` ($7)** (float) : défaut = **1**  (0,4)
* **`Yellow Shift` ($8)** (float) : défaut = **0**  (-255,255)
* **`Yellow Smoothness` ($9)** (float) : défaut = **0**  (0,10)
* **`Key Factor` ($10)** (float) : défaut = **1**  (0,4)
* **`Key Shift` ($11)** (float) : défaut = **0**  (-255,255)
* **`Key Smoothness` ($12)** (float) : défaut = **0**  (0,10)
* **`Tones Range` ($13)** (choice) : choix possibles => All Tones, Shadows, Mid-Tones, Highlights
* **`Tones Smoothness` ($14)** (float) : défaut = **2**  (0,10)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/06/20.
