---
tags: [gmic, filter]
command: fx_poster_hope
---

# Filtre G'MIC : fx_poster_hope

## Structure de la commande
```text
fx_poster_hope:
    gamma = $1
    smoothness = $2
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Recreates the style of the iconic "Hope" poster. 
* **`Gamma` ($1)** (float) : défaut = **0**  (-3,3)
* **`Smoothness` ($2)** (float) : défaut = **3**  (0,20)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2013/11/07.
