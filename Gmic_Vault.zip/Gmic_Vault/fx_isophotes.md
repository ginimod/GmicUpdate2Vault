---
tags: [gmic, filter]
command: fx_isophotes
---

# Filtre G'MIC : fx_isophotes

## Structure de la commande
```text
fx_isophotes:
    levels = $1
    smoothness = $2
    filling = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Draws lines connecting points of equal brightness. 
* **`Levels` ($1)** (int) : défaut = **8**  (1,256)
* **`Smoothness` ($2)** (float) : défaut = **4**  (0,10)
* **`Filling` ($3)** (choice) : choix possibles => Transparent, Colors
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
