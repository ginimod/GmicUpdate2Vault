---
tags: [gmic, filter]
command: fx_polka_dots
---

# Filtre G'MIC : fx_polka_dots

## Structure de la commande
```text
fx_polka_dots:
    size = $1
    density = $2
    first_offset = $3
    second_offset = $4
    angle = $5
    aliasing = $6
    shading = $7
    opacity = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a polka dot pattern. 
* **`Size` ($1)** (float) : défaut = **80**  (0,100)
* **`Density` ($2)** (float) : défaut = **20**  (0.1,100)
* **`First Offset` ($3)** (float) : défaut = **50**  (0,100)
* **`Second Offset` ($4)** (float) : défaut = **50**  (0,100)
* **`Angle` ($5)** (float) : défaut = **0**  (0,180)
* **`Aliasing` ($6)** (float) : défaut = **0.5**  (0.1,1)
* **`Shading` ($7)** (float) : défaut = **0.1**  (0.1,1)
* **`Opacity` ($8)** (float) : défaut = **1**  (0,1)
* **`Color` ($9)** (color) : défaut = 255,0,0,255
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
