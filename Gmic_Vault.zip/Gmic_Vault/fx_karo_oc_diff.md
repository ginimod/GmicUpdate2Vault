---
tags: [gmic, filter]
command: fx_karo_oc_diff
---

# Filtre G'MIC : fx_karo_oc_diff

## Structure de la commande
```text
fx_karo_oc_diff:
    size = $1
    shape = $2
    channel_s = $3
    scale = $4
    preview_type = $5
    preview_split_x = $6
    preview_split_y = $7
```
## Définition des variables
* **`Size` ($1)** (int) : défaut = **5**  (2,25)
* **`Shape` ($2)** (choice) : choix possibles => Square, Octagon, Circle
* **`Channel(s)` ($3)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CYMK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
* **`Scale` ($4)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($5)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($6)** (point) : position = 0,0
(Note) : Difference of mean of morphological opening and closing with original.
(Note) : Author : KaRo.           Latest update : 2013/07/04.
