---
tags: [gmic, filter]
command: fx_jr_multi_mosaic_preview
---

# Filtre G'MIC : fx_jr_multi_mosaic_preview

## Structure de la commande
```text
fx_jr_multi_mosaic_preview:
    1_iterations = $2
    2_lowest_density = $3
    3_highest_density = $4
    4_details_influence = $5
    5_details_smoothness = $6
    9_luma_range = $10
    10_chroma_range = $11
    11_hue_range = $12
    12_opacity = $13
    13_smoothness = $14
    14_linearity = $15
    15_min_threshold = $16
    16_max_threshold = $17
    17_thickness = $18
    21_luma_range = $22
    22_chroma_range = $23
    23_hue_range = $24
    24_edge_blend = $25
    25_smoothness = $26
    26_iterations = $27
    27_sharpness = $28
    28_anisotropy = $29
    29_gradient_smoothness = $30
    30_tensor_smoothness = $31
    31_time_step = $32
    32_amplitude = $33
    33_radius = $34
    34_neighborhood_smoothness = $35
    35_average_smoothness = $36
    36_constrain_values = $37
    37_channel_s = $38
```
## Définition des variables
* **`1. Iterations` ($1)** (int) : défaut = **3**  (1,10)
(Note) : Mosaic
* **`2. Lowest Density` ($2)** (float) : défaut = **15**  (0,100)
* **`3. Highest Density` ($3)** (float) : défaut = **45**  (0,100)
* **`4. Details Influence` ($4)** (float) : défaut = **50**  (0,100)
* **`5. Details Smoothness` ($5)** (float) : défaut = **0**  (0,100)
* **`6-8. Colour Balance` ($6)** (color) : défaut = 128,128,128
* **`9. Luma Range` ($7)** (float) : défaut = **0**  (0,100)
* **`10. Chroma Range` ($8)** (float) : défaut = **0**  (0,100)
* **`11. Hue Range` ($9)** (float) : défaut = **0**  (0,100)
(Note) : Edges [Gradient Norm]
* **`12. Opacity` ($10)** (float) : défaut = **1**  (-1,1)
* **`13. Smoothness` ($11)** (float) : défaut = **0**  (0,10)
* **`14. Linearity` ($12)** (float) : défaut = **0.5**  (0,1.5)
* **`15. Min Threshold` ($13)** (float) : défaut = **0**  (0,100)
* **`16. Max Threshold` ($14)** (float) : défaut = **100**  (0,100)
* **`17. Thickness` ($15)** (int) : défaut = **1**  (1,10)
* **`18-20. Color` ($16)** (color) : défaut = 0,0,0
* **`21. Luma Range` ($17)** (float) : défaut = **0**  (0,100)
* **`22. Chroma Range` ($18)** (float) : défaut = **0**  (0,100)
* **`23. Hue Range` ($19)** (float) : défaut = **0**  (0,100)
(Note) : Final Edge Blend
* **`24. Edge Blend` ($20)** (bool) : par défaut = Faux (0)
* **`25. Smoothness` ($21)** (float) : défaut = **15**  (0,100)
(Note) : Smooth [Diffusion]
* **`26. Iterations` ($22)** (int) : défaut = **16**  (0,100)
* **`27. Sharpness` ($23)** (float) : défaut = **0.5**  (0,2)
* **`28. Anisotropy` ($24)** (float) : défaut = **1**  (0,1)
* **`29. Gradient Smoothness` ($25)** (float) : défaut = **3**  (0,10)
* **`30. Tensor Smoothness` ($26)** (float) : défaut = **5**  (0,10)
* **`31. Time Step` ($27)** (float) : défaut = **15**  (5,50)
(Note) : Local Normalization
* **`32. Amplitude` ($28)** (float) : défaut = **2**  (0,60)
* **`33. Radius` ($29)** (int) : défaut = **6**  (1,64)
* **`34. Neighborhood Smoothness` ($30)** (float) : défaut = **5**  (0,40)
* **`35. Average Smoothness` ($31)** (float) : défaut = **20**  (0,40)
* **`36. Constrain Values` ($32)** (bool) : par défaut = Faux (0)
* **`37 .Channel(s)` ($33)** (choice) : choix possibles => All, RGBA [All], RGB [All], RGB [Red], RGB [Green], RGB [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [Hue], HSV [Saturation], HSV [Value], HSI [Intensity], HSL [Lightness], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
