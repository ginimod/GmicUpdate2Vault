---
tags: [gmic, filter]
command: fx_blend
---

# Filtre G'MIC : fx_blend

## Structure de la commande
```text
fx_blend:
    mode = $1
    process_as = $2
    opacity = $3
    preview_all_outputs = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Provides standard layer blending modes (Multiply, Overlay, etc.). 
* **`Mode` ($1)** (choice) : choix possibles => Add, Alpha, And, Average, Blue, Burn, Custom Formula, Darken, Difference, Divide, Dodge, Edges, Exclusion, Freeze, Grain Extract, Grain Merge, Green, Hard Light, Hard Mix, Hue, Interpolation, Lighten, Lightness, Linear Burn, Linear Light, Luminance, Multiply, Negation, Or, Overlay, Pin Light, Red, Reflect, Saturation, Shape Area Max, Shape Area Max0, Shape Area Min, Shape Area Min0, Shape Average, Shape Average0, Shape Median, Shape Median0, Shape Min, Shape Min0, Shape Max, Shape Max0, Shape Prevalent, Soft Burn, Soft Dodge, Soft Light, Screen, Stamp, Subtract, Value, Vivid Light, Xor
* **`Process As` ($2)** (choice) : choix possibles => Two-By-Two, Upper Layer Is the Top Layer for All Blends, Lower Layer Is the Bottom Layer for All Blends
* **`Opacity (%)` ($3)** (float) : défaut = **100**  (0,100)
* **`Preview All Outputs` ($4)** (bool) : par défaut = Faux (0)
(Note) : Note: In custom formulas, <samp>a</samp> and <samp>b</samp> respectively stand for the values of the base layer and the blend layer, and are defined in value range [0,1].
(Note) : Note: This filter needs at least two layers to work properly. Do not forget to set the Input layers option below to handle multiple input layers. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2017/03/08.
