---
tags: [gmic, filter]
command: demo_ra
---

# Filtre G'MIC : demo_ra

## Structure de la commande
```text
demo_ra:
    radius_scale = $1
    angle_scale = $2
```
## Définition des variables
(Note) : mathmap ra: demo
* **`Radius Scale` ($1)** (float) : défaut = **1**  (0,10)
* **`Angle Scale` ($2)** (float) : défaut = **1**  (0,10)
