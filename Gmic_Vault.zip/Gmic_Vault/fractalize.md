---
tags: [gmic, filter]
command: fractalize
---

# Filtre G'MIC : fractalize

## Structure de la commande
```text
fractalize:
    detail_level = $1
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Modifies image to make it look like a Mandelbrot fractal. 
* **`Detail Level` ($1)** (float) : défaut = **0.8**  (0,1)
(Note) : Note: This filter uses lot of random values to generate its result, so running it twice will give you different results !
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2014/04/25.
