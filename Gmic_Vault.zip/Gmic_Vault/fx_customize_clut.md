---
tags: [gmic, filter]
command: fx_customize_clut
---

# Filtre G'MIC : fx_customize_clut

## Structure de la commande
```text
fx_customize_clut:
    keypoint_influence = $1
    lock_uniform_sampling = $2
    spatial_regularization = $3
    brightness = $4
    contrast = $5
    gamma = $6
    hue = $7
    saturation = $8
    post_normalize = $9
    output_corresponding_clut = $10
    preview_type = $11
    clut_opacity = $12
    action_1 = $13
    action_2 = $20
    action_3 = $27
    action_4 = $34
    action_5 = $41
    action_6 = $48
    action_7 = $55
    action_8 = $62
    action_9 = $69
    action_10 = $76
    action_11 = $83
    action_12 = $90
    action_13 = $97
    action_14 = $104
    action_15 = $111
    action_16 = $118
    action_17 = $125
    action_18 = $132
    action_19 = $139
    action_20 = $146
    action_21 = $153
    action_22 = $160
    action_23 = $167
    action_24 = $174
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Tool to build a customized 3D Color Look-Up Table. 
* **`Keypoint Influence (%)` ($1)** (float) : défaut = **100**  (0,100)
* **`Lock Uniform Sampling` ($2)** (choice) : choix possibles => None, 8 Keypoints (RGB Corners), 27 Keypoints, 64 Keypoints, 125 Keypoints, 216 Keypoints, 343 Keypoints
* **`Spatial Regularization` ($3)** (int) : défaut = **10**  (0,30)
(Note) : Global correction:
* **`Brightness (%)` ($4)** (float) : défaut = **0**  (-100,100)
* **`Contrast (%)` ($5)** (float) : défaut = **0**  (-100,100)
* **`Gamma (%)` ($6)** (float) : défaut = **0**  (-100,100)
* **`Hue (%)` ($7)** (float) : défaut = **0**  (-100,100)
* **`Saturation (%)` ($8)** (float) : défaut = **0**  (-100,100)
* **`Post-Normalize` ($9)** (bool) : par défaut = Faux (0)
* **`Output Corresponding CLUT` ($10)** (choice) : choix possibles => Disable, 512x512 Layer, 4096x4096 Layer
* **`Preview Type` ($11)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Horizontal, Duplicate Vertical, HaldCLUT, 3D CLUT (Fast), 3D CLUT (Precise)
* **`CLUT Opacity` ($12)** (float) : défaut = **0.5**  (0,1)
(Note) : Color correspondences:
* **`Action #1` ($13)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #1` ($14)** (color) : défaut = 0,0,0
* **`Target Color #1` ($15)** (color) : défaut = 0,0,0
* **`Action #2` ($16)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #2` ($17)** (color) : défaut = 255,255,255
* **`Target Color #2` ($18)** (color) : défaut = 255,196,128
* **`Action #3` ($19)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #3` ($20)** (color) : défaut = 0,0,0
* **`Target Color #3` ($21)** (color) : défaut = 0,0,0
* **`Action #4` ($22)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #4` ($23)** (color) : défaut = 0,0,0
* **`Target Color #4` ($24)** (color) : défaut = 0,0,0
* **`Action #5` ($25)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #5` ($26)** (color) : défaut = 0,0,0
* **`Target Color #5` ($27)** (color) : défaut = 0,0,0
* **`Action #6` ($28)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #6` ($29)** (color) : défaut = 0,0,0
* **`Target Color #6` ($30)** (color) : défaut = 0,0,0
* **`Action #7` ($31)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #7` ($32)** (color) : défaut = 0,0,0
* **`Target Color #7` ($33)** (color) : défaut = 0,0,0
* **`Action #8` ($34)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #8` ($35)** (color) : défaut = 0,0,0
* **`Target Color #8` ($36)** (color) : défaut = 0,0,0
* **`Action #9` ($37)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #9` ($38)** (color) : défaut = 0,0,0
* **`Target Color #9` ($39)** (color) : défaut = 0,0,0
* **`Action #10` ($40)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #10` ($41)** (color) : défaut = 0,0,0
* **`Target Color #10` ($42)** (color) : défaut = 0,0,0
* **`Action #11` ($43)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #11` ($44)** (color) : défaut = 0,0,0
* **`Target Color #11` ($45)** (color) : défaut = 0,0,0
* **`Action #12` ($46)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #12` ($47)** (color) : défaut = 0,0,0
* **`Target Color #12` ($48)** (color) : défaut = 0,0,0
* **`Action #13` ($49)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #13` ($50)** (color) : défaut = 0,0,0
* **`Target Color #13` ($51)** (color) : défaut = 0,0,0
* **`Action #14` ($52)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #14` ($53)** (color) : défaut = 0,0,0
* **`Target Color #14` ($54)** (color) : défaut = 0,0,0
* **`Action #15` ($55)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #15` ($56)** (color) : défaut = 0,0,0
* **`Target Color #15` ($57)** (color) : défaut = 0,0,0
* **`Action #16` ($58)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #16` ($59)** (color) : défaut = 0,0,0
* **`Target Color #16` ($60)** (color) : défaut = 0,0,0
* **`Action #17` ($61)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #17` ($62)** (color) : défaut = 0,0,0
* **`Target Color #17` ($63)** (color) : défaut = 0,0,0
* **`Action #18` ($64)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #18` ($65)** (color) : défaut = 0,0,0
* **`Target Color #18` ($66)** (color) : défaut = 0,0,0
* **`Action #19` ($67)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #19` ($68)** (color) : défaut = 0,0,0
* **`Target Color #19` ($69)** (color) : défaut = 0,0,0
* **`Action #20` ($70)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #20` ($71)** (color) : défaut = 0,0,0
* **`Target Color #20` ($72)** (color) : défaut = 0,0,0
* **`Action #21` ($73)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #21` ($74)** (color) : défaut = 0,0,0
* **`Target Color #21` ($75)** (color) : défaut = 0,0,0
* **`Action #22` ($76)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #22` ($77)** (color) : défaut = 0,0,0
* **`Target Color #22` ($78)** (color) : défaut = 0,0,0
* **`Action #23` ($79)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #23` ($80)** (color) : défaut = 0,0,0
* **`Target Color #23` ($81)** (color) : défaut = 0,0,0
* **`Action #24` ($82)** (choice) : choix possibles => Ignore, Lock Source, Replace Source by Target
* **`Source Color #24` ($83)** (color) : défaut = 0,0,0
* **`Target Color #24` ($84)** (color) : défaut = 0,0,0
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/06/14.
