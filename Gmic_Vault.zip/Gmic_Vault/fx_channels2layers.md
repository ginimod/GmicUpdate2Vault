---
tags: [gmic, filter]
command: fx_channels2layers
---

# Filtre G'MIC : fx_channels2layers

## Structure de la commande
```text
fx_channels2layers:
    color_space = $1
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Splits the image color channels into separate layers. 
* **`Color Space` ($1)** (choice) : choix possibles => RGB, CMY, HSV
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/07/15.
