---
tags: [gmic, filter]
command: fx_blend_edges
---

# Filtre G'MIC : fx_blend_edges

## Structure de la commande
```text
fx_blend_edges:
    opacity = $1
    smoothness = $2
    revert_layers = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Blends layers based on edge detection. 
* **`Opacity` ($1)** (float) : défaut = **1**  (0,1)
* **`Smoothness` ($2)** (float) : défaut = **0.8**  (0,5)
* **`Revert Layers` ($3)** (bool) : par défaut = Faux (0)
(Note) : Note: This filter needs two layers to work properly. Set the Input layers option to handle multiple input layers. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2013/01/21.
