---
tags: [gmic, filter]
command: fx_montage
---

# Filtre G'MIC : fx_montage

## Structure de la commande
```text
fx_montage:
    montage_type = $1
    merging_mode = $3
    centering_scale = $4
    padding_px = $5
    frame_px = $6
    angle = $11
    angle_variations = $12
    cycle_layers = $13
    revert_layer_order = $14
    output_as = $15
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Combines multiple input layers into a single montage image. 
* **`Montage Type` ($1)** (choice) : choix possibles => Auto, Custom Layout, Horizontal, Vertical, Horizontal Array, Vertical Array
* **`Merging Mode` ($2)** (choice) : choix possibles => Aligned, Scaled
* **`Centering / Scale` ($3)** (float) : défaut = **0.5**  (0,1)
* **`Padding (px)` ($4)** (int) : défaut = **0**  (0,128)
* **`Frame (px)` ($5)** (int) : défaut = **0**  (0,128)
* **`Frame Color` ($6)** (color) : défaut = 0,0,0,255
* **`Angle` ($7)** (float) : défaut = **0**  (0,360)
* **`Angle Variations` ($8)** (float) : défaut = **0**  (0,180)
* **`Cycle Layers` ($9)** (int) : défaut = **0**  (-255,255)
* **`Revert Layer Order` ($10)** (bool) : par défaut = Faux (0)
* **`Output As` ($11)** (choice) : choix possibles => Single Layer, Multiple Layers
(Note) : Instructions:
 - Don't forget to set the Input layers... option on the left if you have multiple input layers for your montage.
 - The Custom layout parameter is only active when Montage type is set to Custom layout. This is basically a string containing expressions such as:
 
     . H(a,b) or V(a,b) stand respectively for an horizontal and vertical merge of two blocks a and b. 
     . R(a), stands for a 90-deg. rotated version of a block a. Use RR(a) and RRR(a) for resp. 180-deg and 270-deg. rotations. 
     . M(a), stands for a X-mirrored version of a block a. Use MRR(a) for a Y-mirrored version of a.

 - A block a can be a layer index or a nested montage expression itself.
 - Layer indices start from 0 (top layer) and are treated periodically. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2014/12/22.
