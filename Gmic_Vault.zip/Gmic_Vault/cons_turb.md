---
tags: [gmic, filter]
command: _cons_turb
---

# Filtre G'MIC : _cons_turb

## Structure de la commande
```text
_cons_turb:
    radius = $1
    octaves = $2
    damping_per_octave = $3
    mode = $4
    amplitude = $8
    noise_type = $9
    channel_s = $10
    value_action = $11
    colour_space = $12
    channel_1 = $13
    channel_2 = $14
    channel_3 = $15
    normalise = $16
    desaturation = $17
    self_blending = $18
    self_blending_opacity = $19
    self_blending_v_original_blending = $20
    self_blend_v_original_opacity = $21
    value_action = $22
    number_1 = $23
    number_2 = $24
    equalize = $25
    negate = $26
    x_factor = $27
    y_factor = $28
    x_offset = $29
    y_offset = $30
    correlated_channels = $31
    interpolation = $32
    boundary = $33
    channel_s = $34
    blur_original = $35
    activate_butterworth_bandpass_processing = $36
    create_copy = $37
    lp_frequency_power = $38
    lp_order_cube_root = $39
    lp_resonance = $40
    hp_frequency_power = $41
    hp_order_cube_root = $42
    hp_resonance = $43
    colour_space = $44
    absolute = $45
    makeup_gain = $46
    activate_relief_processing = $47
    radius = $48
    angle = $49
    sigma = $50
    value_scale = $51
    output_color = $52
    blending_mode = $53
    blending_opacity = $54
    preview_type = $55
    preview_split_x = $56
    preview_split_y = $57
```
## Définition des variables
(Note) : Construction Material Texture filter is based off the following tutorial by theonlychad for Paint.NET software: <a href="https://forums.getpaint.net/topic/16075-concrete-texture-tutorial/">Concrete Texture Tutorial</a>.

(Note) : Turbulance Texture
* **`Radius` ($1)** (float) : défaut = **88**  (1,1024)
* **`Octaves` ($2)** (int) : défaut = **8**  (1,12)
* **`Damping per Octave` ($3)** (float) : défaut = **2.5**  (1,10)
* **`Mode` ($4)** (choice) : choix possibles => Turbulence, Turbulence 2, Fractal Noise, Fractured Clouds, Stardust, Pea Soup
* **`Color Balance` ($5)** (color) : défaut = 128,128,128
(Note) : Noise Processing
* **`Amplitude` ($6)** (float) : défaut = **20**  (0,200)
* **`Noise Type` ($7)** (choice) : choix possibles => Gaussian, Uniform, Salt and Pepper, Poisson
* **`Channel(s)` ($8)** (choice) : choix possibles => RGB [All], RGB [Red], RGB [Green], RGB [Blue], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [Hue], HSV [Saturation], HSV [Value], HSI [Intensity], HSL [Lightness], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [Luma], YIQ [Chromas]
* **`Value Action` ($9)** (choice) : choix possibles => None, Cut, Normalize
(Note) : Grayscale Processing
* **`Colour Space` ($10)** (choice) : choix possibles => RGB, SRGB
* **`Channel 1` ($11)** (float) : défaut = **1**  (0,3)
* **`Channel 2` ($12)** (float) : défaut = **1**  (0,3)
* **`Channel 3` ($13)** (float) : défaut = **1**  (0,3)
* **`Normalise` ($14)** (bool) : par défaut = Faux (0)
* **`Desaturation (%)` ($15)** (float) : défaut = **100**  (0,100)
(Note) : Self-Image Processing
* **`Self-Blending` ($16)** (choice) : choix possibles => Add, Burn, Dodge, Exclusion, Freeze, Grainextract, Grainmerge, Hardlight, Hardmix, Interpolation, Linearburn, Linearlight, Luminance, Multiply, Negation, Overlay, Pinlight, Reflect, Screen, Shapeaverage, Softburn, Softdodge, Softlight, Stamp, Vividlight
* **`Self-Blending Opacity (%)` ($17)** (float) : défaut = **100**  (0,100)
* **`Self-Blending V. Original Blending` ($18)** (choice) : choix possibles => Add, Alpha, And, Average, Blue, Burn, Darken, Difference, Divide, Dodge, Exclusion, Freeze, Grainextract, Grainmerge, Green, Hardlight, Hardmix, Hue, Interpolation, Lighten, Lightness, Linearburn, Linearlight, Luminance, Multiply, Negation, Or, Overlay, Pinlight, Red, Reflect, Saturation, Screen, Shapeaverage, Softburn, Softdodge, Softlight, Stamp, Subtract, Value, Vividlight, Xor
* **`Self-Blend V. Original Opacity (%)` ($19)** (float) : défaut = **100**  (0,100)
(Note) : Value Processing
* **`Value Action` ($20)** (choice) : choix possibles => None, Cut, Normalize
* **`Number #1` ($21)** (float) : défaut = **0**  (0,255)
* **`Number #2` ($22)** (float) : défaut = **188**  (0,255)
* **`Equalize?` ($23)** (bool) : par défaut = Faux (0)
* **`Negate?` ($24)** (bool) : par défaut = Faux (0)
(Note) : Warp by Intensity
* **`X-Factor` ($25)** (float) : défaut = **0.19**  (-6,6)
* **`Y-Factor` ($26)** (float) : défaut = **0.52**  (-6,6)
* **`X-Offset` ($27)** (float) : défaut = **128**  (0,255)
* **`Y-Offset` ($28)** (float) : défaut = **128**  (0,255)
* **`Correlated Channels` ($29)** (bool) : par défaut = Faux (0)
* **`Interpolation` ($30)** (choice) : choix possibles => Nearest Neighbor, Linear
* **`Boundary` ($31)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
* **`Channel(s)` ($32)** (choice) : choix possibles => All, RGBA [All], RGB [All], RGB [Red], RGB [Green], RGB [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [Hue], HSV [Saturation], HSV [Value], HSI [Intensity], HSL [Lightness], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [Luma], YIQ [Chromas]
(Note) : Style Processing
* **`Blur Original` ($33)** (float) : défaut = **0**  (0,16)
(Note) : Butterworth Bandpass Processing
* **`Activate Butterworth Bandpass Processing` ($34)** (bool) : par défaut = Faux (0)
* **`Create Copy?` ($35)** (bool) : par défaut = Faux (0)
* **`LP Frequency Power` ($36)** (float) : défaut = **3**  (0,16)
* **`LP Order Cube Root` ($37)** (float) : défaut = **2**  (0,4)
* **`LP Resonance` ($38)** (float) : défaut = **0**  (0,5)
* **`HP Frequency Power` ($39)** (float) : défaut = **4**  (0,16)
* **`HP Order Cube Root` ($40)** (float) : défaut = **2**  (0,4)
* **`HP Resonance` ($41)** (float) : défaut = **2**  (0,4)
* **`Colour Space` ($42)** (choice) : choix possibles => RGB, SRGB, HSV8, HSV, HSL8, HSL, HSI8, HSI, LCH8, LCH, Lab8, Lab, YCbCr, YCbCrGLIC, YCbCrJPEG, YIQ8, YIQ, YUV8, YUV, HCY, XYZ8, XYZ, CMY, CMYK, Bayer
* **`Absolute` ($43)** (bool) : par défaut = Faux (0)
* **`Makeup Gain` ($44)** (bool) : par défaut = Faux (0)
(Note) : Relief Processing
* **`Activate Relief Processing` ($45)** (bool) : par défaut = Faux (0)
* **`Radius` ($46)** (int) : défaut = **5**  (5,100)
* **`Angle` ($47)** (float) : défaut = **0**  (-180,180)
* **`Sigma` ($48)** (float) : défaut = **.5**  (.05,4)
* **`Value Scale` ($49)** (float) : défaut = **2**  (.5,10)
* **`Output Color` ($50)** (bool) : par défaut = Faux (0)
* **`Blending Mode` ($51)** (choice) : choix possibles => Grain Extract, Grain Merge
* **`Blending Opacity (%)` ($52)** (float) : défaut = **100**  (0,100)
* **`Preview Type` ($53)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($54)** (point) : position = 0,0
(Note) : Author: Reptorian. Latest Update: 2021/12/07.
