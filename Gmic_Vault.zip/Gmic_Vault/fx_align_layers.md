---
tags: [gmic, filter]
command: fx_align_layers
---

# Filtre G'MIC : fx_align_layers

## Structure de la commande
```text
fx_align_layers:
    alignment_type = $1
    smoothness = $2
    scales = $3
    revert_layers = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Automatically aligns (registers) multiple layers. 
* **`Alignment Type` ($1)** (choice) : choix possibles => Rigid, Non-Rigid
* **`Smoothness` ($2)** (float) : défaut = **0.7**  (0,1)
* **`Scales` ($3)** (choice) : choix possibles => Auto, 1, 2, 3, 4, 5, 6, 7, 8
* **`Revert Layers` ($4)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2020/01/11.
