---
tags: [gmic, filter]
command: fx_corvo_painting_5
---

# Filtre G'MIC : fx_corvo_painting_5

## Structure de la commande
```text
fx_corvo_painting_5:
    amplitude = $1
    smoothness = $2
    minimal_area = $3
    alpha_polygonize = $4
    texture = $5
    plasma = $6
    amplitude = $7
    gradient_smoothness = $8
    tensor_smoothness = $9
    alpha_filter = $10
```
## Définition des variables
(Note) : Polygonize settings
* **`Amplitude` ($1)** (int) : défaut = **35**  (0,2000)
* **`Smoothness` ($2)** (float) : défaut = **10**  (0,100)
* **`Minimal Area` ($3)** (float) : défaut = **10**  (0,100)
* **`Alpha Polygonize` ($4)** (float) : défaut = **0.5**  (0,1)
* **`Texture` ($5)** (float) : défaut = **50**  (0,100)
* **`Plasma` ($6)** (float) : défaut = **0.3**  (0,1)
(Note) : Smooth settings
* **`Amplitude` ($7)** (float) : défaut = **50**  (0,1000)
* **`Gradient Smoothness` ($8)** (float) : défaut = **2**  (0,10)
* **`Tensor Smoothness` ($9)** (float) : défaut = **5**  (0,10)
* **`Alpha Filter` ($10)** (float) : défaut = **1**  (0,1)
