---
tags: [gmic, filter]
command: afre_denoisesmooth
---

# Filtre G'MIC : afre_denoisesmooth

## Structure de la commande
```text
afre_denoisesmooth:
    radius = $1
    amount = $2
```
## Définition des variables
(Note) : <strong>Denoise noisy image, or smooth low noise image.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2020 Oct4.</strong>

 Filter is slow when the radius  and amount  are high. Start small and increase as appropriate.


* **`Radius` ($1)** (int) : défaut = **3**  (1,10)
* **`Amount` ($2)** (int) : défaut = **10**  (1,1000)
(Note) : 

<strong>Note</strong>

G'MIC's preview is inaccurate. Apply the filter and review the results in your host editor.
