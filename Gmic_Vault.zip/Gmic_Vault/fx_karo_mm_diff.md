---
tags: [gmic, filter]
command: fx_karo_mm_diff
---

# Filtre G'MIC : fx_karo_mm_diff

## Structure de la commande
```text
fx_karo_mm_diff:
    size = $1
    size2 = $2
    operation = $3
    shape = $4
    channel_s = $5
    scale = $6
    preview_type = $7
    preview_split_x = $8
    preview_split_y = $9
```
## Définition des variables
* **`Size` ($1)** (int) : défaut = **5**  (1,25)
* **`Size2` ($2)** (int) : défaut = **7**  (1,25)
* **`Operation` ($3)** (choice) : choix possibles => Erosion, Dilation, Open, Close
* **`Shape` ($4)** (choice) : choix possibles => Square, Octagon, Circle
* **`Channel(s)` ($5)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CYMK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
* **`Scale` ($6)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($7)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($8)** (point) : position = 0,0
(Note) : Arithmetical difference of a morphological operation of size and size2.
(Note) : Author : KaRo. Latest update : 2012/10/26.
