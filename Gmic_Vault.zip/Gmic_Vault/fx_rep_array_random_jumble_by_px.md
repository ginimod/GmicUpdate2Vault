---
tags: [gmic, filter]
command: fx_rep_array_random_jumble_by_px
---

# Filtre G'MIC : fx_rep_array_random_jumble_by_px

## Structure de la commande
```text
fx_rep_array_random_jumble_by_px:
    tile_width_px = $1
    tile_height = $2
    old_tile_width_px = $3
    old_tile_height = $4
    link_dimensions = $5
    enforce_factors = $6
    stored_number_of_width_s_factors = $14
    stored_number_of_height_s_factors = $15
    stored_number_of_width_s_and_height_s_factors = $16
```
## Définition des variables
(Note) : Main
* **`Tile Width(px)` ($1)** (int) : défaut = **128**  (1,2048)
* **`Tile Height` ($2)** (int) : défaut = **128**  (1,2048)
* **`Old Tile Width(px)` ($3)** (int) : défaut = **128**  (1,2048)
* **`Old Tile Height` ($4)** (int) : défaut = **128**  (1,2048)
* **`Link Dimensions` ($5)** (bool) : par défaut = Faux (0)
* **`Enforce Factors` ($6)** (bool) : par défaut = Faux (0)
(Note) : Image Factors
* **`Stored Number of Width(s) Factors` ($7)** (int) : défaut = **1**  (1,16777216)
* **`Stored Number of Height(s) Factors` ($8)** (int) : défaut = **1**  (1,16777216)
* **`Stored Number of Width(s) and Height(s) Factors` ($9)** (int) : défaut = **1**  (1,16777216)
(Note) : Author: Reptorian. Latest Update: 2023/07/06.
