---
tags: [gmic, filter]
command: cl_reliefFrame
---

# Filtre G'MIC : cl_reliefFrame

## Structure de la commande
```text
cl_reliefFrame:
    type = $1
    size = $2
    relief_width = $3
    relief_amount = $4
    kaleidoscope_effect = $5
    frame_blur = $6
    frame_hue_change = $7
    frame_saturation_change = $8
    frame_luminosity_change = $9
    set_uniform_frame_color = $10
    graininess_type = $14
    graininess_amount = $15
    graininess_on = $16
```
## Définition des variables
(Note) : Frame Limit:
* **`Type` ($1)** (choice) : choix possibles => Outset, Inset, Groove, Ridge
* **`Size` ($2)** (float) : défaut = **10**  (6,40)
* **`Relief Width` ($3)** (float) : défaut = **1.5**  (0,10)
* **`Relief Amount` ($4)** (float) : défaut = **75**  (0,127)
(Note) : Frame Area:
* **`Kaleidoscope Effect` ($5)** (bool) : par défaut = Faux (0)
* **`Frame Blur` ($6)** (float) : défaut = **60**  (5,80)
* **`Frame Hue Change` ($7)** (float) : défaut = **0**  (-180,180)
* **`Frame Saturation Change` ($8)** (float) : défaut = **0**  (-1,1)
* **`Frame Luminosity Change` ($9)** (float) : défaut = **0**  (-0.5,0.5)
(Note) : Uniform Frame Color:
(Note) : This overrides "Frame Area" section.
* **`Set Uniform Frame Color` ($10)** (bool) : par défaut = Faux (0)
* **`Frame Color` ($11)** (color) : défaut = 192,192,192
(Note) : Graininess:
* **`Graininess Type` ($12)** (choice) : choix possibles => Gaussian, Uniform, Poisson
* **`Graininess Amount` ($13)** (float) : défaut = **0**  (0,80)
* **`Graininess On` ($14)** (choice) : choix possibles => Frame, Picture, Both
(Note) : Author: Claude Lion. Latest Update: 2022/08/26.
(Note) : It uses filters of David Tschumperlé and an algorithm of Reptorian.
