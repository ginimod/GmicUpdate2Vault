---
tags: [gmic, filter]
command: afre_portraitmontage
---

# Filtre G'MIC : afre_portraitmontage

## Structure de la commande
```text
afre_portraitmontage:
    size = $1
    spacing = $2
    matte_shape = $3
```
## Définition des variables
(Note) : <strong>Generate portrait montage with resizing.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2020-2021 Apr18.</strong>

 - Set <strong>Input layers</strong> to <strong>All</strong>.
 - Centre subjects for best results.


* **`Size` ($1)** (choice) : choix possibles => Small, Large
* **`Spacing` ($2)** (int) : défaut = **1**  (1,20)
* **`Matte Shape` ($3)** (choice) : choix possibles => None, Circle, Polygon, Star
* **`Matte Colour` ($4)** (color) : défaut = 230,255,230
