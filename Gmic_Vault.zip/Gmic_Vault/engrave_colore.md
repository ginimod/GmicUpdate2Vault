---
tags: [gmic, filter]
command: Engrave_colore
---

# Filtre G'MIC : Engrave_colore

## Structure de la commande
```text
Engrave_colore:
    exemples_examples = $1
    radius = $2
    densite_a = $3
    edges = $4
    coherence = $5
    threshold = $6
    minimal_area = $7
    repetition = $8
    anti_aliasing = $9
    gravure_engraving = $10
```
## Définition des variables
(Note) : Modification du Filtre de Lyle Kroll et David Tschumperlé
(Note) : pour obtenir des gravures colorées - samj 20150321
* **`Exemples / Examples` ($1)** (choice) : choix possibles => Non / None, A, B, C, D ***, E, F, G
(Note) : Gravure / Engraving
* **`Radius` ($2)** (float) : défaut = **0.5**  (0,2)
* **`Densité A` ($3)** (float) : défaut = **4**  (0,10)
* **`Edges` ($4)** (float) : défaut = **0**  (0,10)
* **`Cohérence` ($5)** (float) : défaut = **8**  (0,40)
* **`Threshold (%)` ($6)** (float) : défaut = **40**  (0,100)
* **`Minimal Area` ($7)** (int) : défaut = **0**  (-256,256)
* **`Répétition` ($8)** (int) : défaut = **25**  (0,50)
(Note) : Anti-aliasing
* **`Anti-Aliasing` ($9)** (choice) : choix possibles => Disabled, A, B, C
(Note) : Couleurs / Colors
* **`Gravure / Engraving` ($10)** (choice) : choix possibles => Avant Plan, Image Avec Contours Des Couleurs 8, Image Avec Contours Des Couleurs 16, Image Avec Contours Des Couleurs 32, Image Avec Contours Des Couleurs 64, Image Sans Contours Des Couleurs 8, Image Sans Contours Des Couleurs 16, Image Sans Contours Des Couleurs 32, Image Sans Contours Des Couleurs 64, 3 Calques - Image Sans Contours Des Couleurs 8, 3 Calques - Image Sans Contours Des Couleurs 16, 3 Calques - Image Sans Contours Des Couleurs 32, 3 Calques - Image Sans Contours Des Couleurs 64
* **`Avant Plan` ($11)** (color) : défaut = 0,0,0
* **`Fond / Background Color` ($12)** (color) : défaut = 255,255,255
(Note) : Authors: Lyle Kroll and David Tschumperlé .      Latest update: 2020/10/24.
