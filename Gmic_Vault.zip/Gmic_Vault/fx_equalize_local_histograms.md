---
tags: [gmic, filter]
command: fx_equalize_local_histograms
---

# Filtre G'MIC : fx_equalize_local_histograms

## Structure de la commande
```text
fx_equalize_local_histograms:
    strength = $1
    mode = $2
    radius = $3
    sigma = $4
    regularization = $5
    reduce_halos = $6
    channel_s = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Enhances contrast locally using histogram equalization. 
* **`Strength (%)` ($1)** (float) : défaut = **75**  (0,100)
* **`Mode` ($2)** (choice) : choix possibles => Raw, Hard, Soft
* **`Radius` ($3)** (int) : défaut = **4**  (1,16)
* **`Sigma` ($4)** (float) : défaut = **100**  (0,256)
* **`Regularization` ($5)** (float) : défaut = **8**  (0,32)
* **`Reduce Halos` ($6)** (bool) : par défaut = Faux (0)
* **`Channel(s)` ($7)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2018/01/31.
