---
tags: [gmic, filter]
command: fx_ncee
---

# Filtre G'MIC : fx_ncee

## Structure de la commande
```text
fx_ncee:
    colour_space = $1
    angle = $2
    offset = $3
    contrast_factor = $4
    wraparound_mode = $5
    interpolation = $6
    alpha_mode = $7
    blending_mode = $8
    9_blending_opacity = $9
    preview_type = $10
    preview_split_x = $11
    preview_split_y = $12
```
## Définition des variables
(Note) : Based off PS Embossing filtering. The way it works is that you duplicate once and then shift with wrap-around using original image data using an angle and offset. Then finally, you invert one of the layer, and average those values. In this filter, you have several options when it comes to alpha and how the image wrap-around. Also, CMYK mode may be fixed later as I'm trying to avoid the problem with Alpha mode and CMYK mode.
* **`Colour Space` ($1)** (choice) : choix possibles => RGB8, RYB8, CMY8, CMYK8, HSI8, HSL8, HSV8, LAB8, LCH8, YIQ8, YUV8, XYZ8, YES8, Kodak 1-8, Ohta8
* **`Angle` ($2)** (float) : défaut = **0**  (0,360)
* **`Offset` ($3)** (float) : défaut = **1**  (.5,256)
* **`Contrast Factor [%]` ($4)** (float) : défaut = **100**  (0,500)
* **`Wraparound Mode` ($5)** (choice) : choix possibles => Dirichlet, Neumann, Periodic, Mirror
* **`Interpolation` ($6)** (bool) : par défaut = Faux (0)
(Note) : Alpha Processing
* **`Alpha Mode` ($7)** (choice) : choix possibles => Preserve Original Alpha, Multiply Alphas
(Note) : Blending Processing

If you're looking for normal blending mode, you do not need to touch this and if you did, set mode to alpha and opacity to 100.
* **`Blending Mode` ($8)** (choice) : choix possibles => Add, Alpha, And, Average, Blue, Burn, Darken, Difference, Divide, Dodge, Exclusion, Freeze, Grainextract, Grainmerge, Green, Hardlight, Hardmix, Hue, Interpolation, Lighten, Lightness, Linearburn, Linearlight, Luminance, Multiply, Negation, Or, Overlay, Pinlight, Red, Reflect, Saturation, Screen, Shapeaverage, Softburn, Softdodge, Softlight, Stamp, Subtract, Value, Vividlight, Xor
* **`9. Blending Opacity` ($9)** (float) : défaut = **100**  (0,100)
* **`Preview Type` ($10)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($11)** (point) : position = 0,0
(Note) : Author: Reptorian Latest Update: 2019/4/25.
