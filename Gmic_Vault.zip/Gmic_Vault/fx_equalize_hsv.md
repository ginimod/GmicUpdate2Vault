---
tags: [gmic, filter]
command: fx_equalize_hsv
---

# Filtre G'MIC : fx_equalize_hsv

## Structure de la commande
```text
fx_equalize_hsv:
    color_space = $1
    opacity = $2
    value_blending = $3
    color_blending = $4
    preview_mapping = $5
    hue_offset = $6
    saturation_offset = $7
    value_offset = $8
    hue_offset = $9
    saturation_offset = $10
    value_offset = $11
    hue_offset = $12
    saturation_offset = $13
    value_offset = $14
    hue_offset = $15
    saturation_offset = $16
    value_offset = $17
    hue_offset = $18
    saturation_offset = $19
    value_offset = $20
    hue_offset = $21
    saturation_offset = $22
    value_offset = $23
    hue_offset = $24
    saturation_offset = $25
    value_offset = $26
    hue_offset = $27
    saturation_offset = $28
    value_offset = $29
    hue_offset = $30
    saturation_offset = $31
    value_offset = $32
    preview_type = $33
    preview_split_x = $34
    preview_split_y = $35
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Equalizes histogram in HSI, HSL, or HSV color spaces. 
* **`Color Space` ($1)** (choice) : choix possibles => HSI, HSL, HSV
* **`Opacity (%)` ($2)** (float) : défaut = **100**  (0,100)
* **`Value Blending` ($3)** (float) : défaut = **0**  (0,64)
* **`Color Blending` ($4)** (float) : défaut = **0**  (0,64)
* **`Preview Mapping` ($5)** (choice) : choix possibles => None, Grey, Color
(Note) : Black:
* **`Hue Offset` ($6)** (float) : défaut = **0**  (-180,180)
* **`Saturation Offset` ($7)** (float) : défaut = **0**  (-1,1)
* **`Value Offset` ($8)** (float) : défaut = **0**  (-1,1)
(Note) : Near black:
* **`Hue Offset` ($9)** (float) : défaut = **0**  (-180,180)
* **`Saturation Offset` ($10)** (float) : défaut = **0**  (-1,1)
* **`Value Offset` ($11)** (float) : défaut = **0**  (-1,1)
(Note) : Dark grey:
* **`Hue Offset` ($12)** (float) : défaut = **0**  (-180,180)
* **`Saturation Offset` ($13)** (float) : défaut = **0**  (-1,1)
* **`Value Offset` ($14)** (float) : défaut = **0**  (-1,1)
(Note) : Mi-dark grey:
* **`Hue Offset` ($15)** (float) : défaut = **0**  (-180,180)
* **`Saturation Offset` ($16)** (float) : défaut = **0**  (-1,1)
* **`Value Offset` ($17)** (float) : défaut = **0**  (-1,1)
(Note) : Middle grey:
* **`Hue Offset` ($18)** (float) : défaut = **0**  (-180,180)
* **`Saturation Offset` ($19)** (float) : défaut = **0**  (-1,1)
* **`Value Offset` ($20)** (float) : défaut = **0**  (-1,1)
(Note) : Mid-light grey:
* **`Hue Offset` ($21)** (float) : défaut = **0**  (-180,180)
* **`Saturation Offset` ($22)** (float) : défaut = **0**  (-1,1)
* **`Value Offset` ($23)** (float) : défaut = **0**  (-1,1)
(Note) : Light grey:
* **`Hue Offset` ($24)** (float) : défaut = **0**  (-180,180)
* **`Saturation Offset` ($25)** (float) : défaut = **0**  (-1,1)
* **`Value Offset` ($26)** (float) : défaut = **0**  (-1,1)
(Note) : Highlights:
* **`Hue Offset` ($27)** (float) : défaut = **0**  (-180,180)
* **`Saturation Offset` ($28)** (float) : défaut = **0**  (-1,1)
* **`Value Offset` ($29)** (float) : défaut = **0**  (-1,1)
(Note) : White:
* **`Hue Offset` ($30)** (float) : défaut = **0**  (-180,180)
* **`Saturation Offset` ($31)** (float) : défaut = **0**  (-1,1)
* **`Value Offset` ($32)** (float) : défaut = **0**  (-1,1)
* **`Preview Type` ($33)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($34)** (point) : position = 0,0
(Note) : Authors: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a> and David Revoy.       Latest Update: 2018/01/19.
