---
tags: [gmic, filter]
command: fx_crease
---

# Filtre G'MIC : fx_crease

## Structure de la commande
```text
fx_crease:
    amplitude = $1
    frequency = $2
    boundary = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Deforms image with creases. 
* **`Amplitude` ($1)** (float) : défaut = **30**  (0,300)
* **`Frequency (%)` ($2)** (float) : défaut = **10**  (0,100)
* **`Boundary` ($3)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2018/01/22.
