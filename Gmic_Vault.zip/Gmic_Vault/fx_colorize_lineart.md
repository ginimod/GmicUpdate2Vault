---
tags: [gmic, filter]
command: fx_colorize_lineart
---

# Filtre G'MIC : fx_colorize_lineart

## Structure de la commande
```text
fx_colorize_lineart:
    input_layers = $1
    output_layers = $2
    extrapolate_colors_as = $3
    smoothness = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Colorizes line art by propagating color from user-defined spots. 
(Note) : Layers ordering:
* **`Input Layers` ($1)** (choice) : choix possibles => Color Spots + Lineart, Lineart + Color Spots, Color Spots + Extrapolated Colors + Lineart, Lineart + Color Spots + Extrapolated Colors
* **`Output Layers` ($2)** (choice) : choix possibles => Single (Merged), Extrapolated Colors + Lineart, Lineart + Extrapolated Colors, Color Spots + Extrapolated Colors + Lineart, Lineart + Color Spots + Extrapolated Colors
* **`Extrapolate Colors As` ($3)** (choice) : choix possibles => One Layer, Two Layers, Three Layers, Four Layers, Five Layers, Six Layers, Seven Layers, Eight Layers, Nine Layers, Ten Layers, One Layer per Single Color, One Layer per Single Region
* **`Smoothness` ($4)** (float) : défaut = **0.05**  (0,1)
(Note) : Note: You probably need to select All for the Input layers option on the left.
 Color Spots = your layer with color indications.
 Lineart = your layer with line-art (B&W or transparent).
 Extrapolated Colors = the G'MIC generated layer with flat colors.

 Warnings: 
  - Do not rely too much on the preview, it is probably not accurate! 
  - Enable option Extrapolate color as one layer per single color/region only if you have a lot of available memory ! 
(Note) : Authors: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>, Timothée Giet and David Revoy.       Latest Update: 2013/06/19.
