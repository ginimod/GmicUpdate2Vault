---
tags: [gmic, filter]
command: fx_random3d
---

# Filtre G'MIC : fx_random3d

## Structure de la commande
```text
fx_random3d:
    type = $1
    density = $2
    size = $3
    z_range = $4
    fov = $5
    x_light = $6
    y_light = $7
    z_light = $8
    specular_lightness = $9
    specular_shininess = $10
    rendering = $11
    opacity = $12
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates random 3D geometric shapes over the image. 
* **`Type` ($1)** (choice) : choix possibles => Cube, Cone, Cylinder, Sphere, Torus
* **`Density` ($2)** (int) : défaut = **50**  (1,300)
* **`Size` ($3)** (float) : défaut = **3**  (1,20)
* **`Z-Range` ($4)** (float) : défaut = **100**  (0,300)
* **`FOV` ($5)** (float) : défaut = **45**  (1,90)
* **`X-Light` ($6)** (float) : défaut = **0**  (-100,100)
* **`Y-Light` ($7)** (float) : défaut = **0**  (-100,100)
* **`Z-Light` ($8)** (float) : défaut = **-100**  (-100,0)
* **`Specular Lightness` ($9)** (float) : défaut = **0.5**  (0,1)
* **`Specular Shininess` ($10)** (float) : défaut = **0.7**  (0,3)
* **`Rendering` ($11)** (choice) : choix possibles => Dots, Wireframe, Flat, Flat-Shaded, Gouraud, Phong
* **`Opacity` ($12)** (float) : défaut = **1**  (0,1)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
