---
tags: [gmic, filter]
command: fx_image_sample
---

# Filtre G'MIC : fx_image_sample

## Structure de la commande
```text
fx_image_sample:
    input = $1
    width = $2
    height = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Loads a predefined sample image. 
* **`Input` ($1)** (choice) : choix possibles => Random, Apples, Balloons, Barbara, Boats, Bottles, Butterfly, Cameraman, Car, Cat, Chick, Cliff, Colorful, David, Dog, Duck, Eagle, Elephant, Earth, Flower, Fruits, Gmicky (Deevad), Gmicky (Mahvin), Gmicky & Wilber, Greece, Gummy, House, Inside, Landscape, Leaf, Lena, Leno, Lion, Mandrill, Mona Lisa, Monkey, Parrots, Pencils, Peppers, Portrait0, Portrait1, Portrait2, Portrait3, Portrait4, Portrait5, Portrait6, Portrait7, Portrait8, Portrait9, Roddy, Rooster, Rose, Square, Swan, Teddy, Tiger, Tulips, Wall, Waterfall, Zelda
(Note) : Choosing 0 for parameters Width or Height means Automatic. 
* **`Width` ($2)** (int) : défaut = **0**  (0,1024)
* **`Height` ($3)** (int) : défaut = **0**  (0,1024)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2017/01/16.
