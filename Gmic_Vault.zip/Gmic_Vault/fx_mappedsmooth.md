---
tags: [gmic, filter]
command: fx_MappedSmooth
---

# Filtre G'MIC : fx_MappedSmooth

## Structure de la commande
```text
fx_MappedSmooth:
    map_type = $1
    angle_shift = $2
    zero_point_offset = $3
    amplitude = $4
    vector_length_multipler = $5
    show_quiver = $6
```
## Définition des variables
(Note) : Two layers required if automap is not used. Set input to active and below. Filter Smooths image with a vector field map. Map is created from R and G channels so that R128,G128 becomes [0 0]. Experiment with solid 128,128,0 color layer and add hues of red and green. Angle shift rotates the vector field and Zero point offset moves the default 0 0 point. This is somewhat a development version, sample art is still missing.
* **`Map Type` ($1)** (choice) : choix possibles => Automap, Layer Map
* **`Angle Shift` ($2)** (float) : défaut = **0**  (-180,180)
* **`Zero Point Offset` ($3)** (float) : défaut = **0**  (-128,128)
* **`Amplitude` ($4)** (float) : défaut = **300**  (10,10000)
* **`Vector Length Multipler` ($5)** (float) : défaut = **1**  (0.1,5)
(Note) : Optional viewing of vector field
* **`Show Quiver` ($6)** (bool) : par défaut = Faux (0)
(Note) : Author : Arto Huotari.      Latest update : 2012/02/25.
