---
tags: [gmic, filter]
command: fx_local_orientation
---

# Filtre G'MIC : fx_local_orientation

## Structure de la commande
```text
fx_local_orientation:
    smoothness = $1
    min_threshold = $2
    max_threshold = $3
    negative_colors = $4
    channel_s = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Visualizes the local orientation of image structures. 
* **`Smoothness` ($1)** (float) : défaut = **0**  (0,5)
* **`Min Threshold` ($2)** (float) : défaut = **0**  (0,100)
* **`Max Threshold` ($3)** (float) : défaut = **100**  (0,100)
* **`Negative Colors` ($4)** (bool) : par défaut = Faux (0)
* **`Channel(s)` ($5)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
