---
tags: [gmic, filter]
command: exfusion3
---

# Filtre G'MIC : exfusion3

## Structure de la commande
```text
exfusion3:
    contrast_bias = $1
    saturation_bias = $2
    exposure_sigma = $3
    exposure_bias = $4
    maxlevels_adjust = $5
    base_level_median_stack = $6
```
## Définition des variables
* **`Contrast Bias` ($1)** (float) : défaut = **0.3**  (0,1)
* **`Saturation Bias` ($2)** (float) : défaut = **0.3**  (0,1)
* **`Exposure Sigma` ($3)** (float) : défaut = **0.2**  (0,1)
* **`Exposure Bias` ($4)** (float) : défaut = **0.3**  (0,1)
* **`Maxlevels Adjust` ($5)** (int) : défaut = **-1**  (-5,0)
* **`Base Level Median Stack` ($6)** (bool) : par défaut = Faux (0)
(Note) : Pyramid levels are calculated automatically, but you can reduce the number of pyramid levels to save memory. You can choose how the base level is fused, by using weight maps like normal, or by using a median of the image stack
