---
tags: [gmic, filter]
command: fx_karo_pink
---

# Filtre G'MIC : fx_karo_pink

## Structure de la commande
```text
fx_karo_pink:
    pink_operator = $1
    connectivity_dir = $2
    smoothness = $3
    height_rep = $4
    channel_s = $5
    preview_type = $6
    preview_split_x = $7
    preview_split_y = $8
```
## Définition des variables
* **`Pink Operator` ($1)** (choice) : choix possibles => Wshedtopo, Wshedtopo Inv, Minima, Maxima, Heightminima, Heightmaxima, Grayskel, Htkern, Htkernu, Lvkern, Lvkernu, Saliency, Asf, Asflin, Asfr, Asft, Asftmed, Asftndg, Dilatballnum, Erosballnum, Lintophat
* **`Connectivity / Dir` ($2)** (choice) : choix possibles => Four/x, Eight/y
* **`Smoothness` ($3)** (float) : défaut = **0**  (0,5)
* **`Height/Rep` ($4)** (int) : défaut = **5**  (0,25)
* **`Channel(s)` ($5)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CYMK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
* **`Preview Type` ($6)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($7)** (point) : position = 0,0
