---
tags: [gmic, filter]
command: fx_for_littbarski
---

# Filtre G'MIC : fx_for_littbarski

## Structure de la commande
```text
fx_for_littbarski:
    dithering = $2
    output_mode = $3
```
## Définition des variables
* **`Dithering (%)` ($1)** (float) : défaut = **50**  (0,100)
* **`Output Mode` ($2)** (choice) : choix possibles => Color Indices, Colors
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>       Latest Update: 2025/09/04.
