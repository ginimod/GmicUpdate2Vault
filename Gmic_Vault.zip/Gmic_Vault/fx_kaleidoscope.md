---
tags: [gmic, filter]
command: fx_kaleidoscope
---

# Filtre G'MIC : fx_kaleidoscope

## Structure de la commande
```text
fx_kaleidoscope:
    center_x = $1
    center_y = $2
    x_offset = $3
    y_offset = $4
    radius_cut = $5
    angle_cut = $6
    boundary = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Creates a kaleidoscope effect using polar mirroring. 
* **`Center (%)` ($1)** (point) : position = 0,0
* **`X-Offset (%)` ($2)** (float) : défaut = **0**  (0,100)
* **`Y-Offset (%)` ($3)** (float) : défaut = **0**  (0,100)
* **`Radius Cut` ($4)** (float) : défaut = **100**  (0,100)
* **`Angle Cut` ($5)** (float) : défaut = **10**  (0,100)
* **`Boundary` ($6)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
