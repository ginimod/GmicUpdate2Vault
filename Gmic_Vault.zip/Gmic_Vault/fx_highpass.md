---
tags: [gmic, filter]
command: fx_highpass
---

# Filtre G'MIC : fx_highpass

## Structure de la commande
```text
fx_highpass:
    radius = $1
    contrast = $2
    inverse = $3
    greyscale = $4
    preview_type = $5
```
## Définition des variables
* **`Radius` ($1)** (float) : défaut = **5**  (0,100)
* **`Contrast` ($2)** (float) : défaut = **2**  (0,7)
* **`Inverse` ($3)** (bool) : par défaut = Faux (0)
* **`Greyscale` ($4)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($5)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author : Tom Keil.      Latest update: 2011/05/01.
