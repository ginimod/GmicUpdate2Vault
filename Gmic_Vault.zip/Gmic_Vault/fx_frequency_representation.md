---
tags: [gmic, filter]
command: fx_frequency_representation
---

# Filtre G'MIC : fx_frequency_representation

## Structure de la commande
```text
fx_frequency_representation:
    iterations = $1
    clusters = $2
    split_channels = $3
    blur = $4
    colour_space = $5
```
## Définition des variables
(Note) : Changes values based on relative frequencies of those values in a histogram of image intensity.
* **`Iterations` ($1)** (int) : défaut = **3**  (1,20)
* **`Clusters` ($2)** (int) : défaut = **256**  (2,1024)
* **`Split Channels` ($3)** (bool) : par défaut = Faux (0)
* **`Blur` ($4)** (float) : défaut = **40**  (0,100)
* **`Colour Space` ($5)** (choice) : choix possibles => RGB, SRGB, CMY, RYB, Ohta8, Ohta, YES8, YES, Kodak 1-8, Kodak1, Lab8, Lab, Oklab, LUV, Jzazbz, YIQ8, YIQ, YUV8, YUV, YCbCr, YCbCrGLIC, YCbCrJPEG, YDbDr, XYZ8, XYZ, HSV8, HSV, HSL8, HSL, HSI8, HSI, LCH8, LCH, JzCzHz, HCY
