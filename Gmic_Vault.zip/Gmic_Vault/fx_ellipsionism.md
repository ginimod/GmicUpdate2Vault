---
tags: [gmic, filter]
command: fx_ellipsionism
---

# Filtre G'MIC : fx_ellipsionism

## Structure de la commande
```text
fx_ellipsionism:
    primary_radius = $1
    secondary_radius = $2
    smoothness = $3
    opacity = $4
    outline = $5
    density = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Reconstructs the image using a collection of ellipses. 
* **`Primary Radius` ($1)** (float) : défaut = **20**  (1,100)
* **`Secondary Radius` ($2)** (float) : défaut = **10**  (1,100)
* **`Smoothness` ($3)** (float) : défaut = **0.5**  (0,10)
* **`Opacity` ($4)** (float) : défaut = **0.7**  (0,1)
* **`Outline` ($5)** (float) : défaut = **3**  (1,3)
* **`Density` ($6)** (float) : défaut = **0.5**  (0.1,2)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
