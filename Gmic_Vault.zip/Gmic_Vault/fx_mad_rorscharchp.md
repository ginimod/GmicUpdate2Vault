---
tags: [gmic, filter]
command: fx_mad_rorscharchp
---

# Filtre G'MIC : fx_mad_rorscharchp

## Structure de la commande
```text
fx_mad_rorscharchp:
    scale = $1
    mixer = $2
    line = $3
    smoothness = $4
    sharpen = $5
    remix = $6
    photocomix_preset = $7
    activate_mirror = $8
    expanding_mirrors = $9
```
## Définition des variables
* **`Scale` ($1)** (float) : défaut = **3**  (0,15)
* **`Mixer` ($2)** (choice) : choix possibles => Average, Grain Extract, Vivid Edges, Difference, Exclusion, Negation
* **`Line` ($3)** (float) : défaut = **50**  (0,100)
* **`Smoothness` ($4)** (float) : défaut = **1**  (0,5)
* **`Sharpen` ($5)** (float) : défaut = **300**  (0,1000)
* **`Remix` ($6)** (choice) : choix possibles => Vivid Edges, Average, Difference, Negation, Dark Edges
* **`PhotoComix Preset` ($7)** (choice) : choix possibles => Neat Merge, Lighty Smooth, Dream, Moody, Soft, Naif, Dark Boost, Whitening, None- Skip
* **`Activate Mirror` ($8)** (choice) : choix possibles => No-Skip, XY Mirror, 2XY Mirror
(Note) : WARNING,'Expanding Mirrors' multiply image size of x4 or if '2XY Mirrors' x9
* **`Expanding Mirrors` ($9)** (bool) : par défaut = Faux (0)
(Note) : Author: PhotoComix.      Latest update : 2011/13/11.
