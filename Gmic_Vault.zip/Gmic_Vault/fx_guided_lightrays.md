---
tags: [gmic, filter]
command: fx_guided_lightrays
---

# Filtre G'MIC : fx_guided_lightrays

## Structure de la commande
```text
fx_guided_lightrays:
    amplitude = $1
    ray_length = $2
    mode = $3
    density = $4
    smoothness = $5
    threshold = $6
    light_position_x = $7
    light_position_y = $8
    blend_mode = $12
    opacity = $13
    preview_light_shape = $14
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates light rays emanating from a user-defined point. 
* **`Amplitude (%)` ($1)** (float) : défaut = **10**  (0,100)
* **`Ray Length` ($2)** (float) : défaut = **2**  (0,2)
* **`Mode` ($3)** (choice) : choix possibles => Boundary, Dense
* **`Density (%)` ($4)** (float) : défaut = **80**  (0,100)
* **`Smoothness (%)` ($5)** (float) : défaut = **0.1**  (0,5)
* **`Threshold (%)` ($6)** (float) : défaut = **50**  (0,100)
* **`Light Position` ($7)** (point) : position = 0,0
* **`Light Color` ($8)** (color) : défaut = 255,255,255
* **`Blend Mode` ($9)** (choice) : choix possibles => Add, Alpha, Grain Merge, Hard Light, Lighten, Lightness, Luminance, Overlay, Soft Light, Value
* **`Opacity (%)` ($10)** (float) : défaut = **100**  (0,100)
* **`Preview Light Shape` ($11)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2021/04/06.
