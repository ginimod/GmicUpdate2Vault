---
tags: [gmic, filter]
command: fx_bokeh
---

# Filtre G'MIC : fx_bokeh

## Structure de la commande
```text
fx_bokeh:
    number_of_scales = $1
    shape = $2
    random_seed = $3
    density = $4
    radius = $5
    outline = $6
    inner_shade = $7
    smoothness = $8
    color_dispersion = $13
    density = $14
    radius = $15
    outline = $16
    inner_shade = $17
    smoothness = $18
    color_dispersion = $23
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates the aesthetic blur quality of an out-of-focus lens. 
* **`Number of Scales` ($1)** (int) : défaut = **3**  (1,10)
* **`Shape` ($2)** (choice) : choix possibles => Triangle, Square, Diamond, Pentagon, Hexagon, Octagon, Decagon, Star, Circular
* **`Random Seed` ($3)** (int) : défaut = **0**  (0,65535)
(Note) : Starting parameters:
* **`Density` ($4)** (int) : défaut = **30**  (1,256)
* **`Radius (%)` ($5)** (float) : défaut = **8**  (0,50)
* **`Outline (%)` ($6)** (float) : défaut = **4**  (0,100)
* **`Inner Shade` ($7)** (float) : défaut = **0.3**  (0,1)
* **`Smoothness` ($8)** (float) : défaut = **0.2**  (0,8)
* **`Color` ($9)** (color) : défaut = 210,210,80,160
* **`Color Dispersion` ($10)** (float) : défaut = **0.7**  (0,1)
(Note) : Ending parameters:
* **`Density` ($11)** (int) : défaut = **30**  (1,256)
* **`Radius (%)` ($12)** (float) : défaut = **20**  (0,50)
* **`Outline (%)` ($13)** (float) : défaut = **20**  (0,100)
* **`Inner Shade` ($14)** (float) : défaut = **1**  (0,1)
* **`Smoothness` ($15)** (float) : défaut = **2**  (0,8)
* **`Color` ($16)** (color) : défaut = 170,130,20,110
* **`Color Dispersion` ($17)** (float) : défaut = **0.15**  (0,1)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/07/02.
