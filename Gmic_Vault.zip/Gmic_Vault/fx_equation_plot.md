---
tags: [gmic, filter]
command: fx_equation_plot
---

# Filtre G'MIC : fx_equation_plot

## Structure de la commande
```text
fx_equation_plot:
    x_min = $2
    x_max = $3
    resolution = $4
    channels = $5
    plot_type = $6
    vertex_type = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Plots a mathematical function y=f(x). 
* **`X-Min` ($1)** (float) : défaut = **-10**  (-100,100)
* **`X-Max` ($2)** (float) : défaut = **10**  (-100,100)
* **`Resolution` ($3)** (int) : défaut = **100**  (2,1024)
* **`Channels` ($4)** (int) : défaut = **3**  (1,32)
* **`Plot Type` ($5)** (choice) : choix possibles => None, Lines, Splines, Bars
* **`Vertex Type` ($6)** (choice) : choix possibles => None, Points, Crosses 1, Crosses 2, Circles 1, Circles 2, Square 1, Square 2
(Note) : Note : Use variable X instead of x in the above equation to take care of the X-min/max settings. Variable c refers to the current channel number. Variable u refers to a uniformly distributed random value in [0,1]. Reduce resolution to be able to view separate graph vertices.
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
