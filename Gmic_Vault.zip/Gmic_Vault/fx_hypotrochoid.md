---
tags: [gmic, filter]
command: fx_hypotrochoid
---

# Filtre G'MIC : fx_hypotrochoid

## Structure de la commande
```text
fx_hypotrochoid:
    periods = $1
    outer_radius = $2
    inner_radius = $3
    distance_to_center = $4
    thickness = $5
    anti_aliasing = $10
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Draws hypotrochoid curves (Spirograph-like). 
* **`Periods` ($1)** (int) : défaut = **37**  (1,100)
* **`Outer Radius (%)` ($2)** (float) : défaut = **100**  (0,300)
* **`Inner Radius (%)` ($3)** (float) : défaut = **74**  (0,300)
* **`Distance to Center (%)` ($4)** (float) : défaut = **80**  (0,300)
* **`Thickness (%)` ($5)** (float) : défaut = **0.5**  (0,5)
* **`Color` ($6)** (color) : défaut = 255,255,255,255
* **`Anti-Aliasing` ($7)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2021/01/25.
