---
tags: [gmic, filter]
command: fx_illuminate_shape2d
---

# Filtre G'MIC : fx_illuminate_shape2d

## Structure de la commande
```text
fx_illuminate_shape2d:
    input_type = $1
    output_type = $2
    keep_base_layer_as_input_background = $7
    keep_transparency_in_output = $8
    minimal_shape_area = $9
    preview_detected_shapes = $10
    erosion_dilation = $11
    smoothness = $12
    bump_factor = $13
    std_max_weight = $14
    resolution = $15
    blending_mode = $16
    opacity = $17
    ambient = $18
    diffuse = $19
    specular = $20
    shininess = $21
    smoothness = $22
    flatness = $23
    linearity = $24
    levels = $25
    light_x = $26
    light_y = $27
    light_z = $28
    normalize_illumination = $29
    preview_type = $31
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds 3D-like shading to 2D shapes (automatic bump mapping). 
(Note) : Input / Output:
* **`Input Type` ($1)** (choice) : choix possibles => Single Opaque Shapes Over Transp. BG, Multiple Colored Shapes Over Transp. BG, Bump Map, Normal Map
* **`Output Type` ($2)** (choice) : choix possibles => Illumination, Bump Map, Normal Map
* **`Input Guide Color` ($3)** (color) : défaut = 255,0,0,255
* **`Keep Base Layer as Input Background` ($4)** (bool) : par défaut = Faux (0)
* **`Keep Transparency in Output` ($5)** (bool) : par défaut = Faux (0)
(Note) : Shape:
* **`Minimal Shape Area` ($6)** (int) : défaut = **4**  (1,100)
(Note) : Parameter Minimal shape area is only active in Multiple colored shapes input mode.
* **`Preview Detected Shapes` ($7)** (bool) : par défaut = Faux (0)
* **`Erosion / Dilation` ($8)** (float) : défaut = **0**  (-10,10)
* **`Smoothness` ($9)** (float) : défaut = **3**  (0,6)
* **`Bump Factor` ($10)** (float) : défaut = **1**  (-5,5)
* **`Std / Max Weight` ($11)** (float) : défaut = **0.5**  (0,1)
* **`Resolution` ($12)** (choice) : choix possibles => Full (Slower), 2048, 1024, 512, 256, 128, 64 (Faster)
(Note) : Illumination:
* **`Blending Mode` ($13)** (choice) : choix possibles => Normal, Lighten, Screen, Dodge, Add, Darken, Multiply, Burn, Overlay, Soft Light, Hard Light, Grain Merge
* **`Opacity (%)` ($14)** (float) : défaut = **75**  (0,100)
* **`Ambient (%)` ($15)** (float) : défaut = **30**  (-100,100)
* **`Diffuse (%)` ($16)** (float) : défaut = **40**  (0,200)
* **`Specular (%)` ($17)** (float) : défaut = **40**  (0,300)
* **`Shininess` ($18)** (float) : défaut = **80**  (0,100)
* **`Smoothness` ($19)** (float) : défaut = **0.2**  (0,5)
* **`Flatness` ($20)** (float) : défaut = **1**  (0,3)
* **`Linearity` ($21)** (float) : défaut = **0**  (-100,100)
* **`Levels` ($22)** (int) : défaut = **0**  (0,16)
* **`Light-X` ($23)** (float) : défaut = **2**  (-20,20)
* **`Light-Y` ($24)** (float) : défaut = **-2**  (-20,20)
* **`Light-Z` ($25)** (float) : défaut = **2**  (0,20)
* **`Normalize Illumination` ($26)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($27)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Note: This filter automatically adds illumination to an opaque shape defined over a transparent background.
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2018/05/18.
