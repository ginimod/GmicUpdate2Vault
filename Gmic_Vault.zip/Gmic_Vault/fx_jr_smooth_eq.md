---
tags: [gmic, filter]
command: fx_jr_smooth_eq
---

# Filtre G'MIC : fx_jr_smooth_eq

## Structure de la commande
```text
fx_jr_smooth_eq:
    frequency_power = $1
    order_cube_root = $2
    resonance = $3
    frequency_power = $4
    order_cube_root = $5
    bandwidth = $6
    gain = $7
    frequency_power = $8
    order_cube_root = $9
    bandwidth = $10
    gain = $11
    frequency_power = $12
    order_cube_root = $13
    bandwidth = $14
    gain = $15
    frequency_power = $16
    order_cube_root = $17
    bandwidth = $18
    gain = $19
    frequency_power = $20
    order_cube_root = $21
    bandwidth = $22
    gain = $23
    frequency_power = $24
    order_cube_root = $25
    resonance = $26
    colour_space = $27
    alpha = $28
    absolute = $29
    makeup_gain = $30
    preview_frequency_response = $31
```
## Définition des variables
(Note) : A zero-phase equaliser with low-pass and high-pass filters and 5 band shelves.
(Note) : Low Pass
* **`Frequency Power` ($1)** (float) : défaut = **8**  (0,16)
* **`Order Cube Root` ($2)** (float) : défaut = **2**  (0,4)
* **`Resonance` ($3)** (float) : défaut = **0**  (0,5)
(Note) : Band Shelf 1
* **`Frequency Power` ($4)** (float) : défaut = **3**  (0,16)
* **`Order Cube Root` ($5)** (float) : défaut = **2**  (0,4)
* **`Bandwidth` ($6)** (float) : défaut = **1.5**  (0,16)
* **`Gain` ($7)** (float) : défaut = **0**  (-10,10)
(Note) : Band Shelf 2
* **`Frequency Power` ($8)** (float) : défaut = **4**  (0,16)
* **`Order Cube Root` ($9)** (float) : défaut = **2**  (0,4)
* **`Bandwidth` ($10)** (float) : défaut = **2**  (0,16)
* **`Gain` ($11)** (float) : défaut = **0**  (-10,10)
(Note) : Band Shelf 3
* **`Frequency Power` ($12)** (float) : défaut = **5**  (0,16)
* **`Order Cube Root` ($13)** (float) : défaut = **2**  (0,4)
* **`Bandwidth` ($14)** (float) : défaut = **2**  (0,16)
* **`Gain` ($15)** (float) : défaut = **0**  (-10,10)
(Note) : Band Shelf 4
* **`Frequency Power` ($16)** (float) : défaut = **6**  (0,16)
* **`Order Cube Root` ($17)** (float) : défaut = **2**  (0,4)
* **`Bandwidth` ($18)** (float) : défaut = **2**  (0,16)
* **`Gain` ($19)** (float) : défaut = **0**  (-10,10)
(Note) : Band Shelf 5
* **`Frequency Power` ($20)** (float) : défaut = **7**  (0,16)
* **`Order Cube Root` ($21)** (float) : défaut = **2**  (0,4)
* **`Bandwidth` ($22)** (float) : défaut = **2**  (0,16)
* **`Gain` ($23)** (float) : défaut = **0**  (-10,10)
(Note) : High Pass
* **`Frequency Power` ($24)** (float) : défaut = **3**  (0,16)
* **`Order Cube Root` ($25)** (float) : défaut = **2**  (0,4)
* **`Resonance` ($26)** (float) : défaut = **0**  (0,5)
* **`Colour Space` ($27)** (choice) : choix possibles => RGB, SRGB, CMY, RYB, Ohta8, Ohta, YES8, YES, Kodak 1-8, Kodak1, Lab8, Lab, Oklab, LUV, Jzazbz, YIQ8, YIQ, YUV8, YUV, YCbCr, YCbCrGLIC, YCbCrJPEG, YDbDr, XYZ8, XYZ, HSV8, HSV, HSL8, HSL, HSI8, HSI, LCH8, LCH, JzCzHz, HCY
* **`Alpha` ($28)** (bool) : par défaut = Faux (0)
* **`Absolute` ($29)** (bool) : par défaut = Faux (0)
* **`Makeup Gain` ($30)** (bool) : par défaut = Faux (0)
* **`Preview Frequency Response` ($31)** (bool) : par défaut = Faux (0)
