---
tags: [gmic, filter]
command: fx_decompose_channels
---

# Filtre G'MIC : fx_decompose_channels

## Structure de la commande
```text
fx_decompose_channels:
    color_basis = $1
    action = $2
    output_multiple_layers = $3
    include_opacity_layer = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Decomposes the image into various color space components. 
* **`Color Basis` ($1)** (choice) : choix possibles => RGB, HSV, HSL, HSI, YUV, YCbCr, XYZ, Lab, Lch, CMY, CMYK, YIQ
* **`Action` ($2)** (choice) : choix possibles => Decompose, Recompose
* **`Output Multiple Layers` ($3)** (bool) : par défaut = Faux (0)
* **`Include Opacity Layer` ($4)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/07/19.
