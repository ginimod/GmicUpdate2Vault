---
tags: [gmic, filter]
command: afre_darksky
---

# Filtre G'MIC : afre_darksky

## Structure de la commande
```text
afre_darksky:
    blend = $1
    contrast = $2
    smooth = $3
    radius = $4
```
## Définition des variables
(Note) : <strong>Enhance landscape by darkening the sky.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2017-2020 Sep9.</strong>


* **`Blend` ($1)** (choice) : choix possibles => Softlight, Overlay
* **`Contrast` ($2)** (int) : défaut = **0**  (-100,100)
* **`Smooth` ($3)** (choice) : choix possibles => Fast (Approx.), Slow (Accurate)
* **`Radius` ($4)** (int) : défaut = **0**  (0,3)
(Note) : 

<strong>Note</strong>

G'MIC's preview is inaccurate. Apply the filter and review the results in your host editor.

E.g. <code>Smooth(fast)</code> may appear to cause artifacts when in fact it does not.
