---
tags: [gmic, filter]
command: fx_remove_scratches
---

# Filtre G'MIC : fx_remove_scratches

## Structure de la commande
```text
fx_remove_scratches:
    threshold = $1
    erosion = $2
    dilation = $3
    show_preview_after = $4
    preview_type = $5
```
## Définition des variables
(Note) : Note: Scratch removal for scanned film images
* **`Threshold` ($1)** (float) : défaut = **72**  (0,100)
* **`Erosion` ($2)** (int) : défaut = **2**  (0,5)
* **`Dilation` ($3)** (int) : défaut = **4**  (0,7)
* **`Show Preview After` ($4)** (choice) : choix possibles => Threshold, Erosion, Dilation, Final Image
* **`Preview Type` ($5)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author: Chris/Pixls.us.      Latest update: 2017/04/01.
