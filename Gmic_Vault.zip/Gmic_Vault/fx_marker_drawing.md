---
tags: [gmic, filter]
command: fx_marker_drawing
---

# Filtre G'MIC : fx_marker_drawing

## Structure de la commande
```text
fx_marker_drawing:
    length_px = $1
    radius_px = $2
    opacity = $3
    inertia = $4
    curviness = $5
    anisotropy = $6
    smoothness = $7
    coherence = $8
    iterations = $9
    background_type = $10
    background_blur = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a marker drawing effect. 
* **`Length (px)` ($1)** (int) : défaut = **70**  (1,256)
* **`Radius (px)` ($2)** (float) : défaut = **4**  (1,32)
* **`Opacity (%)` ($3)** (float) : défaut = **10**  (0,100)
* **`Inertia (%)` ($4)** (float) : défaut = **15**  (0,100)
* **`Curviness (%)` ($5)** (float) : défaut = **100**  (0,200)
* **`Anisotropy (%)` ($6)** (float) : défaut = **85**  (0,100)
* **`Smoothness` ($7)** (float) : défaut = **0.5**  (0,5)
* **`Coherence` ($8)** (float) : défaut = **3**  (0,16)
* **`Iterations` ($9)** (int) : défaut = **3**  (1,64)
* **`Background Type` ($10)** (choice) : choix possibles => Blur, Color
* **`Background Blur` ($11)** (float) : défaut = **20**  (0,128)
* **`Background Color` ($12)** (color) : défaut = 255,255,255,255
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2026/02/23.
