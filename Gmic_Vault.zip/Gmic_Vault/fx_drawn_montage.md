---
tags: [gmic, filter]
command: fx_drawn_montage
---

# Filtre G'MIC : fx_drawn_montage

## Structure de la commande
```text
fx_drawn_montage:
    layer = $1
    zoom = $5
    x_centering = $6
    y_centering = $7
    angle = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Creates a montage from multiple layers based on a drawn template. 
* **`Layer` ($1)** (choice) : choix possibles => 1st, 2nd, 3rd, 4th, 5th, 6th, 7th, 8th, 9th, 10th, 11th, 12th, 13th, 14th, 15th, 16th
* **`Associated Color` ($2)** (color) : défaut = 0,0,0
* **`Zoom` ($3)** (float) : défaut = **-10**  (0,10)
* **`X-Centering (%)` ($4)** (float) : défaut = **50**  (0,100)
* **`Y-Centering (%)` ($5)** (float) : défaut = **50**  (0,100)
* **`Angle` ($6)** (choice) : choix possibles => 0 Deg., 90 Deg., 180 Deg., 270 Deg.
(Note) : Note: This filter requires a top layer containing the desired montage layout defined as free-form shapes of different colors. You can then assign each layer to a layout color to create the montage. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2018/01/29.
