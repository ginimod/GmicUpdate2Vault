---
tags: [gmic, filter]
command: fx_animate_pencilbw
---

# Filtre G'MIC : fx_animate_pencilbw

## Structure de la commande
```text
fx_animate_pencilbw:
    frames = $1
    output_frames = $2
    output_files = $3
    pencil_type = $5
    amplitude = $6
    pencil_type = $7
    amplitude = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Animates a pencil sketch effect. 
* **`Frames` ($1)** (int) : défaut = **10**  (2,100)
* **`Output Frames` ($2)** (bool) : par défaut = Faux (0)
* **`Output Files` ($3)** (bool) : par défaut = Faux (0)
(Note) : 
Starting Parameters :
* **`Pencil Type` ($4)** (float) : défaut = **2.3**  (0,5)
* **`Amplitude` ($5)** (float) : défaut = **100**  (0,200)
(Note) : 
Ending Parameters :
* **`Pencil Type` ($6)** (float) : défaut = **0.3**  (0,5)
* **`Amplitude` ($7)** (float) : défaut = **60**  (0,200)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
