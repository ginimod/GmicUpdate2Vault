---
tags: [gmic, filter]
command: fx_jr_spiral_transform
---

# Filtre G'MIC : fx_jr_spiral_transform

## Structure de la commande
```text
fx_jr_spiral_transform:
    mode = $1
    spiral_rotation = $2
    direction = $3
    starting_axis = $4
    spiral_start = $5
```
## Définition des variables
(Note) : Transforms images into rectangular spirals. The main use is to run effects on the transformed images and then use a corresponding reverse transformation for unusual effects. Preview may be highly-inaccurate. Based off an unfinished script from the <a href="https://forums.getpaint.net/topic/30276-glitch-effect-plugin-polyglitch-v14b/">PolyGlitch Paint.NET plugin</a>.

 Details of the Spiral Matrix Transform's mathematics can be found in this thread - <a href="https://discuss.pixls.us/t/challenge-spiralbw-as-a-parametric-function-x-t-y-t/12779">Challenge: Spiralbw as a parametric function (x(t),y(t))</a>.
* **`Mode` ($1)** (choice) : choix possibles => Spiral, Inverse Spiral
* **`Spiral Rotation` ($2)** (choice) : choix possibles => Clockwise, Anticlockwise
* **`Direction` ($3)** (choice) : choix possibles => Down, Up
* **`Starting Axis` ($4)** (choice) : choix possibles => X, Y
* **`Spiral Start` ($5)** (choice) : choix possibles => Outside, Inside
(Note) : Author: Reptorian, <a href="http://bit.ly/2CmhX65">David Tschumperlé</a>.,Joan Rake and Garagecoder. Latest Update: 2019/5/28.
