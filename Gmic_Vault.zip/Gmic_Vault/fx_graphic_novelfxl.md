---
tags: [gmic, filter]
command: fx_graphic_novelfxl
---

# Filtre G'MIC : fx_graphic_novelfxl

## Structure de la commande
```text
fx_graphic_novelfxl:
    skip_this_step = $1
    ln_amplititude = $2
    ln_size = $3
    ln_neightborhood_smoothness = $4
    ln_average_smoothness = $5
    skip_all_other_steps = $6
    pencil_size = $7
    pencil_amplitude = $8
    skip_all_other_steps = $9
    activate_pencil_smoother = $10
    pencil_smoother_sharpness = $11
    pencil_smoother_edge_protection = $12
    pencil_smoother_smoothness = $13
    skip_all_other_steps = $14
    swap_layers = $15
    mixer = $16
    opacity = $17
    intensity = $18
    add_painter_s_touch = $19
    painter_s_touch_sharpness = $20
    painter_s_edge_protection_flow = $21
    painter_s_smoothness = $22
```
## Définition des variables
(Note) : Apply Local Normalization
* **`Skip This Step` ($1)** (bool) : par défaut = Faux (0)
(Note) : Local Normalization Controls
* **`LN Amplititude` ($2)** (float) : défaut = **2**  (0,60)
* **`LN Size` ($3)** (float) : défaut = **6**  (0,64)
* **`LN Neightborhood-Smoothness` ($4)** (float) : défaut = **5**  (0,40)
* **`LN Average-Smoothness` ($5)** (float) : défaut = **20**  (0,40)
* **`Skip All Other Steps` ($6)** (bool) : par défaut = Faux (0)
(Note) : Pencil Options
* **`Pencil Size` ($7)** (float) : défaut = **0.62**  (0,4)
* **`Pencil Amplitude` ($8)** (float) : défaut = **14**  (0,200)
* **`Skip All Other Steps` ($9)** (bool) : par défaut = Faux (0)
* **`Activate 'Pencil Smoother'` ($10)** (bool) : par défaut = Faux (0)
(Note) : If unchecked the 3 sliders below are disabled
* **`Pencil Smoother Sharpness` ($11)** (float) : défaut = **0.5**  (0,2)
* **`Pencil Smoother Edge Protection` ($12)** (float) : défaut = **0.78**  (0,1)
* **`Pencil Smoother Smoothness` ($13)** (float) : défaut = **1.92**  (0,10)
* **`Skip All Other Steps` ($14)** (bool) : par défaut = Faux (0)
(Note) : Boost Merging Options
* **`Swap Layers` ($15)** (bool) : par défaut = Faux (0)
* **`MIxer` ($16)** (choice) : choix possibles => Overlay, Multiply, Soft Light, Color Burn, Darken, Stamp, Hard Light, Value, Grain Merge, Freeze, Lightness, Luminance, *Colors Doping, *Comix Colors*, Graphic Colours, *Graphix Colors, *Vivid Edges*, *Dark Edges*, *Dark Screen*, *Vivid Screen*, Interpolate
* **`Opacity` ($17)** (float) : défaut = **1**  (0,1)
* **`Intensity` ($18)** (float) : défaut = **1**  (0,1)
* **`Add Painter's Touch` ($19)** (bool) : par défaut = Faux (0)
* **`Painter's Touch Sharpness` ($20)** (float) : défaut = **0.5**  (0,2)
* **`Painter's Edge Protection Flow` ($21)** (float) : défaut = **0.8**  (0,1)
* **`Painter's Smoothness` ($22)** (float) : défaut = **1.28**  (0,10)
(Note) : Author: PhotoComiX. Latest update : 2011/13/11.
