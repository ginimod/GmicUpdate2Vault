---
tags: [gmic, filter]
command: fx_graphic_boost4
---

# Filtre G'MIC : fx_graphic_boost4

## Structure de la commande
```text
fx_graphic_boost4:
    radius = $1
    darken = $2
    skip_others_steps = $3
    pencil_size = $4
    pencil_amplitude = $5
    skip_others_steps = $6
    activate_pencil_smoother = $7
    pencil_smoother_sharpness = $8
    pencil_smoother_edge_protection = $9
    pencil_smoother_smoothness = $10
    skip_others_steps = $11
    swap_layers = $12
    merging_option = $13
    opacity = $14
    intensity = $15
    add_painter_s_touch = $16
    painter_s_touch_sharpness = $17
    painter_s_edge_protection_flow = $18
    painter_s_smoothness = $19
```
## Définition des variables
(Note) : Unsharp Mask controls
* **`Radius` ($1)** (float) : défaut = **1.25**  (0,20)
* **`Darken` ($2)** (float) : défaut = **2**  (0,10)
* **`Skip Others Steps` ($3)** (bool) : par défaut = Faux (0)
(Note) : Check for visual control, UNcheck to reactivate the other controls
(Note) : BW_Pencil Controls
* **`Pencil Size` ($4)** (float) : défaut = **0.15**  (0,4)
* **`Pencil Amplitude` ($5)** (float) : défaut = **14**  (0,200)
* **`Skip Others Steps` ($6)** (bool) : par défaut = Faux (0)
* **`Activate 'Pencil Smoother'` ($7)** (bool) : par défaut = Faux (0)
(Note) : If unchecked the 3 sliders below are disabled
* **`Pencil Smoother Sharpness` ($8)** (float) : défaut = **0.5**  (0,2)
* **`Pencil Smoother Edge Protection` ($9)** (float) : défaut = **0.45**  (0,1)
* **`Pencil Smoother Smoothness` ($10)** (float) : défaut = **2**  (0,10)
* **`Skip Others Steps` ($11)** (bool) : par défaut = Faux (0)
(Note) : Merging Options
* **`Swap Layers` ($12)** (bool) : par défaut = Faux (0)
(Note) : 'Swap' change the effect of Merging and Intesity
* **`Merging Option` ($13)** (choice) : choix possibles => Hard Light, Grain Merge, Multiply, Color Burn, Overlay, Value, Darken, Lightness, Luminance, *Colors Doping*, Comix Colors, Graphic Colours, Graphix Colors, Vivid Edges*, Dark Edges, Dark Screen, Vivid Screen, Interpolate
* **`Opacity` ($14)** (float) : défaut = **1**  (0,1)
* **`Intensity` ($15)** (float) : défaut = **1**  (0,1)
* **`Add Painter's Touch` ($16)** (bool) : par défaut = Faux (0)
(Note) : If unchecked the 3 sliders below are disabled
* **`Painter's Touch Sharpness` ($17)** (float) : défaut = **0.5**  (0,2)
* **`Painter's Edge Protection Flow` ($18)** (float) : défaut = **0.45**  (0,1)
* **`Painter's Smoothness` ($19)** (float) : défaut = **1**  (0,10)
(Note) : Author: PhotoComiX. Latest update : 2011/13/11 .
