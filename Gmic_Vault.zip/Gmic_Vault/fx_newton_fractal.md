---
tags: [gmic, filter]
command: fx_newton_fractal
---

# Filtre G'MIC : fx_newton_fractal

## Structure de la commande
```text
fx_newton_fractal:
    expression = $5
    descent_method = $9
    max_iterations = $10
    precision = $11
    coloring = $12
    number_of_colors = $13
    smoothness = $14
    seed = $15
    color_space = $16
    hue_min = $17
    hue_max = $18
    lightness_min = $19
    lightness_max = $20
    color_space = $21
    pre_process = $22
    post_process = $26
    brightness = $27
    contrast = $28
    gamma = $29
    hue = $30
    saturation = $31
    equalization = $32
    anti_aliasing = $33
    zoom_center_x = $35
    zoom_center_y = $36
    zoom_factor = $37
    angle = $38
    display_coordinates_on_preview_window = $43
    preview_subsampling = $44
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Renders a Newton fractal. 
(Note) : <span color="#EE5500">Fractal Type:</span>
* **`Expression` ($1)** (choice) : choix possibles => Custom, Z^^2 - 1, Z^^3 - 1, Z^^5 - 1, Z^^6 + Z^^3 - 1, Z^^8 + 15*z^^4 - 1
* **`Descent Method` ($2)** (choice) : choix possibles => Secant, Newton, Householder
* **`Max Iterations` ($3)** (int) : défaut = **200**  (16,1024)
* **`Precision` ($4)** (float) : défaut = **2**  (0,12)
(Note) : <span color="#EE5500">Rendering:</span>
* **`Coloring` ($5)** (choice) : choix possibles => By Custom Expression, By Iteration, By Value
* **`Number of Colors` ($6)** (int) : défaut = **16**  (2,2048)
* **`Smoothness` ($7)** (int) : défaut = **8**  (1,256)
* **`Seed` ($8)** (int) : défaut = **255**  (0,65536)
* **`Color Space` ($9)** (choice) : choix possibles => HSI, HSL, HSV
* **`Hue Min (%)` ($10)** (float) : défaut = **100**  (0,500)
* **`Hue Max (%)` ($11)** (float) : défaut = **150**  (0,500)
* **`Lightness Min (%)` ($12)** (float) : défaut = **20**  (0,500)
* **`Lightness Max (%)` ($13)** (float) : défaut = **400**  (0,500)
* **`Color Space` ($14)** (choice) : choix possibles => RGB, HSI, HSL, HSV, Lab
* **`Pre-Process` ($15)** (choice) : choix possibles => None, Equalize, Normalize, Equalize and Normalize
(Note) : <span color="#EE5500">Tips for Custom expressions:</span>
 - Variables i0,i1 stand for the real and imaginary parts of the iterated complex number.
 - Variable i2 is the number of iterations required for convergence.
 - Variable z is the complex number with value [ i0,i1 ].
 - Functions p(z), dp(z) and d2p(z) are the expressions used for computing the fractal. 
* **`Post-Process` ($16)** (choice) : choix possibles => None, Equalize, Normalize, Equalize and Normalize
* **`Brightness (%)` ($17)** (float) : défaut = **0**  (-100,100)
* **`Contrast (%)` ($18)** (float) : défaut = **0**  (-100,100)
* **`Gamma (%)` ($19)** (float) : défaut = **0**  (-100,100)
* **`Hue (%)` ($20)** (float) : défaut = **0**  (-100,100)
* **`Saturation (%)` ($21)** (float) : défaut = **0**  (-100,100)
* **`Equalization (%)` ($22)** (float) : défaut = **0**  (0,100)
* **`Anti-Aliasing` ($23)** (choice) : choix possibles => X1, X1.5, X2, X2.5, X3, X3.5, 4
(Note) : Note: Anti-aliasing is applied to final rendering only, not on preview.
(Note) : <span color="#EE5500">Navigation:</span>
* **`Zoom Center` ($24)** (point) : position = 0,0
* **`Zoom Factor` ($25)** (float) : défaut = **0.5**  (0,1)
* **`Angle` ($26)** (float) : défaut = **0**  (-180,180)
* **`Display Coordinates on Preview Window` ($27)** (bool) : par défaut = Faux (0)
* **`Preview Subsampling` ($28)** (choice) : choix possibles => None, X1.5, X2, X2.5, X3, X3.5, X4
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2019/01/09.
