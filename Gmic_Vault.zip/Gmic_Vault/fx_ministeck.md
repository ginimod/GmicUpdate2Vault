---
tags: [gmic, filter]
command: fx_ministeck
---

# Filtre G'MIC : fx_ministeck

## Structure de la commande
```text
fx_ministeck:
    number_of_colors = $1
    resolution_px = $2
    piece_size_px = $3
    piece_complexity = $4
    relief_amplitude = $5
    relief_size = $6
    add_1px_outline = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates a mosaic effect using "Ministeck" plastic shapes. 
* **`Number of Colors` ($1)** (int) : défaut = **8**  (2,24)
* **`Resolution (px)` ($2)** (int) : défaut = **64**  (16,256)
* **`Piece Size (px)` ($3)** (int) : défaut = **8**  (1,64)
* **`Piece Complexity` ($4)** (int) : défaut = **2**  (1,10)
* **`Relief Amplitude` ($5)** (float) : défaut = **100**  (0,256)
* **`Relief Size` ($6)** (float) : défaut = **0.3**  (0,1)
* **`Add 1px Outline` ($7)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/01/14.
