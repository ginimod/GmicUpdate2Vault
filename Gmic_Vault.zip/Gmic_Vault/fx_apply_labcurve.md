---
tags: [gmic, filter]
command: fx_apply_Labcurve
---

# Filtre G'MIC : fx_apply_Labcurve

## Structure de la commande
```text
fx_apply_Labcurve:
    starting_y = $1
    x_coord_1 = $2
    y_coord_1 = $3
    x_coord_2 = $4
    y_coord_2 = $5
    x_coord_3 = $6
    y_coord_3 = $7
    x_coord_4 = $8
    y_coord_4 = $9
    x_coord_5 = $10
    y_coord_5 = $11
    ending_y = $12
    curve_smoothness = $13
    display_histogram = $14
    preview_type = $15
```
## Définition des variables
* **`Starting Y` ($1)** (int) : défaut = **0**  (0,255)
* **`X-Coord(1)` ($2)** (int) : défaut = **-1**  (-1,255)
* **`Y-Coord(1)` ($3)** (int) : défaut = **128**  (0,255)
* **`X-Coord(2)` ($4)** (int) : défaut = **-1**  (-1,255)
* **`Y-Coord(2)` ($5)** (int) : défaut = **128**  (0,255)
* **`X-Coord(3)` ($6)** (int) : défaut = **-1**  (-1,255)
* **`Y-Coord(3)` ($7)** (int) : défaut = **128**  (0,255)
* **`X-Coord(4)` ($8)** (int) : défaut = **-1**  (-1,255)
* **`Y-Coord(4)` ($9)** (int) : défaut = **128**  (0,255)
* **`X-Coord(5)` ($10)** (int) : défaut = **-1**  (-1,255)
* **`Y-Coord(5)` ($11)** (int) : défaut = **128**  (0,255)
* **`Ending Y` ($12)** (int) : défaut = **255**  (0,255)
* **`Curve Smoothness` ($13)** (float) : défaut = **1**  (0,1)
* **`Display Histogram` ($14)** (float) : défaut = **0**  (0,100)
* **`Preview Type` ($15)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest update: 2010/29/12.
