---
tags: [gmic, filter]
command: fx_posterize
---

# Filtre G'MIC : fx_posterize

## Structure de la commande
```text
fx_posterize:
    smoothness = $1
    edges = $2
    paint = $3
    colors = $4
    minimal_area = $5
    outline = $6
    normalize_colors = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Reduces the number of distinct colors in the image and apply a smooth look. 
* **`Smoothness` ($1)** (float) : défaut = **150**  (0,800)
* **`Edges (%)` ($2)** (float) : défaut = **30**  (0,100)
* **`Paint` ($3)** (float) : défaut = **1**  (0,10)
* **`Colors` ($4)** (int) : défaut = **12**  (2,256)
* **`Minimal Area` ($5)** (int) : défaut = **0**  (0,64)
* **`Outline (%)` ($6)** (float) : défaut = **0**  (0,100)
* **`Normalize Colors` ($7)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/10/25.
