---
tags: [gmic, filter]
command: fx_pack_sprites
---

# Filtre G'MIC : fx_pack_sprites

## Structure de la commande
```text
fx_pack_sprites:
    number_of_scales = $1
    minimal_scale = $2
    allow_angle = $3
    spacing = $4
    precision = $5
    masking = $6
    width = $7
    height = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Fills the image by packing small sprite images. 
* **`Number of Scales` ($1)** (int) : défaut = **5**  (1,16)
* **`Minimal Scale (%)` ($2)** (float) : défaut = **25**  (1,100)
* **`Allow Angle` ($3)** (choice) : choix possibles => 0 Deg., 180 Deg., 90 Deg., Any
* **`Spacing` ($4)** (int) : défaut = **1**  (-16,16)
* **`Precision` ($5)** (int) : défaut = **5**  (1,10)
* **`Masking` ($6)** (choice) : choix possibles => No Masking, Mask as Bottom Layer
* **`Width` ($7)** (int) : défaut = **512**  (32,2048)
* **`Height` ($8)** (int) : défaut = **512**  (32,2048)
(Note) : Notes:
 - Parameters Width and Height are considered only when No masking mode is selected.
 - Set different sprites on different layers to pack multiple sprites at the same time.
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2025/06/06.
