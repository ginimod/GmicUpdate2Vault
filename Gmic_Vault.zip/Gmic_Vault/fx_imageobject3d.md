---
tags: [gmic, filter]
command: fx_imageobject3d
---

# Filtre G'MIC : fx_imageobject3d

## Structure de la commande
```text
fx_imageobject3d:
    type = $1
    width = $2
    height = $3
    size = $4
    x_angle = $5
    y_angle = $6
    z_angle = $7
    fov = $8
    x_light = $9
    y_light = $10
    z_light = $11
    specular_lightness = $12
    specular_shininess = $13
    rendering = $14
    antialiasing = $15
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Maps the image onto a 3D object. 
* **`Type` ($1)** (choice) : choix possibles => Plane, Cube, Pyramid, Sphere, Torus, Gyroid, Weird, Cup, Rubik
* **`Width` ($2)** (int) : défaut = **1024**  (1,4096)
* **`Height` ($3)** (int) : défaut = **1024**  (1,4096)
* **`Size` ($4)** (float) : défaut = **0.5**  (0,3)
* **`X-Angle` ($5)** (float) : défaut = **57**  (0,360)
* **`Y-Angle` ($6)** (float) : défaut = **41**  (0,360)
* **`Z-Angle` ($7)** (float) : défaut = **21**  (0,360)
* **`FOV` ($8)** (float) : défaut = **45**  (1,90)
* **`X-Light` ($9)** (float) : défaut = **0**  (-100,100)
* **`Y-Light` ($10)** (float) : défaut = **0**  (-100,100)
* **`Z-Light` ($11)** (float) : défaut = **-100**  (-100,0)
* **`Specular Lightness` ($12)** (float) : défaut = **0.5**  (0,1)
* **`Specular Shininess` ($13)** (float) : défaut = **0.7**  (0,3)
* **`Rendering` ($14)** (choice) : choix possibles => Dots, Wireframe, Flat, Flat-Shaded, Gouraud, Phong
* **`Antialiasing` ($15)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
