---
tags: [gmic, filter]
command: afre_softlight
---

# Filtre G'MIC : afre_softlight

## Structure de la commande
```text
afre_softlight:
    amount = $1
    reverse_order = $2
```
## Définition des variables
(Note) : <strong>Blend image with itself or another image using softlight.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2019-2020 Sept9.</strong>


* **`Amount` ($1)** (int) : défaut = **50**  (-100,100)
* **`Reverse Order` ($2)** (bool) : par défaut = Faux (0)
(Note) : 

<strong>Hint</strong>

Use the  <code>Input</code> <code>layers</code>  menu to select the layer(s) you would like to blend.
(Note) : 
<strong>Note</strong>

G'MIC's preview is inaccurate. Apply the filter and review the results in your host editor.
