---
tags: [gmic, filter]
command: fx_compose_graphixcolor
---

# Filtre G'MIC : fx_compose_graphixcolor

## Structure de la commande
```text
fx_compose_graphixcolor:
    opacity = $1
    revert_layers = $2
```
## Définition des variables
* **`Opacity` ($1)** (float) : défaut = **1**  (0,1)
* **`Revert Layers` ($2)** (bool) : par défaut = Faux (0)
(Note) : This filter needs two layers to work properly. Set the Input layers option to handle multiple input layers.
(Note) : Author: PhotoComiX.      Latest update : 2011/13/11.
