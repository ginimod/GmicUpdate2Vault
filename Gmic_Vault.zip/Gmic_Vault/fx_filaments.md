---
tags: [gmic, filter]
command: fx_filaments
---

# Filtre G'MIC : fx_filaments

## Structure de la commande
```text
fx_filaments:
    density = $1
    length = $2
    contour = $3
    distortion = $4
    smoothness = $5
    rotation_deg = $6
    local_normalization = $7
    throw_from_left = $8
    throw_from_right = $9
    throw_from_above = $10
    throw_from_below = $11
    opacity = $12
    color_model = $13
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Converts the image into a network of fine filaments. 
* **`Density (%)` ($1)** (float) : défaut = **50**  (0,100)
* **`Length (%)` ($2)** (float) : défaut = **50**  (0,100)
* **`Contour (%)` ($3)** (float) : défaut = **75**  (0,100)
* **`Distortion (%)` ($4)** (float) : défaut = **30**  (0,100)
* **`Smoothness` ($5)** (float) : défaut = **10**  (0,100)
* **`Rotation (deg.)` ($6)** (float) : défaut = **0**  (-180,180)
* **`Local Normalization` ($7)** (bool) : par défaut = Faux (0)
* **`Throw From Left` ($8)** (bool) : par défaut = Faux (0)
* **`Throw From Right` ($9)** (bool) : par défaut = Faux (0)
* **`Throw From Above` ($10)** (bool) : par défaut = Faux (0)
* **`Throw From Below` ($11)** (bool) : par défaut = Faux (0)
* **`Opacity (%)` ($12)** (float) : défaut = **50**  (0,100)
* **`Color Model` ($13)** (choice) : choix possibles => White on Black, Black on White, White on Transparent, Black on Transparent
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2023/12/18.
