---
tags: [gmic, filter]
command: fx_animate_lissajous
---

# Filtre G'MIC : fx_animate_lissajous

## Structure de la commande
```text
fx_animate_lissajous:
    frames = $1
    output_as_frames = $2
    output_as_files = $3
    resolution = $5
    x_size = $6
    y_size = $7
    z_size = $8
    x_multiplier = $9
    y_multiplier = $10
    z_multiplier = $11
    x_offset = $12
    y_offset = $13
    z_offset = $14
    x_angle = $15
    y_angle = $16
    z_angle = $17
    thickness = $18
    resolution = $23
    x_size = $24
    y_size = $25
    z_size = $26
    x_multiplier = $27
    y_multiplier = $28
    z_multiplier = $29
    x_offset = $30
    y_offset = $31
    z_offset = $32
    x_angle = $33
    y_angle = $34
    z_angle = $35
    thickness = $36
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Animates a Lissajous curve. 
* **`Frames` ($1)** (int) : défaut = **10**  (2,100)
* **`Output as Frames` ($2)** (bool) : par défaut = Faux (0)
* **`Output as Files` ($3)** (bool) : par défaut = Faux (0)
(Note) : Starting parameters :
* **`Resolution` ($4)** (int) : défaut = **4096**  (2,8192)
* **`X-Size` ($5)** (float) : défaut = **0.9**  (0,2)
* **`Y-Size` ($6)** (float) : défaut = **0.9**  (0,2)
* **`Z-Size` ($7)** (float) : défaut = **3**  (1,10)
* **`X-Multiplier` ($8)** (float) : défaut = **8**  (0,32)
* **`Y-Multiplier` ($9)** (float) : défaut = **7**  (0,32)
* **`Z-Multiplier` ($10)** (float) : défaut = **0**  (0,32)
* **`X-Offset` ($11)** (float) : défaut = **0**  (0,1)
* **`Y-Offset` ($12)** (float) : défaut = **0**  (0,1)
* **`Z-Offset` ($13)** (float) : défaut = **0**  (0,1)
* **`X-Angle` ($14)** (float) : défaut = **0**  (0,360)
* **`Y-Angle` ($15)** (float) : défaut = **0**  (0,360)
* **`Z-Angle` ($16)** (float) : défaut = **0**  (0,360)
* **`Thickness` ($17)** (float) : défaut = **0**  (0,50)
* **`Color` ($18)** (color) : défaut = 255,255,255,255
(Note) : Ending parameters :
* **`Resolution` ($19)** (int) : défaut = **4096**  (2,8192)
* **`X-Size` ($20)** (float) : défaut = **0.9**  (0,2)
* **`Y-Size` ($21)** (float) : défaut = **0.9**  (0,2)
* **`Z-Size` ($22)** (float) : défaut = **3**  (1,10)
* **`X-Multiplier` ($23)** (float) : défaut = **8**  (0,32)
* **`Y-Multiplier` ($24)** (float) : défaut = **7**  (0,32)
* **`Z-Multiplier` ($25)** (float) : défaut = **0**  (0,32)
* **`X-Offset` ($26)** (float) : défaut = **0**  (0,1)
* **`Y-Offset` ($27)** (float) : défaut = **0**  (0,1)
* **`Z-Offset` ($28)** (float) : défaut = **0**  (0,1)
* **`X-Angle` ($29)** (float) : défaut = **0**  (0,360)
* **`Y-Angle` ($30)** (float) : défaut = **0**  (0,360)
* **`Z-Angle` ($31)** (float) : défaut = **0**  (0,360)
* **`Thickness` ($32)** (float) : défaut = **0**  (0,50)
* **`Color` ($33)** (color) : défaut = 255,255,255,255
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2011/04/18.
