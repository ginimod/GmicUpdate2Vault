---
tags: [gmic, filter]
command: fx_gcd_upscale_edge
---

# Filtre G'MIC : fx_gcd_upscale_edge

## Structure de la commande
```text
fx_gcd_upscale_edge:
    factor = $1
    factor = $2
    type = $3
    values = $4
```
## Définition des variables
(Note) : Edge sharpening upscale
* **`Factor` ($1)** (choice) : choix possibles => Custom, 2, 3, 4, 5, 6, 7, 8
* **`Factor` ($2)** (float) : défaut = **1**  (1,8)
* **`Type` ($3)** (choice) : choix possibles => Linear, Bicubic
* **`Values` ($4)** (choice) : choix possibles => Unbounded, Cut, Normalize
(Note) : Author : Garagecoder.      Latest update : 2021/01/12.
(Note) : 
Variance smoothed upscale for high scale factors.
(Note) : Image dimensions are multiplied by specified factor.
