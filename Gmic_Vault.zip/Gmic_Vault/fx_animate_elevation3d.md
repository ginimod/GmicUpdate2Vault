---
tags: [gmic, filter]
command: fx_animate_elevation3d
---

# Filtre G'MIC : fx_animate_elevation3d

## Structure de la commande
```text
fx_animate_elevation3d:
    frames = $1
    output_as_frames = $2
    output_as_files = $3
    factor = $5
    smoothness = $6
    width = $7
    height = $8
    rendering = $9
    size = $10
    x_angle = $11
    y_angle = $12
    z_angle = $13
    fov = $14
    x_light = $15
    y_light = $16
    z_light = $17
    specular_lightness = $18
    specular_shininess = $19
    size = $20
    x_angle = $21
    y_angle = $22
    z_angle = $23
    fov = $24
    x_light = $25
    y_light = $26
    z_light = $27
    specular_lightness = $28
    specular_shininess = $29
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Creates an animation of a 3D image elevation. 
* **`Frames` ($1)** (int) : défaut = **10**  (2,100)
* **`Output as Frames` ($2)** (bool) : par défaut = Faux (0)
* **`Output as Files` ($3)** (bool) : par défaut = Faux (0)
(Note) : 
Global parameters :
* **`Factor` ($4)** (float) : défaut = **100**  (-1000,1000)
* **`Smoothness` ($5)** (float) : défaut = **1**  (0,10)
* **`Width` ($6)** (int) : défaut = **1024**  (8,4096)
* **`Height` ($7)** (int) : défaut = **1024**  (8,4096)
* **`Rendering` ($8)** (choice) : choix possibles => Dots, Wireframe, Flat, Flat-Shaded, Gouraud, Phong
(Note) : 
Starting parameters :
* **`Size` ($9)** (float) : défaut = **0.8**  (0,3)
* **`X-Angle` ($10)** (float) : défaut = **35**  (0,360)
* **`Y-Angle` ($11)** (float) : défaut = **0**  (0,360)
* **`Z-Angle` ($12)** (float) : défaut = **0**  (0,360)
* **`FOV` ($13)** (float) : défaut = **45**  (1,90)
* **`X-Light` ($14)** (float) : défaut = **0**  (-100,100)
* **`Y-Light` ($15)** (float) : défaut = **0**  (-100,100)
* **`Z-Light` ($16)** (float) : défaut = **-100**  (-100,0)
* **`Specular Lightness` ($17)** (float) : défaut = **0.5**  (0,1)
* **`Specular Shininess` ($18)** (float) : défaut = **0.7**  (0,3)
(Note) : 
Ending parameters :
* **`Size` ($19)** (float) : défaut = **0.8**  (0,3)
* **`X-Angle` ($20)** (float) : défaut = **35**  (0,1440)
* **`Y-Angle` ($21)** (float) : défaut = **0**  (0,1440)
* **`Z-Angle` ($22)** (float) : défaut = **360**  (0,1440)
* **`FOV` ($23)** (float) : défaut = **45**  (1,90)
* **`X-Light` ($24)** (float) : défaut = **0**  (-100,100)
* **`Y-Light` ($25)** (float) : défaut = **0**  (-100,100)
* **`Z-Light` ($26)** (float) : défaut = **-100**  (-100,0)
* **`Specular Lightness` ($27)** (float) : défaut = **0.5**  (0,1)
* **`Specular Shininess` ($28)** (float) : défaut = **0.7**  (0,3)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
