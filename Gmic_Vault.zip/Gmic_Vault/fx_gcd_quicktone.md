---
tags: [gmic, filter]
command: fx_gcd_quicktone
---

# Filtre G'MIC : fx_gcd_quicktone

## Structure de la commande
```text
fx_gcd_quicktone:
    power = $1
    radius = $2
    range = $3
    smooth = $4
    channels = $5
    values = $6
```
## Définition des variables
(Note) : Simple tone and detail control
* **`Power` ($1)** (float) : défaut = **1**  (0.5,2.5)
* **`Radius` ($2)** (float) : défaut = **4**  (0,10)
* **`Range` ($3)** (float) : défaut = **20**  (0,20)
* **`Smooth` ($4)** (float) : défaut = **0**  (0,4)
* **`Channels` ($5)** (choice) : choix possibles => HSI, HSV, Lab, YCbCr
* **`Values` ($6)** (choice) : choix possibles => Cut, Normalize
(Note) : Author : Garagecoder.      Latest update : 2018/06/26.
