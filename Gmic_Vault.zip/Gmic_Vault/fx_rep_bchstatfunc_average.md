---
tags: [gmic, filter]
command: fx_rep_bchstatfunc_average
---

# Filtre G'MIC : fx_rep_bchstatfunc_average

## Structure de la commande
```text
fx_rep_bchstatfunc_average:
    mode = $1
    preserve_alpha = $2
    preview_type = $3
    preview_split_x = $4
    preview_split_y = $5
```
## Définition des variables
* **`Mode` ($1)** (choice) : choix possibles => RGB, SRGB, RYB, LAB
* **`Preserve Alpha?` ($2)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($3)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($4)** (point) : position = 0,0
(Note) : Author: Reptorian. Latest Update: 2024/01/15.
