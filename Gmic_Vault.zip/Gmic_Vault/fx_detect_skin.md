---
tags: [gmic, filter]
command: fx_detect_skin
---

# Filtre G'MIC : fx_detect_skin

## Structure de la commande
```text
fx_detect_skin:
    skin_estimation = $1
    tolerance = $2
    smoothness = $3
    threshold = $4
    pre_normalize_image = $5
    x_coordinate = $6
    y_coordinate = $7
    radius = $8
    output_mode = $9
    preview_type = $10
    preview_split_x = $11
    preview_split_y = $12
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a mask highlighting skin tones. 
* **`Skin Estimation` ($1)** (choice) : choix possibles => Manual, Automatic
* **`Tolerance` ($2)** (float) : défaut = **0.5**  (0,1)
* **`Smoothness` ($3)** (float) : défaut = **0.5**  (0,5)
* **`Threshold` ($4)** (float) : défaut = **1**  (0,10)
* **`Pre-Normalize Image` ($5)** (bool) : par défaut = Faux (0)
(Note) : Manual estimation:
 Use the sliders below to target as much skin pixels as you can.
* **`X-Coordinate` ($6)** (float) : défaut = **50**  (0,100)
* **`Y-Coordinate` ($7)** (float) : défaut = **50**  (0,100)
* **`Radius` ($8)** (float) : défaut = **5**  (0,25)
* **`Output Mode` ($9)** (choice) : choix possibles => Probability Map, Opaque Skin, Transparent Skin
* **`Preview Type` ($10)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($11)** (point) : position = 0,0
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2014/01/03.
