---
tags: [gmic, filter]
command: fx_equirectangular2nadirzenith
---

# Filtre G'MIC : fx_equirectangular2nadirzenith

## Structure de la commande
```text
fx_equirectangular2nadirzenith:
    mode = $1
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Converts 360 panoramas to nadir/zenith views. 
* **`Mode` ($1)** (choice) : choix possibles => to Nadir / Zenith, to Equirectangular
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/12/29.
