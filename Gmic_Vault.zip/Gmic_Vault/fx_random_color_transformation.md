---
tags: [gmic, filter]
command: fx_random_color_transformation
---

# Filtre G'MIC : fx_random_color_transformation

## Structure de la commande
```text
fx_random_color_transformation:
    seed = $1
    amplitude = $4
    brightness = $5
    contrast = $6
    gamma = $7
    hue = $8
    saturation = $9
    preview_type = $10
    preview_split_x = $11
    preview_split_y = $12
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Applies random changes to image colors, using randomly generated CLUT. 
* **`Seed` ($1)** (float) : défaut = **0**  (0,100000)
* **`Amplitude (%)` ($2)** (float) : défaut = **100**  (0,100)
* **`Brightness (%)` ($3)** (float) : défaut = **0**  (-100,100)
* **`Contrast (%)` ($4)** (float) : défaut = **0**  (-100,100)
* **`Gamma (%)` ($5)** (float) : défaut = **0**  (-100,100)
* **`Hue (%)` ($6)** (float) : défaut = **0**  (-100,100)
* **`Saturation (%)` ($7)** (float) : défaut = **0**  (-100,100)
* **`Preview Type` ($8)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($9)** (point) : position = 0,0
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2023/03/10.
