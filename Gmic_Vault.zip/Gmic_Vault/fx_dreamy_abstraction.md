---
tags: [gmic, filter]
command: fx_dreamy_abstraction
---

# Filtre G'MIC : fx_dreamy_abstraction

## Structure de la commande
```text
fx_dreamy_abstraction:
    1_edge_threshold = $1
    2_smoothness = $2
    3_blend_mode = $3
    4_opacity = $4
    5_noise_amplitude = $5
    6_noise_type = $6
    7_noise_channel_s = $7
    8_blend_mode = $8
    9_opacity = $9
    11_blur_strength = $10
    12_sharpen_radius_factor = $11
    13_amount_factor = $12
    14_threshold = $13
    15_constraint_radius_factor = $14
    16_overshoot_factor = $15
    17_sharpen_channel_s = $16
    18_value_action = $17
    19_antialias = $18
    20_size = $19
    21_intensity = $20
    22_darken = $21
    23_saturation = $22
    24_26_preview_type = $23
    preview_split_x = $24
    preview_split_y = $25
```
## Définition des variables
(Note) : A less-aggressive alternative to the Painting filter. Yes, 'Joan Rake' made a filter that isn't aggressive! What kind of digital paint has she been sniffing?
(Note) : Segmentation
* **`1. Edge Threshold` ($1)** (float) : défaut = **2**  (0,30)
* **`2. Smoothness` ($2)** (float) : défaut = **1**  (0,10)
* **`3. Blend Mode` ($3)** (choice) : choix possibles => Add, Alpha, And, Average, Blue, Burn, Darken, Difference, Divide, Dodge, Exclusion, Freeze, Grainextract, Grainmerge, Green, Hardlight, Hardmix, Hue, Interpolation, Lighten, Lightness, Linearburn, Linearlight, Luminance, Multiply, Negation, Or, Overlay, Pinlight, Red, Reflect, Saturation, Screen, Shapeaverage, Softburn, Softdodge, Softlight, Stamp, Subtract, Value, Vividlight, Xor
* **`4. Opacity` ($4)** (float) : défaut = **0.5**  (0,1)
(Note) : Noise
* **`5. Noise Amplitude` ($5)** (float) : défaut = **10**  (0,100)
* **`6. Noise Type` ($6)** (choice) : choix possibles => Gaussian, Uniform, Salt and Pepper, Poisson, Rice, Spread
* **`7. Noise Channel(s)` ($7)** (choice) : choix possibles => All, RGBA [all], RGB [all], RGB [red], RGB [green], RGB [blue], RGBA [alpha], Linear RGB [all], Linear RGB [red], Linear RGB [green], Linear RGB [blue], YCbCr [luminance], YCbCr [blue-Red Chrominances], YCbCr [blue Chrominance], YCbCr [red Chrominance], YCbCr [green Chrominance], Lab [lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [hue], HSV [saturation], HSV [value], HSI [intensity], HSL [lightness], CMYK [cyan], CMYK [magenta], CMYK [yellow], CMYK [key], YIQ [luma], YIQ [chromas]
* **`8. Blend Mode` ($8)** (choice) : choix possibles => Add, Alpha, And, Average, Blue, Burn, Darken, Difference, Divide, Dodge, Exclusion, Freeze, Grainextract, Grainmerge, Green, Hardlight, Hardmix, Hue, Interpolation, Lighten, Lightness, Linearburn, Linearlight, Luminance, Multiply, Negation, Or, Overlay, Pinlight, Red, Reflect, Saturation, Screen, Shapeaverage, Softburn, Softdodge, Softlight, Stamp, Subtract, Value, Vividlight, Xor
* **`9. Opacity` ($9)** (float) : défaut = **1**  (0,1)
(Note) : Blur & Constrained Sharpen
* **`11. Blur Strength` ($10)** (float) : défaut = **3**  (0,20)
* **`12. Sharpen Radius Factor` ($11)** (float) : défaut = **1**  (0,5)
* **`13. Amount Factor` ($12)** (float) : défaut = **1**  (0,5)
* **`14. Threshold` ($13)** (float) : défaut = **1**  (0,5)
* **`15. Constraint Radius Factor` ($14)** (float) : défaut = **1**  (0,5)
* **`16. Overshoot Factor` ($15)** (float) : défaut = **1**  (0,20)
* **`17. Sharpen Channel(s)` ($16)** (choice) : choix possibles => All, RGBA [all], RGB [all], RGB [red], RGB [green], RGB [blue], RGBA [alpha], Linear RGB [all], Linear RGB [red], Linear RGB [green], Linear RGB [blue], YCbCr [luminance], YCbCr [blue-Red Chrominances], YCbCr [blue Chrominance], YCbCr [red Chrominance], YCbCr [green Chrominance], Lab [lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [hue], HSV [saturation], HSV [value], HSI [intensity], HSL [lightness], CMYK [cyan], CMYK [magenta], CMYK [yellow], CMYK [key]
* **`18. Value Action` ($17)** (choice) : choix possibles => None, Cut, Normalize
* **`19. Antialias` ($18)** (float) : défaut = **25**  (0,100)
(Note) : Glow
* **`20. Size` ($19)** (float) : défaut = **5**  (0,50)
* **`21. Intensity` ($20)** (float) : défaut = **1**  (0,3)
* **`22. Darken` ($21)** (float) : défaut = **0**  (0,1)
* **`23. Saturation` ($22)** (float) : défaut = **1.5**  (0,4)
* **`24-26. Preview Type` ($23)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($24)** (point) : position = 0,0
