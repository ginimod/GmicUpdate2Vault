---
tags: [gmic, filter]
command: fx_blend_seamless
---

# Filtre G'MIC : fx_blend_seamless

## Structure de la commande
```text
fx_blend_seamless:
    mixed_mode = $1
    inner_fading = $2
    outer_fading = $3
    color_space = $4
    output_as_separate_layers = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Blends a source into a target layer seamlessly (Poisson blending). 
* **`Mixed Mode` ($1)** (bool) : par défaut = Faux (0)
* **`Inner Fading` ($2)** (float) : défaut = **0**  (0,100)
* **`Outer Fading` ($3)** (float) : défaut = **25**  (0,100)
* **`Color Space` ($4)** (choice) : choix possibles => SRGB, Linear RGB, Lab
* **`Output as Separate Layers` ($5)** (bool) : par défaut = Faux (0)
(Note) : Note: This filter needs at least two layers to work properly. Set the Input layers option to handle multiple input layers. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2014/05/04.
