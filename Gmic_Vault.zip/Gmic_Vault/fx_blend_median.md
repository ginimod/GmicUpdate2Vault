---
tags: [gmic, filter]
command: fx_blend_median
---

# Filtre G'MIC : fx_blend_median

## Structure de la commande
```text
fx_blend_median:
    color_space = $1
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Computes the median pixel value across layers (removes ghosts). 
* **`Color Space` ($1)** (choice) : choix possibles => SRGB, Linear RGB, Lab
(Note) : Note: This filter needs at least two layers to work properly. Set the Input layers option to handle multiple input layers. 
(Note) : Authors: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a> and Iain Fergusson.       Latest Update: 2014/12/16.
