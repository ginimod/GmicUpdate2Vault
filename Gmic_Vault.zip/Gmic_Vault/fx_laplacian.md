---
tags: [gmic, filter]
command: fx_laplacian
---

# Filtre G'MIC : fx_laplacian

## Structure de la commande
```text
fx_laplacian:
    smoothness = $1
    min_threshold = $2
    max_threshold = $3
    absolute_value = $4
    negative_colors = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Computes the Laplacian of the image (second derivative). 
* **`Smoothness` ($1)** (float) : défaut = **0**  (0,10)
* **`Min Threshold (%)` ($2)** (float) : défaut = **0**  (0,100)
* **`Max Threshold (%)` ($3)** (float) : défaut = **100**  (0,100)
* **`Absolute Value` ($4)** (bool) : par défaut = Faux (0)
* **`Negative Colors` ($5)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
