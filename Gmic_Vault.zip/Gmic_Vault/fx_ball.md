---
tags: [gmic, filter]
command: fx_ball
---

# Filtre G'MIC : fx_ball

## Structure de la commande
```text
fx_ball:
    radius = $1
    ambient_light = $5
    diffuse_light = $6
    specular_light = $7
    shininess = $8
    light_x = $9
    light_y = $10
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Renders a 3D sphere/ball. 
* **`Radius` ($1)** (int) : défaut = **200**  (1,1024)
* **`Color` ($2)** (color) : défaut = 255,0,255
* **`Ambient Light` ($3)** (float) : défaut = **0.25**  (0,2)
* **`Diffuse Light` ($4)** (float) : défaut = **1**  (0,2)
* **`Specular Light` ($5)** (float) : défaut = **1**  (0,2)
* **`Shininess` ($6)** (float) : défaut = **20**  (0,100)
* **`Light` ($7)** (point) : position = 0,0
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2024/12/17.
