---
tags: [gmic, filter]
command: fx_balance_gamma
---

# Filtre G'MIC : fx_balance_gamma

## Structure de la commande
```text
fx_balance_gamma:
    stretch_colors = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adjusts the color balance. 
* **`Neutral Color` ($1)** (color) : défaut = 128,128,128
* **`Stretch Colors` ($2)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2011/01/07.
