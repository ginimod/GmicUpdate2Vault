---
tags: [gmic, filter]
command: fx_layer_cake
---

# Filtre G'MIC : fx_layer_cake

## Structure de la commande
```text
fx_layer_cake:
    iterations = $1
    angle_at_centre = $2
    angle_times_iteration = $3
    size = $4
    centre_x = $5
    centre_y = $6
    boundary = $7
    interpolation = $8
    blur = $9
    anti_alias_amplitude = $10
    edge_threshold = $11
    smoothness = $12
    output_layers = $13
    preview_type = $14
    preview_split_x = $15
    preview_split_y = $16
```
## Définition des variables
(Note) : Splits image into annular or circular layers and rotates each layer. Based on <a href="https://forums.getpaint.net/topic/26566-layer-cake-plugin/">the Paint.NET plugin</a>.
* **`Iterations` ($1)** (int) : défaut = **4**  (1,32)
* **`Angle at Centre` ($2)** (float) : défaut = **360**  (-1440,1440)
* **`Angle Times Iteration` ($3)** (bool) : par défaut = Faux (0)
* **`Size` ($4)** (float) : défaut = **75**  (0,200)
* **`Centre` ($5)** (point) : position = 0,0
* **`Boundary` ($6)** (choice) : choix possibles => None, Nearest, Periodic, Mirror
* **`Interpolation` ($7)** (choice) : choix possibles => None, Linear, Bicubic
* **`Blur` ($8)** (float) : défaut = **0**  (0,200)
* **`Anti-Alias Amplitude` ($9)** (float) : défaut = **30**  (0,100)
* **`Edge Threshold (%)` ($10)** (float) : défaut = **0**  (0,100)
* **`Smoothness` ($11)** (float) : défaut = **3**  (0,10)
* **`Output Layers` ($12)** (choice) : choix possibles => Off, Hollow, Filled
* **`Preview Type` ($13)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($14)** (point) : position = 0,0
