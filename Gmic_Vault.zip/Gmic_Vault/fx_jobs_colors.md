---
tags: [gmic, filter]
command: fx_jobs_colors
---

# Filtre G'MIC : fx_jobs_colors

## Structure de la commande
```text
fx_jobs_colors:
    gamma = $1
    equalize = $2
    preview_type = $3
```
## Définition des variables
* **`Gamma` ($1)** (float) : défaut = **0**  (-2,2)
* **`Equalize` ($2)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($3)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author: Oberon Leung.      Latest update: 2014/25/01.
