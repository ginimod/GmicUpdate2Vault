---
tags: [gmic, filter]
command: fx_reaction_diffusion
---

# Filtre G'MIC : fx_reaction_diffusion

## Structure de la commande
```text
fx_reaction_diffusion:
    iterations = $1
    size = $2
    mode = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates a Turing reaction-diffusion pattern. 
* **`Iterations` ($1)** (int) : défaut = **5**  (1,10)
* **`Size` ($2)** (float) : défaut = **5**  (0,20)
* **`Mode` ($3)** (choice) : choix possibles => Monochrome, Monochrome + Alpha, RGB Colors, RGB Colors + Alpha
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2024/01/14.
