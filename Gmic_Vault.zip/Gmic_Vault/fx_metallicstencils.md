---
tags: [gmic, filter]
command: fx_metallicstencils
---

# Filtre G'MIC : fx_metallicstencils

## Structure de la commande
```text
fx_metallicstencils:
    set_mode = $1
    preview_type = $2
```
## Définition des variables
* **`Set Mode` ($1)** (choice) : choix possibles => Darken, Lighten, Overlay
* **`Preview Type` ($2)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author: PhotoComix,a hack of a Samj filter.      Latest update : 2012/03/10.
