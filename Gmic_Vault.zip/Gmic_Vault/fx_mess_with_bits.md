---
tags: [gmic, filter]
command: fx_mess_with_bits
---

# Filtre G'MIC : fx_mess_with_bits

## Structure de la commande
```text
fx_mess_with_bits:
    pre_normalize = $1
    smoothness = $2
    multiplier = $3
    reversing = $4
    bit_masking_start = $5
    bit_masking_end = $6
    opacity = $7
    channel_s = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Corrupts the image by flipping bits in the pixel data. 
(Note) : Input processing:
* **`Pre-Normalize` ($1)** (bool) : par défaut = Faux (0)
* **`Smoothness (%)` ($2)** (float) : défaut = **15**  (0,100)
* **`Multiplier` ($3)** (int) : défaut = **1**  (1,256)
(Note) : Output processing:
* **`Reversing` ($4)** (choice) : choix possibles => None, Reverse Bits, Reverse Bytes
* **`Bit Masking (Start)` ($5)** (int) : défaut = **0**  (0,15)
* **`Bit Masking (End)` ($6)** (int) : défaut = **15**  (0,15)
* **`Opacity (%)` ($7)** (float) : défaut = **100**  (0,100)
* **`Channel(s)` ($8)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2019/01/16.
