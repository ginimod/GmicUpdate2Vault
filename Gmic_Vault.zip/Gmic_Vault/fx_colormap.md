---
tags: [gmic, filter]
command: fx_colormap
---

# Filtre G'MIC : fx_colormap

## Structure de la commande
```text
fx_colormap:
    colormap = $1
    dithering = $2
    number_of_tones = $3
    number_of_colors = $4
    preview_type = $29
    preview_split_x = $30
    preview_split_y = $31
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Remaps image colors to a fixed palette. 
* **`Colormap` ($1)** (choice) : choix possibles => Adaptive, Custom, Standard (256), HSV (256), Lines (256), Hot (256), Cool (256), Jet (256), Flag (256), Cube (256)
* **`Dithering` ($2)** (float) : défaut = **1**  (0,1)
* **`Number of Tones` ($3)** (int) : défaut = **32**  (2,256)
* **`Number of Colors` ($4)** (int) : défaut = **8**  (2,8)
* **`1st Color` ($5)** (color) : défaut = 0,0,0
* **`2nd Color` ($6)** (color) : défaut = 255,255,255
* **`3rd Color` ($7)** (color) : défaut = 255,0,0
* **`4th Color` ($8)** (color) : défaut = 0,255,0
* **`5th Color` ($9)** (color) : défaut = 0,0,255
* **`6th Color` ($10)** (color) : défaut = 255,255,0
* **`7th Color` ($11)** (color) : défaut = 255,0,255
* **`8th Color` ($12)** (color) : défaut = 0,255,255
* **`Preview Type` ($13)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($14)** (point) : position = 0,0
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2011/12/27.
