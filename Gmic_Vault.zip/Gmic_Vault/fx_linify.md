---
tags: [gmic, filter]
command: fx_linify
---

# Filtre G'MIC : fx_linify

## Structure de la commande
```text
fx_linify:
    density = $1
    spreading = $2
    resolution = $3
    line_opacity = $4
    line_precision = $5
    color_mode = $6
    preview_progression_while_running = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Reconstructs the image using only straight lines. 
* **`Density` ($1)** (float) : défaut = **40**  (0,100)
* **`Spreading` ($2)** (float) : défaut = **2**  (0,10)
* **`Resolution (%)` ($3)** (float) : défaut = **40**  (0,100)
* **`Line Opacity` ($4)** (float) : défaut = **10**  (0,30)
* **`Line Precision` ($5)** (int) : défaut = **24**  (1,128)
* **`Color Mode` ($6)** (choice) : choix possibles => Subtractive, Additive
* **`Preview Progression While Running` ($7)** (bool) : par défaut = Faux (0)
(Note) : Note:

 - This filter is our own implementation of the algorithm proposed on the webpage <a href="http://linify.me">http://linify.me</a>.
 - This filter is quite resource-intensive, so please be patient when running it.
 - It actually renders better when applied to small images (&lt;1024). 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2017/11/21.
