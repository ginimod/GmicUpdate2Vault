---
tags: [gmic, filter]
command: fx_gcd_dither_srgb
---

# Filtre G'MIC : fx_gcd_dither_srgb

## Structure de la commande
```text
fx_gcd_dither_srgb:
    levels = $1
    luminance = $2
```
## Définition des variables
(Note) : Dither sRGB image with selected levels per channel
* **`Levels` ($1)** (int) : défaut = **2**  (2,16)
* **`Luminance` ($2)** (bool) : par défaut = Faux (0)
(Note) : Author : Garagecoder.      Latest update : 2021/10/17.
