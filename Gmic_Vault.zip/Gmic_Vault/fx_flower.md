---
tags: [gmic, filter]
command: fx_flower
---

# Filtre G'MIC : fx_flower

## Structure de la commande
```text
fx_flower:
    center_x = $1
    center_y = $2
    amplitude_angle_x = $3
    amplitude_angle_y = $4
    petals = $5
    offset = $6
    boundary = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Warps the image into a flower-like shape. 
* **`Center (%)` ($1)** (point) : position = 0,0
* **`Amplitude / Angle` ($2)** (point) : position = 0,0
* **`Petals` ($3)** (int) : défaut = **6**  (2,20)
* **`Offset (%)` ($4)** (float) : défaut = **0**  (0,100)
* **`Boundary` ($5)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
