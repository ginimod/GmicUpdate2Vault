---
tags: [gmic, filter]
command: fx_blackandwhite
---

# Filtre G'MIC : fx_blackandwhite

## Structure de la commande
```text
fx_blackandwhite:
    red_level = $1
    red_smoothness = $2
    green_level = $3
    green_smoothness = $4
    blue_level = $5
    blue_smoothness = $6
    brightness = $7
    contrast = $8
    gamma = $9
    hue = $10
    saturation = $11
    grain_shadows = $12
    grain_midtones = $13
    grain_highlights = $14
    grain_tone_fading = $15
    grain_scale = $16
    grain_type = $17
    local_contrast = $18
    radius = $19
    contrast_smoothness = $20
    pseudo_gray_dithering = $21
    use_maximum_tones = $22
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Converts color images to grayscale with various mixing options. 
* **`Red Level` ($1)** (float) : défaut = **0.299**  (0,1)
* **`Red Smoothness` ($2)** (float) : défaut = **0**  (0,10)
* **`Green Level` ($3)** (float) : défaut = **0.587**  (0,1)
* **`Green Smoothness` ($4)** (float) : défaut = **0**  (0,10)
* **`Blue Level` ($5)** (float) : défaut = **0.114**  (0,1)
* **`Blue Smoothness` ($6)** (float) : défaut = **0**  (0,10)
* **`Brightness (%)` ($7)** (float) : défaut = **0**  (-100,100)
* **`Contrast (%)` ($8)** (float) : défaut = **0**  (-100,100)
* **`Gamma (%)` ($9)** (float) : défaut = **0**  (-100,100)
* **`Hue (%)` ($10)** (float) : défaut = **0**  (-100,100)
* **`Saturation (%)` ($11)** (float) : défaut = **0**  (-100,100)
* **`Grain (Shadows)` ($12)** (float) : défaut = **0**  (0,200)
* **`Grain (Midtones)` ($13)** (float) : défaut = **0**  (0,200)
* **`Grain (Highlights)` ($14)** (float) : défaut = **0**  (0,200)
* **`Grain Tone Fading` ($15)** (float) : défaut = **2**  (0,10)
* **`Grain Scale` ($16)** (float) : défaut = **0**  (0,3)
* **`Grain Type` ($17)** (choice) : choix possibles => Gaussian, Uniform, Salt and Pepper, Poisson
* **`Local Contrast` ($18)** (float) : défaut = **0**  (0,60)
* **`Radius` ($19)** (int) : défaut = **16**  (1,512)
* **`Contrast Smoothness` ($20)** (float) : défaut = **4**  (0,10)
* **`Pseudo-Gray Dithering` ($21)** (int) : défaut = **0**  (0,5)
* **`Use Maximum Tones` ($22)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2013/02/20.
