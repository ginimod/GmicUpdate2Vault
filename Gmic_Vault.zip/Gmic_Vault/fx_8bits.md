---
tags: [gmic, filter]
command: fx_8bits
---

# Filtre G'MIC : fx_8bits

## Structure de la commande
```text
fx_8bits:
    scale = $1
    dithering = $2
    levels = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Reduces color depth to simulate 8-bit graphics. 
* **`Scale` ($1)** (float) : défaut = **25**  (1,100)
* **`Dithering` ($2)** (float) : défaut = **800**  (0,10000)
* **`Levels` ($3)** (int) : défaut = **16**  (2,256)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2011/02/11.
