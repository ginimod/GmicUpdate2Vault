---
tags: [gmic, filter]
command: fx_jfif_bomb
---

# Filtre G'MIC : fx_jfif_bomb

## Structure de la commande
```text
fx_jfif_bomb:
    quality = $2
    mesh_x = $3
    mesh_y = $4
    mesh_smoothness = $5
    contrast_scheme = $6
    mesh_contrast = $7
    scale_x = $8
    scale_y = $9
    interpolation = $10
    normalize = $11
    output_mesh = $12
    solidify_alpha = $13
    smoothness = $14
    regularization = $15
    regularization_iterations = $16
    dilation_erosion = $17
    colorspace = $18
```
## Définition des variables
(Note) : OI! TRY SMOOTHING THIS!
(Note) : Adds JPEG artefacts and then self-bomb-blends. Use grid interpolation with scale factors above 1 to destroy the results even more.
* **`Quality (%)` ($1)** (int) : défaut = **50**  (1,100)
* **`Mesh X` ($2)** (int) : défaut = **16**  (1,256)
* **`Mesh Y` ($3)** (int) : défaut = **16**  (1,256)
* **`Mesh Smoothness` ($4)** (float) : défaut = **0.5**  (0,10)
* **`Contrast Scheme` ($5)** (choice) : choix possibles => Arctan, Clip, Power
* **`Mesh Contrast` ($6)** (float) : défaut = **75**  (0,100)
* **`Scale X` ($7)** (float) : défaut = **1**  (0.05,16)
* **`Scale Y` ($8)** (float) : défaut = **1**  (0.05,16)
* **`Interpolation` ($9)** (choice) : choix possibles => None, Nearest, Average, Bilinear, Grid, Bicubic
* **`Normalize` ($10)** (bool) : par défaut = Faux (0)
* **`Output Mesh` ($11)** (bool) : par défaut = Faux (0)
* **`Solidify Alpha` ($12)** (bool) : par défaut = Faux (0)
* **`Smoothness (%)` ($13)** (float) : défaut = **75**  (0,100)
* **`Regularization` ($14)** (choice) : choix possibles => Isotropic, Delaunay-Oriented, Edge-Oriented
* **`Regularization Iterations` ($15)** (int) : défaut = **20**  (0,100)
* **`Dilation / Erosion` ($16)** (int) : défaut = **0**  (-20,20)
* **`Colorspace` ($17)** (choice) : choix possibles => SRGB, Linear RGB
