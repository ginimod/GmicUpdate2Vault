---
tags: [gmic, filter]
command: fx_dct_fsu
---

# Filtre G'MIC : fx_dct_fsu

## Structure de la commande
```text
fx_dct_fsu:
    1_operation = $1
    2_x = $2
    3_y = $3
    4_5_shift_before_x = $4
    4_5_shift_before_y = $5
    6_7_shift_after_x = $6
    6_7_shift_after_y = $7
    8_absolute = $8
    9_normalise = $9
    10_colour_space = $10
    11_alpha = $11
    preview_type = $12
    preview_split_x = $13
    preview_split_y = $14
```
## Définition des variables
* **`1. Operation` ($1)** (choice) : choix possibles => Low Pass 1, Low Pass 2, High Pass 1, High Pass 2, Isolate, Plaid, Plaid LP, Plaid HP, Randomised Spread, Randomised Spread [intense]
* **`2. X (%)` ($2)** (float) : défaut = **50**  (0,100)
* **`3. Y (%)` ($3)** (float) : défaut = **50**  (0,100)
* **`4-5. Shift Before` ($4)** (point) : position = 0,0
* **`6-7. Shift After` ($5)** (point) : position = 0,0
* **`8. Absolute` ($6)** (bool) : par défaut = Faux (0)
* **`9. Normalise` ($7)** (bool) : par défaut = Faux (0)
* **`10. Colour Space` ($8)** (choice) : choix possibles => RGB, SRGB, CMY, RYB, Ohta8, Ohta, YES8, YES, Kodak 1-8, Kodak1, Lab8, Lab, Oklab, LUV, Jzazbz, YIQ8, YIQ, YUV8, YUV, YCbCr, YCbCrGLIC, YCbCrJPEG, YDbDr, XYZ8, XYZ, HSV8, HSV, HSL8, HSL, HSI8, HSI, LCH8, LCH, JzCzHz, HCY
* **`11. Alpha` ($9)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($10)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($11)** (point) : position = 0,0
