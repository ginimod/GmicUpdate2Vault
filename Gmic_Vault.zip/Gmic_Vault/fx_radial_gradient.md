---
tags: [gmic, filter]
command: fx_radial_gradient
---

# Filtre G'MIC : fx_radial_gradient

## Structure de la commande
```text
fx_radial_gradient:
    swap_colors = $9
    fade_start = $10
    fade_end = $11
    quantization = $12
    center_x = $13
    center_y = $14
    color_space = $15
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a circular radial color gradient. 
* **`Starting Color` ($1)** (color) : défaut = 0,0,0,255
* **`Ending Color` ($2)** (color) : défaut = 255,255,255,255
* **`Swap Colors` ($3)** (bool) : par défaut = Faux (0)
* **`Fade Start` ($4)** (float) : défaut = **0**  (0,100)
* **`Fade End` ($5)** (float) : défaut = **100**  (0,100)
* **`Quantization` ($6)** (int) : défaut = **0**  (0,64)
* **`Center (%)` ($7)** (point) : position = 0,0
* **`Color Space` ($8)** (choice) : choix possibles => SRGB, Linear RGB, Lab
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2015/06/29.
