---
tags: [gmic, filter]
command: fx_pack
---

# Filtre G'MIC : fx_pack

## Structure de la commande
```text
fx_pack:
    order_by = $1
    tends_to_be_square = $2
    force_transparency = $3
    add_image_label = $4
    font_height_px = $5
    font_colors = $6
    output_coordinates_file = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Packs multiple layers into a sprite sheet. 
* **`Order By` ($1)** (choice) : choix possibles => Width, Height, Maximum Dimension, Area, Name
* **`Tends to Be Square` ($2)** (bool) : par défaut = Faux (0)
* **`Force Transparency` ($3)** (bool) : par défaut = Faux (0)
* **`Add Image Label` ($4)** (bool) : par défaut = Faux (0)
* **`Font Height (px)` ($5)** (float) : défaut = **16**  (0,64)
* **`Font Colors` ($6)** (choice) : choix possibles => White on Black, Black on White
* **`Output Coordinates File` ($7)** (bool) : par défaut = Faux (0)
(Note) : This filter tries to pack all input layers into a single image, while trying to minimize the empty areas. This problem being NP-hard, the algorithm finds (of course) a non-optimal, but often acceptable solution to this packing problem.
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2019/03/20.
