---
tags: [gmic, filter]
command: fx_recolorize
---

# Filtre G'MIC : fx_recolorize

## Structure de la commande
```text
fx_recolorize:
    smoothness = $1
    anisotropy = $2
    output_mode = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Colorizes B&W photos. 
* **`Smoothness` ($1)** (int) : défaut = **2**  (0,6)
* **`Anisotropy` ($2)** (float) : défaut = **0.2**  (0,1)
* **`Output Mode` ($3)** (choice) : choix possibles => Merge Brightness / Colors, Split Brightness / Colors
(Note) : Note: This filter needs two layers to work properly. The bottom layer must be a B&W image, while the top layer contains color patches that will be extrapolated in a smart way (edge-directed) to fill the entire image. At the end, you get a completely recolored image.
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2013/01/16.
