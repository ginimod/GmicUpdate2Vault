---
tags: [gmic, filter]
command: fx_rep_blur_cs
---

# Filtre G'MIC : fx_rep_blur_cs

## Structure de la commande
```text
fx_rep_blur_cs:
    xy_amplitude = $1
    x_amplitude = $2
    y_amplitude = $3
    boundary = $4
    color_space = $5
    preview_type = $6
    preview_split_x = $7
    preview_split_y = $8
```
## Définition des variables
* **`XY-Amplitude` ($1)** (float) : défaut = **3**  (0,100)
* **`X-Amplitude` ($2)** (float) : défaut = **0**  (0,20)
* **`Y-Amplitude` ($3)** (float) : défaut = **0**  (0,20)
* **`Boundary` ($4)** (choice) : choix possibles => Black, Nearest
* **`Color Space` ($5)** (choice) : choix possibles => RGB, SRGB, RYB, CMY, CMYKA, HCY, HSI, HSL, HSV, LAB, LCH
* **`Preview Type` ($6)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($7)** (point) : position = 0,0
(Note) : Author: Reptorian. Latest Update: 2020/10/04.
