---
tags: [gmic, filter]
command: fx_equalize_details
---

# Filtre G'MIC : fx_equalize_details

## Structure de la commande
```text
fx_equalize_details:
    base_scale = $1
    detail_scale = $2
    threshold = $3
    smoothness = $4
    smoothness_type = $5
    gain = $6
    threshold = $7
    smoothness = $8
    smoothness_type = $9
    gain = $10
    threshold = $11
    smoothness = $12
    smoothness_type = $13
    gain = $14
    threshold = $15
    smoothness = $16
    smoothness_type = $17
    gain = $18
    channel_s = $19
    value_action = $20
    parallel_processing = $21
    spatial_overlap = $22
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adjusts image details at different spatial scales (frequencies). 
* **`Base Scale` ($1)** (float) : défaut = **5**  (0,15)
* **`Detail Scale` ($2)** (float) : défaut = **0.5**  (0,5)
(Note) : Coarse scale:
* **`Threshold` ($3)** (float) : défaut = **0**  (0,10)
* **`Smoothness` ($4)** (float) : défaut = **0**  (0,10)
* **`Smoothness Type` ($5)** (choice) : choix possibles => Gaussian, Bilateral, Diffusion
* **`Gain` ($6)** (float) : défaut = **0**  (-4,4)
(Note) : Medium scale:
* **`Threshold` ($7)** (float) : défaut = **0**  (0,10)
* **`Smoothness` ($8)** (float) : défaut = **0**  (0,10)
* **`Smoothness Type` ($9)** (choice) : choix possibles => Gaussian, Bilateral, Diffusion
* **`Gain` ($10)** (float) : défaut = **0**  (-4,4)
(Note) : Small scale:
* **`Threshold` ($11)** (float) : défaut = **0**  (0,10)
* **`Smoothness` ($12)** (float) : défaut = **0**  (0,10)
* **`Smoothness Type` ($13)** (choice) : choix possibles => Gaussian, Bilateral, Diffusion
* **`Gain` ($14)** (float) : défaut = **0**  (-4,4)
(Note) : Fine scale:
* **`Threshold` ($15)** (float) : défaut = **0**  (0,10)
* **`Smoothness` ($16)** (float) : défaut = **0**  (0,10)
* **`Smoothness Type` ($17)** (choice) : choix possibles => Gaussian, Bilateral, Diffusion
* **`Gain` ($18)** (float) : défaut = **0**  (-4,4)
* **`Channel(s)` ($19)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
* **`Value Action` ($20)** (choice) : choix possibles => None, Cut, Normalize
* **`Parallel Processing` ($21)** (choice) : choix possibles => Auto, One Thread, Two Threads, Four Threads, Eight Threads, Sixteen Threads
* **`Spatial Overlap` ($22)** (int) : défaut = **32**  (0,256)
(Note) : Author: Jérome Boulanger and <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.       Latest Update: 2015/11/11.
