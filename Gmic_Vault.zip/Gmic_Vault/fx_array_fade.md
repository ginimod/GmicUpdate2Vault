---
tags: [gmic, filter]
command: fx_array_fade
---

# Filtre G'MIC : fx_array_fade

## Structure de la commande
```text
fx_array_fade:
    x_tiles = $1
    y_tiles = $2
    x_offset = $3
    y_offset = $4
    fade_start = $5
    fade_end = $6
    mirror = $7
    size = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Creates a tiled grid of image with fading opacity. 
* **`X-Tiles` ($1)** (int) : défaut = **2**  (1,10)
* **`Y-Tiles` ($2)** (int) : défaut = **2**  (1,10)
* **`X-Offset (%)` ($3)** (float) : défaut = **0**  (0,100)
* **`Y-Offset (%)` ($4)** (float) : défaut = **0**  (0,100)
* **`Fade Start (%)` ($5)** (float) : défaut = **80**  (1,100)
* **`Fade End (%)` ($6)** (float) : défaut = **90**  (1,100)
* **`Mirror` ($7)** (choice) : choix possibles => None, X-Axis, Y-Axis, XY-Axes
* **`Size` ($8)** (choice) : choix possibles => Shrink, Expand, Repeat [Memory Consuming!]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
