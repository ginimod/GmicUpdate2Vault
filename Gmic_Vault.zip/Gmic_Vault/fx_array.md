---
tags: [gmic, filter]
command: fx_array
---

# Filtre G'MIC : fx_array

## Structure de la commande
```text
fx_array:
    x_tiles = $1
    y_tiles = $2
    x_offset = $3
    y_offset = $4
    mirror = $5
    size = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Creates a standard grid of identical image tiles. 
* **`X-Tiles` ($1)** (int) : défaut = **2**  (1,10)
* **`Y-Tiles` ($2)** (int) : défaut = **2**  (1,10)
* **`X-Offset (%)` ($3)** (float) : défaut = **0**  (0,100)
* **`Y-Offset (%)` ($4)** (float) : défaut = **0**  (0,100)
* **`Mirror` ($5)** (choice) : choix possibles => None, X-Axis, Y-Axis, XY-Axes
* **`Size` ($6)** (choice) : choix possibles => Shrink, Expand, Repeat [Memory Consuming!]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
