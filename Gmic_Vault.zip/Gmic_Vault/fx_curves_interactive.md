---
tags: [gmic, filter]
command: fx_curves_interactive
---

# Filtre G'MIC : fx_curves_interactive

## Structure de la commande
```text
fx_curves_interactive:
    color_space = $1
    output_preset_as_a_haldclut_layer = $2
    apply_transformation_from = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adjusts tonal response using interactive curves. 
* **`Color Space` ($1)** (choice) : choix possibles => RGB, CMY, CMYK, HSI, HSL, HSV, Lab, Lch, YCbCr
* **`Output Preset as a HaldCLUT Layer` ($2)** (choice) : choix possibles => Disable, Lowres CLUT, Highres CLUT
* **`Apply Transformation From` ($3)** (choice) : choix possibles => New Curves [Interactive], Curves Previously Defined
(Note) : Description:
 This filter lets you apply color curves on your images, in many different color spaces. Click on the Apply or OK buttons below to open the G'MIC interactive windows and start building your color curves. When you're done, exit the main image window: your modified result will be transferred back to the host software.

 Once you've set curves, you can save them by pressing the Add to faves button below the filter tree. To clear control points for your curves, click on the Reset button above. 
(Note) : Interactions:
 Use the following actions in the interactive windows to manage your colorization:

 - Left mouse button on a curve creates a new color control point (or move an existing one).
 - Right mouse button on a control point deletes it.
 - Left mouse button on the main image window shows the initial image until button is released.
 - Right mouse button on the main image window adds a keypoint to all curves from picked color.
 - Key R on a curve resets it.
 - Keys CTRL+D increase window size.
 - Keys CTRL+C decrease window size.
 - Keys CTRL+R resets window size.
 - Keys ESC, Q or RETURN close the current window. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 09/28/2014.
