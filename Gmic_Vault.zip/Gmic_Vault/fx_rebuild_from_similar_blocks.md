---
tags: [gmic, filter]
command: fx_rebuild_from_similar_blocks
---

# Filtre G'MIC : fx_rebuild_from_similar_blocks

## Structure de la commande
```text
fx_rebuild_from_similar_blocks:
    block_size = $1
    regularization_factor = $2
    luminance_factor = $3
    norm_type = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Reconstructs the image using self-similarity (blocky effect). 
* **`Block Size (%)` ($1)** (float) : défaut = **5**  (2,50)
* **`Regularization Factor` ($2)** (float) : défaut = **10**  (0,20)
* **`Luminance Factor` ($3)** (float) : défaut = **0.75**  (0,3)
* **`Norm Type` ($4)** (choice) : choix possibles => L1, L2
(Note) : This filter subdivides the image into blocks, and replace each block by the most similar block found in the other blocks.
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2020/09/17.
