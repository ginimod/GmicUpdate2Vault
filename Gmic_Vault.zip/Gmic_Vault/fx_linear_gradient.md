---
tags: [gmic, filter]
command: fx_linear_gradient
---

# Filtre G'MIC : fx_linear_gradient

## Structure de la commande
```text
fx_linear_gradient:
    swap_colors = $9
    angle_deg = $10
    fade_start = $11
    fade_end = $12
    quantization = $13
    color_space = $14
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a standard linear color gradient. 
* **`Starting Color` ($1)** (color) : défaut = 0,0,0,255
* **`Ending Color` ($2)** (color) : défaut = 255,255,255,255
* **`Swap Colors` ($3)** (bool) : par défaut = Faux (0)
* **`Angle (deg.)` ($4)** (float) : défaut = **45**  (0,360)
* **`Fade Start (%)` ($5)** (float) : défaut = **0**  (0,100)
* **`Fade End (%)` ($6)** (float) : défaut = **100**  (0,100)
* **`Quantization` ($7)** (int) : défaut = **0**  (0,64)
* **`Color Space` ($8)** (choice) : choix possibles => SRGB, Linear RGB, Lab
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2025/10/20.
