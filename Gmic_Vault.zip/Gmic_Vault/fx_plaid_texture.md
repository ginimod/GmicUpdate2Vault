---
tags: [gmic, filter]
command: fx_plaid_texture
---

# Filtre G'MIC : fx_plaid_texture

## Structure de la commande
```text
fx_plaid_texture:
    line = $1
    number_of_angles = $2
    starting_angle = $3
    angle_range = $4
    smoothness = $5
    sharpen = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generates a tartan/plaid cloth pattern. 
* **`Line` ($1)** (float) : défaut = **50**  (0,100)
* **`Number of Angles` ($2)** (int) : défaut = **2**  (1,8)
* **`Starting Angle` ($3)** (float) : défaut = **0**  (0,360)
* **`Angle Range` ($4)** (float) : défaut = **90**  (0,360)
* **`Smoothness` ($5)** (float) : défaut = **1**  (0,5)
* **`Sharpen` ($6)** (float) : défaut = **300**  (0,1000)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2011/05/16.
