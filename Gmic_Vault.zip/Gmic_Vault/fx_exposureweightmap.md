---
tags: [gmic, filter]
command: fx_ExposureWeightMap
---

# Filtre G'MIC : fx_ExposureWeightMap

## Structure de la commande
```text
fx_ExposureWeightMap:
    contrast_bias = $1
    saturation_bias = $2
    exposure_sigma = $3
    exposure_bias = $4
    blurmap = $5
    preview_type = $6
```
## Définition des variables
(Note) : Create exposure fusion weight map
(Note) : Set filter output to "New layers". Copy filter output to corresponding layer mask. Use aligned layers to combine multiple exposures.
* **`Contrast Bias` ($1)** (float) : défaut = **0.3**  (0,1)
* **`Saturation Bias` ($2)** (float) : défaut = **0.3**  (0,1)
* **`Exposure Sigma` ($3)** (float) : défaut = **0.2**  (0,1)
* **`Exposure Bias` ($4)** (float) : défaut = **0.3**  (0,1)
* **`BlurMap` ($5)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($6)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) :  Author: Arto Huotari Latest update : 2014/11/30 v2.
