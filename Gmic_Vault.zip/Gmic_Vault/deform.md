---
tags: [gmic, filter]
command: deform
---

# Filtre G'MIC : deform

## Structure de la commande
```text
deform:
    amplitude = $1
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Applies random, smooth deformations. 
* **`Amplitude` ($1)** (float) : défaut = **10**  (0,100)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
