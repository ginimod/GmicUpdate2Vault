---
tags: [gmic, filter]
command: afre_montagex
---

# Filtre G'MIC : afre_montagex

## Structure de la commande
```text
afre_montagex:
    max_per_row = $1
    spacing = $2
```
## Définition des variables
(Note) : <strong>Generate montage without resizing.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2021 Apr16.</strong>

 - Set <strong>Input layers</strong> to <strong>All</strong>.


* **`Max Per Row` ($1)** (int) : défaut = **5**  (1,25)
* **`Spacing` ($2)** (int) : défaut = **1**  (0,10)
* **`Matte Colour` ($3)** (color) : défaut = 230,255,230
