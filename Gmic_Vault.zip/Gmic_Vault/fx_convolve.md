---
tags: [gmic, filter]
command: fx_convolve
---

# Filtre G'MIC : fx_convolve

## Structure de la commande
```text
fx_convolve:
    kernel = $1
    boundary = $2
    value_range = $4
    kernel_multiplier = $5
    channel_s = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Convolves the image with a customizable kernel. 
* **`Kernel` ($1)** (choice) : choix possibles => Custom, Average 3x3, Average 5x5, Average 7x7, Average 9x9, Prewitt-X, Prewitt-Y, Sobel-X, Sobel-Y, Rotinv-X, Rotinv-Y, Laplacian, Robert Cross 1, Robert Cross 2, Impulses 5x5, Impulses 7x7, Impulses 9x9
* **`Boundary` ($2)** (choice) : choix possibles => Dirichlet, Neumann
(Note) : Note: If parameter Kernel is set to Custom, it uses the custom convolution kernel defined below. Use commas and semicolons as separators for res. matrix columns and rows. 
(Note) : Note: Kernel multiplier is useful only when parameter Value range is set to Cut.
* **`Value Range` ($3)** (choice) : choix possibles => Cut, Normalize
* **`Kernel Multiplier` ($4)** (float) : défaut = **1**  (0,50)
* **`Channel(s)` ($5)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2013/06/06.
