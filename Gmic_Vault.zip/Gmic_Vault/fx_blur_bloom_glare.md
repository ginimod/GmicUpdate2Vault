---
tags: [gmic, filter]
command: fx_blur_bloom_glare
---

# Filtre G'MIC : fx_blur_bloom_glare

## Structure de la commande
```text
fx_blur_bloom_glare:
    amplitude = $1
    ratio = $2
    iterations = $3
    operator = $4
    kernel = $5
    normalize_scales = $6
    anisotropy = $7
    angle = $8
    axis = $9
    opacity = $10
    channel_s = $11
    preview_type = $12
```
## Définition des variables
* **`Amplitude` ($1)** (float) : défaut = **1**  (0,20)
* **`Ratio` ($2)** (float) : défaut = **2**  (0,10)
* **`Iterations` ($3)** (int) : défaut = **5**  (0,200)
* **`Operator` ($4)** (choice) : choix possibles => Add, Max, Min
* **`Kernel` ($5)** (choice) : choix possibles => Quasi-Gaussian, Gaussian, Box, Triangle, Quadratic
* **`Normalize Scales` ($6)** (bool) : par défaut = Faux (0)
* **`Anisotropy` ($7)** (bool) : par défaut = Faux (0)
* **`Angle` ($8)** (float) : défaut = **0**  (0,180)
* **`Axis` ($9)** (int) : défaut = **3**  (1,20)
* **`Opacity` ($10)** (float) : défaut = **0.5**  (0,1)
(Note) : Parameters Angle, Axis and Opacity are only active when Anisotropy is checked
* **`Channel(s)` ($11)** (choice) : choix possibles => All, RGBA [all], RGB [all], RGB [red], RGB [green], RGB [blue], RGBA [alpha], Linear RGB [all], Linear RGB [red], Linear RGB [green], Linear RGB [blue], YCbCr [luminance], YCbCr [blue-Red Chrominances], YCbCr [blue Chrominance], YCbCr [red Chrominance], YCbCr [green Chrominance], Lab [lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [hue], HSV [saturation], HSV [value], HSI [intensity], HSL [lightness], CMYK [cyan], CMYK [magenta], CMYK [yellow], CMYK [key], YIQ [luma], YIQ [chromas]
* **`Preview Type` ($12)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right
(Note) : Authors: <a href="https://goo.gl/Ryf7Cv">David Tschumperlé</a>.      Latest update: 2015/03/02.
