---
tags: [gmic, filter]
command: afre_contrast
---

# Filtre G'MIC : afre_contrast

## Structure de la commande
```text
afre_contrast:
    amount = $1
    ignore_alpha = $2
```
## Définition des variables
(Note) : <strong>Enhance luminance contrast.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2020 Jan9.</strong>


* **`Amount` ($1)** (int) : défaut = **50**  (-200,200)
* **`Ignore Alpha` ($2)** (bool) : par défaut = Faux (0)
(Note) : 

<strong>Note</strong>

G'MIC's preview is inaccurate. Apply the filter and review the results in your host editor.
