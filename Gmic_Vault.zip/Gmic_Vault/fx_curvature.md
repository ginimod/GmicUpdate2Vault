---
tags: [gmic, filter]
command: fx_curvature
---

# Filtre G'MIC : fx_curvature

## Structure de la commande
```text
fx_curvature:
    smoothness = $1
    min_threshold = $2
    max_threshold = $3
    absolute_value = $4
    negative_colors = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Computes the curvature of image isophotes. 
* **`Smoothness` ($1)** (float) : défaut = **2**  (0,10)
* **`Min Threshold` ($2)** (float) : défaut = **0**  (0,100)
* **`Max Threshold` ($3)** (float) : défaut = **100**  (0,100)
* **`Absolute Value` ($4)** (bool) : par défaut = Faux (0)
* **`Negative Colors` ($5)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
