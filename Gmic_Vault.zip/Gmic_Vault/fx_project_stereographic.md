---
tags: [gmic, filter]
command: fx_project_stereographic
---

# Filtre G'MIC : fx_project_stereographic

## Structure de la commande
```text
fx_project_stereographic:
    transform = $1
    center_x = $2
    center_y = $3
    radius_angle_x = $4
    radius_angle_y = $5
    horizon_leveling_deg = $6
    left_right_blur = $7
    dilation = $8
    mirror = $9
    boundary = $10
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Applies a stereographic projection (Little Planet effect). 
* **`Transform` ($1)** (choice) : choix possibles => Direct, Inverse
* **`Center (%)` ($2)** (point) : position = 0,0
* **`Radius / Angle` ($3)** (point) : position = 0,0
* **`Horizon Leveling (deg)` ($4)** (float) : défaut = **0**  (-10,10)
* **`Left / Right Blur (%)` ($5)** (float) : défaut = **0**  (0,20)
* **`Dilation` ($6)** (float) : défaut = **0**  (-2,2)
* **`Mirror` ($7)** (choice) : choix possibles => None, X-Axis, Y-Axis, XY-Axis
* **`Boundary` ($8)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2018/07/04.
