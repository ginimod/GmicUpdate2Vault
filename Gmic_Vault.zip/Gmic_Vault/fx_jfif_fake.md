---
tags: [gmic, filter]
command: fx_jfif_fake
---

# Filtre G'MIC : fx_jfif_fake

## Structure de la commande
```text
fx_jfif_fake:
    quality = $1
    encoding = $2
    power = $3
    colour_distortion = $4
    max_tile_error_length = $5
    persistent_tile_error_power = $6
    preview_type = $7
    preview_split_x = $8
    preview_split_y = $9
```
## Définition des variables
(Note) : A fake jfif encoder.
* **`Quality (%)` ($1)** (int) : défaut = **50**  (1,100)
* **`Encoding` ($2)** (choice) : choix possibles => 442, 424, 422
(Note) : Fake Glitch
* **`Power` ($3)** (float) : défaut = **0**  (0,5)
* **`Colour Distortion` ($4)** (float) : défaut = **1.25**  (0,10)
* **`Max Tile Error Length` ($5)** (int) : défaut = **5**  (1,10)
* **`Persistent Tile Error Power` ($6)** (float) : défaut = **0.25**  (0,1)
* **`Preview Type` ($7)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($8)** (point) : position = 0,0
(Note) : Author: Joan Rake, 'borrowed' from <a href="https://goo.gl/Ryf7Cv">David Tschumperlé</a>.      Latest Update: 2017/05/07.
