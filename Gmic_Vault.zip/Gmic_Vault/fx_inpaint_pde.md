---
tags: [gmic, filter]
command: fx_inpaint_pde
---

# Filtre G'MIC : fx_inpaint_pde

## Structure de la commande
```text
fx_inpaint_pde:
    smoothness = $1
    regularization = $2
    regularization_iterations = $3
    mask_dilation = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Inpaints mask content using transport-diffusion equations. 
* **`Smoothness (%)` ($1)** (float) : défaut = **75**  (0,100)
* **`Regularization` ($2)** (choice) : choix possibles => Isotropic, Delaunay-Guided, Edge-Oriented
* **`Regularization Iterations` ($3)** (int) : défaut = **20**  (0,100)
* **`Mask Color` ($4)** (color) : défaut = 255,0,0,255
* **`Mask Dilation` ($5)** (int) : défaut = **0**  (0,32)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/04/10.
