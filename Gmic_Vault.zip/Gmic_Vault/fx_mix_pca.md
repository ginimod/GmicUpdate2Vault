---
tags: [gmic, filter]
command: fx_mix_pca
---

# Filtre G'MIC : fx_mix_pca

## Structure de la commande
```text
fx_mix_pca:
    primary_factor = $1
    primary_shift = $2
    primary_twist = $3
    primary_gamma = $4
    secondary_factor = $5
    secondary_shift = $6
    secondary_twist = $7
    secondary_gamma = $8
    tertiary_factor = $9
    tertiary_shift = $10
    tertiary_twist = $11
    tertiary_gamma = $12
    display_color_axes = $13
    preview_type = $16
    preview_split_x = $17
    preview_split_y = $18
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Mixes colors based on Principal Component Analysis. 
* **`Primary Factor` ($1)** (float) : défaut = **0**  (-1.5,1.5)
* **`Primary Shift` ($2)** (float) : défaut = **0**  (-255,255)
* **`Primary Twist` ($3)** (float) : défaut = **0**  (-180,180)
* **`Primary Gamma` ($4)** (float) : défaut = **0**  (-100,100)
* **`Secondary Factor` ($5)** (float) : défaut = **0**  (-1.5,1.5)
* **`Secondary Shift` ($6)** (float) : défaut = **0**  (-255,255)
* **`Secondary Twist` ($7)** (float) : défaut = **0**  (-180,180)
* **`Secondary Gamma` ($8)** (float) : défaut = **0**  (-100,100)
* **`Tertiary Factor` ($9)** (float) : défaut = **0**  (-1.5,1.5)
* **`Tertiary Shift` ($10)** (float) : défaut = **0**  (-255,255)
* **`Tertiary Twist` ($11)** (float) : défaut = **0**  (-180,180)
* **`Tertiary Gamma` ($12)** (float) : défaut = **0**  (-100,100)
* **`Display Color Axes` ($13)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($14)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($15)** (point) : position = 0,0
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2018/07/18.
