---
tags: [gmic, filter]
command: fx_deblur
---

# Filtre G'MIC : fx_deblur

## Structure de la commande
```text
fx_deblur:
    radius = $1
    iterations = $2
    time_step = $3
    smoothness = $4
    regularization = $5
    channel_s = $6
    parallel_processing = $7
    spatial_overlap = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Generic deblurring filter. 
* **`Radius` ($1)** (float) : défaut = **2**  (0,20)
* **`Iterations` ($2)** (int) : défaut = **10**  (0,100)
* **`Time Step` ($3)** (float) : défaut = **20**  (0,50)
* **`Smoothness` ($4)** (float) : défaut = **0.1**  (0,10)
* **`Regularization` ($5)** (choice) : choix possibles => Tikhonov, Mean Curvature, Total Variation
* **`Channel(s)` ($6)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
* **`Parallel Processing` ($7)** (choice) : choix possibles => Auto, One Thread, Two Threads, Four Threads, Eight Threads, Sixteen Threads
* **`Spatial Overlap` ($8)** (int) : défaut = **24**  (0,256)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
