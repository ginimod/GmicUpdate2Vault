---
tags: [gmic, filter]
command: fx_array_mirror
---

# Filtre G'MIC : fx_array_mirror

## Structure de la commande
```text
fx_array_mirror:
    iterations = $1
    x_offset = $2
    y_offset = $3
    array_mode = $4
    initialization = $5
    expand_size = $6
    crop = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Creates a grid where adjacent image tiles are mirrored. 
* **`Iterations` ($1)** (int) : défaut = **1**  (1,10)
* **`X-Offset (%)` ($2)** (float) : défaut = **0**  (0,100)
* **`Y-Offset (%)` ($3)** (float) : défaut = **0**  (0,100)
* **`Array Mode` ($4)** (choice) : choix possibles => X-Axis, Y-Axis, XY-Axes, 2XY-Axes
* **`Initialization` ($5)** (choice) : choix possibles => Original, Mirror X, Mirror Y, Rotate 90 Deg., Rotate 180 Deg., Rotate 270 Deg.
* **`Expand Size` ($6)** (bool) : par défaut = Faux (0)
* **`Crop (%)` ($7)** (int) : défaut = **0**  (0,100)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
