---
tags: [gmic, filter]
command: fx_pack_ellipses
---

# Filtre G'MIC : fx_pack_ellipses

## Structure de la commande
```text
fx_pack_ellipses:
    min_radius_px = $1
    max_radius_px = $2
    radius_dilation_erosion_px = $3
    min_isotropy = $4
    max_isotropy = $5
    isotropy_quantization = $6
    orientation = $7
    region_analysis_size = $8
    render_resolution = $13
    preserve_image_size = $14
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Fills the image with non-overlapping, packed ellipses. 
* **`Min Radius (px)` ($1)** (float) : défaut = **3**  (1,256)
* **`Max Radius (px)` ($2)** (float) : défaut = **20**  (1,256)
* **`Radius Dilation/Erosion (px)` ($3)** (float) : défaut = **0**  (-10,10)
* **`Min Isotropy (%)` ($4)** (float) : défaut = **30**  (0,100)
* **`Max Isotropy (%)` ($5)** (float) : défaut = **100**  (0,100)
* **`Isotropy Quantization` ($6)** (int) : défaut = **6**  (0,16)
* **`Orientation` ($7)** (choice) : choix possibles => Isotropic (Circles Only), Anisotropic (Along Contours), Anisotropic (Orthogonal to Contours)
* **`Region Analysis Size` ($8)** (int) : défaut = **3**  (0,10)
* **`Background Color` ($9)** (color) : défaut = 0,0,0,255
* **`Render Resolution` ($10)** (choice) : choix possibles => X1, X2, X3, X4, X5, X6, X7, X8
* **`Preserve Image Size` ($11)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2023/03/29.
