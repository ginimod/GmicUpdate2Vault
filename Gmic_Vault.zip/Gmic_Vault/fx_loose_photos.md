---
tags: [gmic, filter]
command: fx_loose_photos
---

# Filtre G'MIC : fx_loose_photos

## Structure de la commande
```text
fx_loose_photos:
    density = $1
    maximal_size = $2
    minimal_size_of_max = $3
    maximal_ratio = $4
    minimal_ratio_of_max = $5
    maximal_angle_deg = $6
    minimal_angle_of_max = $7
    frame_size = $8
    rotation_probability = $12
    maximal_angle_deg = $13
    minimal_angle_of_max = $14
    background_image = $19
    opacity = $20
    x_shift = $21
    y_shift = $22
    smoothness = $23
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates multiple photos thrown loosely onto a surface. 
(Note) : <span color="#EE5500">Photo geometry:</span>
* **`Density (%)` ($1)** (float) : défaut = **60**  (0,100)
* **`Maximal Size (%)` ($2)** (float) : défaut = **40**  (0,100)
* **`Minimal Size (% of Max)` ($3)** (float) : défaut = **50**  (0,100)
* **`Maximal Ratio (%)` ($4)** (float) : défaut = **100**  (0,100)
* **`Minimal Ratio (% of Max)` ($5)** (float) : défaut = **50**  (0,100)
* **`Maximal Angle (deg.)` ($6)** (float) : défaut = **360**  (0,360)
* **`Minimal Angle (% of Max)` ($7)** (float) : défaut = **0**  (0,100)
* **`Frame Size (%)` ($8)** (float) : défaut = **2**  (0,20)
* **`Frame Color` ($9)** (color) : défaut = 255,255,255
(Note) : <span color="#EE5500">Photo content:</span>
* **`Rotation Probability (%)` ($10)** (float) : défaut = **50**  (0,100)
* **`Maximal Angle (deg.)` ($11)** (float) : défaut = **25**  (0,360)
* **`Minimal Angle (% of Max)` ($12)** (float) : défaut = **0**  (0,100)
* **`Background` ($13)** (color) : défaut = 0,0,0,0
* **`Background Image (%)` ($14)** (float) : défaut = **0**  (0,100)
(Note) : <span color="#EE5500">Shadow:</span>
* **`Opacity (%)` ($15)** (float) : défaut = **50**  (0,100)
* **`X-Shift (%)` ($16)** (float) : défaut = **1**  (-10,10)
* **`Y-Shift (%)` ($17)** (float) : défaut = **1**  (-10,10)
* **`Smoothness (%)` ($18)** (float) : défaut = **1**  (0,5)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2023/09/07.
