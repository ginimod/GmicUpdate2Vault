---
tags: [gmic, filter]
command: fx_custom_code
---

# Filtre G'MIC : fx_custom_code

## Structure de la commande
```text
fx_custom_code:
    channel_s = $2
    value_action = $3
    display_debug_info_on_preview = $4
    debug_font_size = $5
    preview_type = $6
    preview_split_x = $7
    preview_split_y = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Interprets custom G'MIC code (with local preview). 
* **`Channel(s)` ($1)** (choice) : choix possibles => None (Allows Multi-Layers), All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
* **`Value Action` ($2)** (choice) : choix possibles => None, Cut, Normalize
* **`Display Debug Info on Preview` ($3)** (bool) : par défaut = Faux (0)
* **`Debug Font Size` ($4)** (choice) : choix possibles => Tiny, Small, Normal, Large
* **`Preview Type` ($5)** (choice) : choix possibles => Full (Allows Multi-Layers), Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($6)** (point) : position = 0,0
(Note) : Note:  This filter can execute any set of instructions understood by the G'MIC language interpreter. Here, you can then test some commands before creating your own G'MIC custom commands and plug-in menu entries.

 Please look at the documentation reference web page :
(Note) :  to learn more about available G'MIC commands. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/10/03.
