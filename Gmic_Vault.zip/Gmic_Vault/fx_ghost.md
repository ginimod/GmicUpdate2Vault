---
tags: [gmic, filter]
command: fx_ghost
---

# Filtre G'MIC : fx_ghost

## Structure de la commande
```text
fx_ghost:
    amplitude = $1
    smoothness = $2
    coherence = $3
    gamma = $4
    amplitude = $5
    radius = $6
    invert = $7
```
## Définition des variables
(Note) : Ghost Effect:
* **`Amplitude` ($1)** (float) : défaut = **200**  (0,1000)
* **`Smoothness` ($2)** (float) : défaut = **2**  (0,10)
* **`Coherence` ($3)** (float) : défaut = **2**  (0,10)
* **`Gamma` ($4)** (float) : défaut = **1**  (-3,3)
(Note) : Normalization:
* **`Amplitude` ($5)** (float) : défaut = **3**  (0,10)
* **`Radius` ($6)** (float) : défaut = **16**  (1,64)
* **`Invert` ($7)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2021/01/30.
