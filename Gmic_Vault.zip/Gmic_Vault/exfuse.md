---
tags: [gmic, filter]
command: exfuse
---

# Filtre G'MIC : exfuse

## Structure de la commande
```text
exfuse:
    exposure = $1
    contrast_bias = $2
    saturation_bias = $3
    exposure_sigma = $4
    exposure_bias = $5
    blur = $6
```
## Définition des variables
* **`Exposure` ($1)** (float) : défaut = **1**  (0,2)
* **`Contrast Bias` ($2)** (float) : défaut = **0.6**  (0,1)
* **`Saturation Bias` ($3)** (float) : défaut = **0**  (0,1)
* **`Exposure Sigma` ($4)** (float) : défaut = **0.5**  (0,1)
* **`Exposure Bias` ($5)** (float) : défaut = **1**  (0,1)
* **`Blur` ($6)** (float) : défaut = **5**  (0,50)
