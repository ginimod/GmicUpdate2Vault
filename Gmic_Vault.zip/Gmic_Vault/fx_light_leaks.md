---
tags: [gmic, filter]
command: fx_light_leaks
---

# Filtre G'MIC : fx_light_leaks

## Structure de la commande
```text
fx_light_leaks:
    leak_type = $1
    angle = $2
    x_scale = $3
    y_scale = $4
    hue = $5
    opacity = $6
    blend_mode = $7
    output_as_separate_layers = $8
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates light leaking into a camera body. 
* **`Leak Type` ($1)** (int) : défaut = **0**  (0,70)
* **`Angle` ($2)** (float) : défaut = **0**  (-180,180)
* **`X-Scale` ($3)** (float) : défaut = **1**  (1,10)
* **`Y-Scale` ($4)** (float) : défaut = **1**  (1,10)
* **`Hue` ($5)** (float) : défaut = **0**  (-180,180)
* **`Opacity (%)` ($6)** (float) : défaut = **85**  (0,100)
* **`Blend Mode` ($7)** (choice) : choix possibles => Normal, Lighten, Screen, Dodge, Add, Darken, Multiply, Burn, Overlay, Soft Light, Hard Light, Difference, Subtract, Grain Extract, Grain Merge, Divide, Hue, Saturation, Value
* **`Output as Separate Layers` ($8)** (bool) : par défaut = Faux (0)
(Note) : This filter uses the free light leaks dataset available at :
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2024/02/27.
