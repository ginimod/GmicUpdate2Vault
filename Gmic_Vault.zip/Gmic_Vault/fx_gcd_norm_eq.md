---
tags: [gmic, filter]
command: fx_gcd_norm_eq
---

# Filtre G'MIC : fx_gcd_norm_eq

## Structure de la commande
```text
fx_gcd_norm_eq:
    red = $1
    blue = $2
    exp = $3
    preview_type = $4
```
## Définition des variables
(Note) : Desaturate sRGB using equalized norm
* **`Red` ($1)** (float) : défaut = **0.5**  (0,1)
* **`Blue` ($2)** (float) : défaut = **0.5**  (0,1)
* **`Exp` ($3)** (float) : défaut = **2**  (1,3)
* **`Preview Type` ($4)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author : Garagecoder.      Latest update : 2016/12/27.
