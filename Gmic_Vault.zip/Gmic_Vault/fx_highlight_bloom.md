---
tags: [gmic, filter]
command: fx_highlight_bloom
---

# Filtre G'MIC : fx_highlight_bloom

## Structure de la commande
```text
fx_highlight_bloom:
    details_strength = $1
    details_scale = $2
    smoothness = $3
    highlight = $4
    contrast = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Enhance image highlights in a smooth, artistic way. 
* **`Details Strength (%)` ($1)** (float) : défaut = **90**  (0,400)
* **`Details Scale` ($2)** (float) : défaut = **60**  (0,255)
* **`Smoothness` ($3)** (float) : défaut = **60**  (0,255)
* **`Highlight (%)` ($4)** (int) : défaut = **30**  (0,100)
* **`Contrast (%)` ($5)** (float) : défaut = **20**  (0,100)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/10/24.
(Note) : This effect has been inspired by:
