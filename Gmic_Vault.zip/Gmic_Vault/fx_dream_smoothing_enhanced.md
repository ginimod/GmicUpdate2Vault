---
tags: [gmic, filter]
command: fx_dream_smoothing_enhanced
---

# Filtre G'MIC : fx_dream_smoothing_enhanced

## Structure de la commande
```text
fx_dream_smoothing_enhanced:
    iterations = $1
    amplitude = $2
    blend_opacity = $3
    sharpness_1 = $4
    anisotropy_1 = $5
    alpha_1 = $6
    sigma_1 = $7
    sharpness_2 = $8
    anisotropy_2 = $9
    alpha_2 = $10
    sigma_2 = $11
    ethereal_glow = $12
    soft_light = $13
    halo = $14
    brightness = $15
    contrast = $16
    saturation = $17
    hue_shift = $18
    vignette = $19
    fog = $20
    grain = $21
    preview_quality = $22
    preview_type = $23
    preview_split_x = $24
    preview_split_y = $25
```
## Définition des variables
(Note) : Dream Smoothing Enhanced
(Note) : Filter Design: Zarir Madon ,      Coded with: Claude Sonnet 4.5      [October 11, 2025]      
(Note) : Based on the original Dream Smoothing algorithm by Arto Huotari
(Note) : G'MIC Framework: David Tschumperlé and contributors
(Note) : License: This filter is licensed under the GNU General Public License v3.0
(Note) : Core Smoothing
* **`Iterations` ($1)** (int) : défaut = **3**  (1,10)
* **`Amplitude` ($2)** (float) : défaut = **430**  (50,2000)
* **`Blend Opacity` ($3)** (float) : défaut = **0.8**  (0,1)
(Note) : Lower iterations and amplitude for speed
(Note) : Anisotropic Parameters - Pass 1
* **`Sharpness 1` ($4)** (float) : défaut = **0.4**  (0.1,2)
* **`Anisotropy 1` ($5)** (float) : défaut = **0.5**  (0,1)
* **`Alpha 1` ($6)** (float) : défaut = **0.6**  (0,1)
* **`Sigma 1` ($7)** (int) : défaut = **2**  (0,10)
(Note) : Anisotropic Parameters - Pass 2
* **`Sharpness 2` ($8)** (float) : défaut = **0.4**  (0.1,2)
* **`Anisotropy 2` ($9)** (float) : défaut = **1.0**  (0,2)
* **`Alpha 2` ($10)** (float) : défaut = **0.6**  (0,1)
* **`Sigma 2` ($11)** (int) : défaut = **4**  (0,10)
(Note) : Dream Effects
* **`Ethereal Glow` ($12)** (float) : défaut = **0**  (0,100)
* **`Soft Light` ($13)** (float) : défaut = **0**  (0,100)
* **`Halo` ($14)** (float) : défaut = **0**  (0,100)
(Note) : Color
* **`Brightness` ($15)** (float) : défaut = **0**  (-100,100)
* **`Contrast` ($16)** (float) : défaut = **0**  (-100,100)
* **`Saturation` ($17)** (float) : défaut = **0**  (-100,100)
* **`Hue Shift` ($18)** (float) : défaut = **0**  (-180,180)
(Note) : Atmosphere
* **`Vignette` ($19)** (float) : défaut = **0**  (0,100)
* **`Fog` ($20)** (float) : défaut = **0**  (0,100)
* **`Grain` ($21)** (float) : défaut = **0**  (0,100)
(Note) : Preview Quality
* **`Preview Quality` ($22)** (choice) : choix possibles => Draft, Normal, High Quality
* **`Preview Type` ($23)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right
* **`Preview Split` ($24)** (point) : position = 0,0
