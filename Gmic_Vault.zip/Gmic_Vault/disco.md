---
tags: [gmic, filter]
command: disco
---

# Filtre G'MIC : disco

## Structure de la commande
```text
disco:
    red_wavelength = $1
    green_wavelength = $2
    blue_wavelength = $3
    zoom = $4
```
## Définition des variables
* **`Red Wavelength` ($1)** (int) : défaut = **10**  (1,50)
* **`Green Wavelength` ($2)** (int) : défaut = **15**  (1,50)
* **`Blue Wavelength` ($3)** (int) : défaut = **20**  (1,50)
* **`Zoom` ($4)** (float) : défaut = **250**  (0,3000)
(Note) : This is a failed attempt on a conversion of a Mathmap script written by persons unknown
(Note) : I prefer this over the filter I was attempting to recreate!!!.
(Note) : Create a light effect with the size and aspect ratio of the input image.
