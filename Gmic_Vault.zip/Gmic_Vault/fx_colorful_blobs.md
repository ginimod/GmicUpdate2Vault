---
tags: [gmic, filter]
command: fx_colorful_blobs
---

# Filtre G'MIC : fx_colorful_blobs

## Structure de la commande
```text
fx_colorful_blobs:
    color_space = $1
    display_blob_controls = $6
    blob_1_x = $7
    blob_1_y = $8
    radius_x = $9
    radius_y = $10
    blob2_x = $15
    blob2_y = $16
    radius_x = $17
    radius_y = $18
    blob_3_x = $23
    blob_3_y = $24
    radius_x = $25
    radius_y = $26
    blob_4_x = $31
    blob_4_y = $32
    radius_x = $33
    radius_y = $34
    blob_5_x = $39
    blob_5_y = $40
    radius_x = $41
    radius_y = $42
    blob_6_x = $47
    blob_6_y = $48
    radius_x = $49
    radius_y = $50
    blob_7_x = $55
    blob_7_y = $56
    radius_x = $57
    radius_y = $58
    blob_8_x = $63
    blob_8_y = $64
    radius_x = $65
    radius_y = $66
    blob_9_x = $71
    blob_9_y = $72
    radius_x = $73
    radius_y = $74
    blob_10_x = $79
    blob_10_y = $80
    radius_x = $81
    radius_y = $82
    blob_11_x = $87
    blob_11_y = $88
    radius_x = $89
    radius_y = $90
    blob_12_x = $95
    blob_12_y = $96
    radius_x = $97
    radius_y = $98
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Create random colorful blobs to be used as a palette. 
* **`Color Space` ($1)** (choice) : choix possibles => SRGB, Linear RGB, Lab
* **`Background Color` ($2)** (color) : défaut = 200,200,200,0
* **`Display Blob Controls` ($3)** (bool) : par défaut = Faux (0)
* **`Blob 1` ($4)** (point) : position = 0,0
* **`Radius` ($5)** (point) : position = 0,0
* **`Blob 1 Color` ($6)** (color) : défaut = 255,0,0
* **`Blob2` ($7)** (point) : position = 0,0
* **`Radius` ($8)** (point) : position = 0,0
* **`Blob 2 Color` ($9)** (color) : défaut = 0,255,0
* **`Blob 3` ($10)** (point) : position = 0,0
* **`Radius` ($11)** (point) : position = 0,0
* **`Blob 3 Color` ($12)** (color) : défaut = 0,0,255
* **`Blob 4` ($13)** (point) : position = 0,0
* **`Radius` ($14)** (point) : position = 0,0
* **`Blob 4 Color` ($15)** (color) : défaut = 255,255,0
* **`Blob 5` ($16)** (point) : position = 0,0
* **`Radius` ($17)** (point) : position = 0,0
* **`Blob 5 Color` ($18)** (color) : défaut = 255,0,255
* **`Blob 6` ($19)** (point) : position = 0,0
* **`Radius` ($20)** (point) : position = 0,0
* **`Blob 6 Color` ($21)** (color) : défaut = 0,255,255
* **`Blob 7` ($22)** (point) : position = 0,0
* **`Radius` ($23)** (point) : position = 0,0
* **`Blob 7 Color` ($24)** (color) : défaut = 255,255,255
* **`Blob 8` ($25)** (point) : position = 0,0
* **`Radius` ($26)** (point) : position = 0,0
* **`Blob 8 Color` ($27)** (color) : défaut = 0,0,0
* **`Blob 9` ($28)** (point) : position = 0,0
* **`Radius` ($29)** (point) : position = 0,0
* **`Blob 9 Color` ($30)** (color) : défaut = 255,128,64
* **`Blob 10` ($31)** (point) : position = 0,0
* **`Radius` ($32)** (point) : position = 0,0
* **`Blob 10 Color` ($33)** (color) : défaut = 255,64,128
* **`Blob 11` ($34)** (point) : position = 0,0
* **`Radius` ($35)** (point) : position = 0,0
* **`Blob 11 Color` ($36)** (color) : défaut = 128,64,255
* **`Blob 12` ($37)** (point) : position = 0,0
* **`Radius` ($38)** (point) : position = 0,0
* **`Blob 12 Color` ($39)** (color) : défaut = 64,128,255
(Note) : This filter can be used to create custom palettes with given color shades. It has been inspired by <a href="https://research.adobe.com/publication/playful-palette-an-interactive-parametric-color-mixer-for-artists/"> Adobe's Playful Palette</a>.
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2018/08/26.
