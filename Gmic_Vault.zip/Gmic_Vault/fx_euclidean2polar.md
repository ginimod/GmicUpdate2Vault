---
tags: [gmic, filter]
command: fx_euclidean2polar
---

# Filtre G'MIC : fx_euclidean2polar

## Structure de la commande
```text
fx_euclidean2polar:
    center_x = $1
    center_y = $2
    stretch_factor = $3
    boundary = $4
    inverse_transform = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Converts between Cartesian and Polar coordinates. 
* **`Center (%)` ($1)** (point) : position = 0,0
* **`Stretch Factor` ($2)** (float) : défaut = **1**  (0.1,10)
* **`Boundary` ($3)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
* **`Inverse Transform` ($4)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
