---
tags: [gmic, filter]
command: azimuthal_equidistant_projection
---

# Filtre G'MIC : azimuthal_equidistant_projection

## Structure de la commande
```text
azimuthal_equidistant_projection:
    roll = $1
    pitch = $2
    yaw = $3
    central_longitude = $4
    standard_parallel = $5
    cut_off_at = $6
```
## Définition des variables
(Note) : Rotate an equirectangular map or panorama around three axises in order and output it as an azimuthal equidistant map. All points on the map are at proportionally correct distances from the center point, and that all points on the map are at the correct azimuth (direction
* **`Roll` ($1)** (float) : défaut = **0**  (-360,360)
* **`Pitch` ($2)** (float) : défaut = **0**  (-360,360)
* **`Yaw` ($3)** (float) : défaut = **0**  (-360,360)
* **`Central Longitude` ($4)** (float) : défaut = **0**  (-180,180)
* **`Standard Parallel` ($5)** (float) : défaut = **0**  (-90,90)
* **`Cut-off At` ($6)** (float) : défaut = **180**  (0,180)
(Note) : Author: <a href="https://www.cartographersguild.com/showthread.php?t=47591">Kristian Järventaus</a>.      Latest Update: 2024/03/05.
