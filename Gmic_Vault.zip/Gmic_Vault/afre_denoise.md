---
tags: [gmic, filter]
command: afre_denoise
---

# Filtre G'MIC : afre_denoise

## Structure de la commande
```text
afre_denoise:
    radius = $1
```
## Définition des variables
(Note) : <strong>Denoise.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2022 Feb9-17.</strong>


* **`Radius` ($1)** (int) : défaut = **1**  (1,10)
(Note) : 

<strong>Note</strong>

G'MIC's preview is inaccurate. Apply the filter and review the results in your host editor.
