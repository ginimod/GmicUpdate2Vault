---
tags: [gmic, filter]
command: fx_rec_tileit
---

# Filtre G'MIC : fx_rec_tileit

## Structure de la commande
```text
fx_rec_tileit:
    tile_size = $1
    disrupt_orientation = $2
    spread_tiles_apart = $3
    fill_holes = $4
    color_count = $5
    flat_color = $6
    light_angle = $7
    soften_lighting = $8
```
## Définition des variables
(Note) : Generate a mosaic from an image. Works best with line art cartoons with flat color.
* **`Tile Size` ($1)** (float) : défaut = **1.0**  (0.05,5.0)
* **`Disrupt Orientation` ($2)** (float) : défaut = **5.0**  (0.0,10.0)
* **`Spread Tiles Apart` ($3)** (float) : défaut = **1.5**  (0.25,5.0)
* **`Fill Holes` ($4)** (bool) : par défaut = Faux (0)
* **`Color Count` ($5)** (int) : défaut = **4**  (2,32)
* **`Flat Color` ($6)** (bool) : par défaut = Faux (0)
* **`Light Angle` ($7)** (float) : défaut = **45.0**  (-180,180)
* **`Soften Lighting` ($8)** (float) : défaut = **0.5**  (0.0,5.0)
(Note) : Author: Garry R. Osgood. Latest Update: 2023/07/01
