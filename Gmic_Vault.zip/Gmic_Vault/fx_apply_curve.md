---
tags: [gmic, filter]
command: fx_apply_curve
---

# Filtre G'MIC : fx_apply_curve

## Structure de la commande
```text
fx_apply_curve:
    starting_y = $1
    x_coord_1 = $2
    y_coord_1 = $3
    x_coord_2 = $4
    y_coord_2 = $5
    x_coord_3 = $6
    y_coord_3 = $7
    x_coord_4 = $8
    y_coord_4 = $9
    x_coord_5 = $10
    y_coord_5 = $11
    ending_y = $12
    curve_smoothness = $13
    channel_s = $14
    value_action = $15
    display_histogram = $16
    preview_type = $17
```
## Définition des variables
* **`Starting Y` ($1)** (int) : défaut = **0**  (0,255)
* **`X-Coord(1)` ($2)** (int) : défaut = **-1**  (-1,255)
* **`Y-Coord(1)` ($3)** (int) : défaut = **128**  (0,255)
* **`X-Coord(2)` ($4)** (int) : défaut = **-1**  (-1,255)
* **`Y-Coord(2)` ($5)** (int) : défaut = **128**  (0,255)
* **`X-Coord(3)` ($6)** (int) : défaut = **-1**  (-1,255)
* **`Y-Coord(3)` ($7)** (int) : défaut = **128**  (0,255)
* **`X-Coord(4)` ($8)** (int) : défaut = **-1**  (-1,255)
* **`Y-Coord(4)` ($9)** (int) : défaut = **128**  (0,255)
* **`X-Coord(5)` ($10)** (int) : défaut = **-1**  (-1,255)
* **`Y-Coord(5)` ($11)** (int) : défaut = **128**  (0,255)
* **`Ending Y` ($12)** (int) : défaut = **255**  (0,255)
* **`Curve Smoothness` ($13)** (float) : défaut = **1**  (0,1)
* **`Channel(s)` ($14)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CYMK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
* **`Value Action` ($15)** (choice) : choix possibles => None, Cut, Normalize
* **`Display Histogram` ($16)** (float) : défaut = **0**  (0,1)
* **`Preview Type` ($17)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest update: 2010/29/12.
