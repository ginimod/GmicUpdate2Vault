---
tags: [gmic, filter]
command: afre_localcontrast
---

# Filtre G'MIC : afre_localcontrast

## Structure de la commande
```text
afre_localcontrast:
    radius = $1
    amount = $2
```
## Définition des variables
(Note) : <strong>Enhance local contrast.  Filter by <a href="https://discuss.pixls.us/u/afre">afre</a> 2020 Jul28-Sep5.</strong>


* **`Radius` ($1)** (int) : défaut = **1**  (1,10)
* **`Amount` ($2)** (int) : défaut = **50**  (-100,100)
(Note) : 

<strong>Note</strong>

G'MIC's preview is inaccurate. Apply the filter and review the results in your host editor.
