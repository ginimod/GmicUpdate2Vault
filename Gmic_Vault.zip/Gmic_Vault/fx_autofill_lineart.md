---
tags: [gmic, filter]
command: fx_autofill_lineart
---

# Filtre G'MIC : fx_autofill_lineart

## Structure de la commande
```text
fx_autofill_lineart:
    contour_threshold = $1
    contour_normalization = $2
    minimal_region_area = $3
    tolerance_to_gaps = $4
    preview_type = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Automatically fills distinct regions in line art with random flat colors. 
* **`Contour Threshold (%)` ($1)** (float) : défaut = **90**  (0,100)
* **`Contour Normalization` ($2)** (bool) : par défaut = Faux (0)
* **`Minimal Region Area` ($3)** (int) : défaut = **8**  (0,256)
* **`Tolerance to Gaps` ($4)** (int) : défaut = **0**  (0,10)
* **`Preview Type` ($5)** (choice) : choix possibles => Lineart + Colors, Colors Only
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/11/12.
