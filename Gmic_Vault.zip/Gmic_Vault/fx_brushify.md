---
tags: [gmic, filter]
command: fx_brushify
---

# Filtre G'MIC : fx_brushify

## Structure de la commande
```text
fx_brushify:
    shape = $1
    ratio = $2
    number_of_sizes = $3
    maximal_size = $4
    minimal_size = $5
    number_of_orientations = $6
    fuzziness = $7
    smoothness = $8
    light_type = $9
    light_strength = $10
    opacity = $11
    density = $12
    contour_coherence = $13
    orientation_coherence = $14
    gradient_smoothness = $15
    structure_smoothness = $16
    primary_angle = $17
    angle_dispersion = $18
    preview_brush = $19
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates a painting created with specific brush shapes. 
(Note) : Brush parameters:
* **`Shape` ($1)** (choice) : choix possibles => Bottom Layer, Top Layer, Rectangle, Diamond, Pentagon, Hexagon, Octogon, Ellipse, Gaussian, Star, Heart
* **`Ratio` ($2)** (float) : défaut = **0.25**  (0,1)
* **`Number of Sizes` ($3)** (int) : défaut = **4**  (1,16)
* **`Maximal Size` ($4)** (int) : défaut = **64**  (1,128)
* **`Minimal Size (%)` ($5)** (float) : défaut = **25**  (0,100)
* **`Number of Orientations` ($6)** (int) : défaut = **12**  (1,24)
* **`Fuzziness` ($7)** (float) : défaut = **0**  (0,10)
* **`Smoothness` ($8)** (float) : défaut = **2**  (0,10)
* **`Light Type` ($9)** (choice) : choix possibles => None, Flat, Darken, Lighten, Full
* **`Light Strength` ($10)** (float) : défaut = **0.2**  (0,1)
* **`Opacity` ($11)** (float) : défaut = **0.5**  (0,1)
(Note) : Painting parameters:
* **`Density (%)` ($12)** (float) : défaut = **30**  (0,100)
* **`Contour Coherence` ($13)** (float) : défaut = **1**  (0,1)
* **`Orientation Coherence` ($14)** (float) : défaut = **1**  (0,1)
* **`Gradient Smoothness` ($15)** (float) : défaut = **1**  (0,10)
* **`Structure Smoothness` ($16)** (float) : défaut = **5**  (0,10)
* **`Primary Angle` ($17)** (float) : défaut = **0**  (-180,180)
* **`Angle Dispersion` ($18)** (float) : défaut = **0.2**  (0,1)
* **`Preview Brush` ($19)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/04/22.
