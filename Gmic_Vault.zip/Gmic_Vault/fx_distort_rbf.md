---
tags: [gmic, filter]
command: fx_distort_rbf
---

# Filtre G'MIC : fx_distort_rbf

## Structure de la commande
```text
fx_distort_rbf:
    upper_left_corner_x = $1
    upper_left_corner_y = $2
    upper_right_corner_x = $3
    upper_right_corner_y = $4
    lower_left_corner_x = $5
    lower_left_corner_y = $6
    lower_right_corner_x = $7
    lower_right_corner_y = $8
    sampling = $9
    boundary = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Distorts the image using Radial Basis Functions. 
* **`Upper-Left Corner` ($1)** (point) : position = 0,0
* **`Upper-Right Corner` ($2)** (point) : position = 0,0
* **`Lower-Left Corner` ($3)** (point) : position = 0,0
* **`Lower-Right Corner` ($4)** (point) : position = 0,0
* **`Sampling` ($5)** (int) : défaut = **3**  (2,8)
* **`Boundary` ($6)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2024/04/20.
