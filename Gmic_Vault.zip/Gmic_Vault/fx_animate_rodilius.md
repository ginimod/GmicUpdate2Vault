---
tags: [gmic, filter]
command: fx_animate_rodilius
---

# Filtre G'MIC : fx_animate_rodilius

## Structure de la commande
```text
fx_animate_rodilius:
    frames = $1
    output_as_frames = $2
    output_as_files = $3
    color_mode = $5
    amplitude = $6
    thickness = $7
    sharpness = $8
    orientations = $9
    offset = $10
    amplitude = $11
    thickness = $12
    sharpness = $13
    orientations = $14
    offset = $15
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Animates the Rodilius filter parameters. 
* **`Frames` ($1)** (int) : défaut = **10**  (2,100)
* **`Output as Frames` ($2)** (bool) : par défaut = Faux (0)
* **`Output as Files` ($3)** (bool) : par défaut = Faux (0)
* **`Color Mode` ($4)** (choice) : choix possibles => Darker, Lighter
(Note) : 
Starting Parameters :
* **`Amplitude` ($5)** (float) : défaut = **10**  (0,30)
* **`Thickness` ($6)** (float) : défaut = **10**  (0,100)
* **`Sharpness` ($7)** (float) : défaut = **300**  (0,1000)
* **`Orientations` ($8)** (int) : défaut = **5**  (2,20)
* **`Offset` ($9)** (float) : défaut = **0**  (0,180)
(Note) : 
Ending Parameters :
* **`Amplitude` ($10)** (float) : défaut = **10**  (0,30)
* **`Thickness` ($11)** (float) : défaut = **10**  (0,100)
* **`Sharpness` ($12)** (float) : défaut = **300**  (0,1000)
* **`Orientations` ($13)** (int) : défaut = **5**  (2,20)
* **`Offset` ($14)** (float) : défaut = **180**  (0,180)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
