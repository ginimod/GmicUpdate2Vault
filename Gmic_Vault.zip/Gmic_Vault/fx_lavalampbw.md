---
tags: [gmic, filter]
command: fx_lavalampbw
---

# Filtre G'MIC : fx_lavalampbw

## Structure de la commande
```text
fx_lavalampbw:
    number_of_key_frames = $1
    number_of_inter_frames = $2
    smooth_looping = $3
    resolution = $4
    size = $5
    smoothness = $6
    transparent_background = $7
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Creates a liquid lava lamp animation. 
* **`Number of Key-Frames` ($1)** (int) : défaut = **3**  (2,50)
* **`Number of Inter-Frames` ($2)** (int) : défaut = **30**  (2,100)
* **`Smooth Looping` ($3)** (bool) : par défaut = Faux (0)
* **`Resolution` ($4)** (float) : défaut = **20**  (1,100)
* **`Size` ($5)** (float) : défaut = **2**  (0,30)
* **`Smoothness` ($6)** (float) : défaut = **0.01**  (0,1)
* **`Transparent Background` ($7)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2011/07/06.
