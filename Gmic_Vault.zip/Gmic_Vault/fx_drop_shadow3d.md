---
tags: [gmic, filter]
command: fx_drop_shadow3d
---

# Filtre G'MIC : fx_drop_shadow3d

## Structure de la commande
```text
fx_drop_shadow3d:
    x_angle = $1
    y_angle = $2
    z_angle = $3
    zoom = $4
    x_offset = $5
    y_offset = $6
    perspective = $7
    smoothness = $8
    preview_only_shadow = $13
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds a projected 3D shadow. 
* **`X-Angle` ($1)** (float) : défaut = **0**  (-90,90)
* **`Y-Angle` ($2)** (float) : défaut = **0**  (-90,90)
* **`Z-Angle` ($3)** (float) : défaut = **0**  (-90,90)
* **`Zoom` ($4)** (float) : défaut = **0**  (-100,100)
* **`X-Offset` ($5)** (float) : défaut = **1**  (-50,50)
* **`Y-Offset` ($6)** (float) : défaut = **1**  (-50,50)
* **`Perspective` ($7)** (float) : défaut = **2**  (0,10)
* **`Smoothness` ($8)** (float) : défaut = **0.5**  (0,5)
* **`Color` ($9)** (color) : défaut = 0,0,0,200
* **`Preview Only Shadow` ($10)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2013/07/02.
