---
tags: [gmic, filter]
command: fx_distort_lens
---

# Filtre G'MIC : fx_distort_lens

## Structure de la commande
```text
fx_distort_lens:
    amplitude = $1
    aspect_ratio = $2
    zoom = $3
    center_x = $4
    center_y = $5
    boundary = $6
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Corrects or applies lens distortion (barrel/pincushion). 
* **`Amplitude` ($1)** (float) : défaut = **0.1**  (-1,1)
* **`Aspect Ratio` ($2)** (float) : défaut = **0**  (-2,2)
* **`Zoom` ($3)** (float) : défaut = **0**  (-4,4)
* **`Center (%)` ($4)** (point) : position = 0,0
* **`Boundary` ($5)** (choice) : choix possibles => Transparent, Nearest, Periodic, Mirror
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2017/02/18.
