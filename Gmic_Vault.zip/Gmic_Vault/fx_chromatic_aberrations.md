---
tags: [gmic, filter]
command: fx_chromatic_aberrations
---

# Filtre G'MIC : fx_chromatic_aberrations

## Structure de la commande
```text
fx_chromatic_aberrations:
    deformation_type = $4
    x_amplitude = $5
    y_amplitude = $6
    smoothness = $7
    attenuation_near_center = $8
    attenuation_decay = $9
    deformation_type = $13
    x_amplitude = $14
    y_amplitude = $15
    smoothness = $16
    attenuation_near_center = $17
    attenuation_decay = $18
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates lens color fringing artifacts. 
* **`Primary Color` ($1)** (color) : défaut = 255,0,0
* **`Deformation Type` ($2)** (choice) : choix possibles => Shift, Radial, Angular, Random
* **`X-Amplitude` ($3)** (float) : défaut = **2**  (-32,32)
* **`Y-Amplitude` ($4)** (float) : défaut = **2**  (-32,32)
* **`Smoothness` ($5)** (float) : défaut = **0**  (0,10)
* **`Attenuation Near Center (%)` ($6)** (float) : défaut = **50**  (-100,100)
* **`Attenuation Decay` ($7)** (float) : défaut = **1**  (0,8)
* **`Secondary Color` ($8)** (color) : défaut = 0,255,0
* **`Deformation Type` ($9)** (choice) : choix possibles => Shift, Radial, Angular, Random
* **`X-Amplitude` ($10)** (float) : défaut = **0**  (-32,32)
* **`Y-Amplitude` ($11)** (float) : défaut = **0**  (-32,32)
* **`Smoothness` ($12)** (float) : défaut = **0**  (0,10)
* **`Attenuation Near Center (%)` ($13)** (float) : défaut = **0**  (-100,100)
* **`Attenuation Decay` ($14)** (float) : défaut = **1**  (0,8)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2021/08/10.
