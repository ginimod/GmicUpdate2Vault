---
tags: [gmic, filter]
command: fx_polaroid
---

# Filtre G'MIC : fx_polaroid

## Structure de la commande
```text
fx_polaroid:
    frame_size = $1
    bottom_size = $2
    x_shadow = $3
    y_shadow = $4
    smoothness = $5
    x_curvature = $6
    y_curvature = $7
    angle = $8
    vignette_strength = $9
    vignette_min_radius = $10
    vignette_max_radius = $11
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds a classic white instant film border. 
* **`Frame Size` ($1)** (int) : défaut = **10**  (0,400)
* **`Bottom Size` ($2)** (int) : défaut = **20**  (0,400)
* **`X-Shadow` ($3)** (float) : défaut = **0**  (-20,20)
* **`Y-Shadow` ($4)** (float) : défaut = **0**  (-20,20)
* **`Smoothness` ($5)** (float) : défaut = **3**  (0,5)
* **`X-Curvature` ($6)** (float) : défaut = **0**  (0,1)
* **`Y-Curvature` ($7)** (float) : défaut = **0**  (0,1)
* **`Angle` ($8)** (float) : défaut = **20**  (-180,180)
* **`Vignette Strength` ($9)** (float) : défaut = **50**  (0,255)
* **`Vignette Min Radius` ($10)** (float) : défaut = **70**  (0,100)
* **`Vignette Max Radius` ($11)** (float) : défaut = **95**  (0,100)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2016/06/20.
