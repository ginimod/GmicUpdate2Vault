---
tags: [gmic, filter]
command: fx_painting
---

# Filtre G'MIC : fx_painting

## Structure de la commande
```text
fx_painting:
    abstraction = $1
    details_scale = $2
    color = $3
    smoothness = $4
    sharpen_shades = $5
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Converts the photo into a generic painting style. 
* **`Abstraction` ($1)** (int) : défaut = **5**  (1,10)
* **`Details Scale` ($2)** (float) : défaut = **2.5**  (0,5)
* **`Color` ($3)** (float) : défaut = **1.5**  (0,4)
* **`Smoothness` ($4)** (float) : défaut = **50**  (0,1000)
* **`Sharpen Shades` ($5)** (bool) : par défaut = Faux (0)
(Note) : Authors: Lyle Kroll, Angelo Lama and <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.       Latest Update: 2011/02/28.
