---
tags: [gmic, filter]
command: fx_gcd_canny
---

# Filtre G'MIC : fx_gcd_canny

## Structure de la commande
```text
fx_gcd_canny:
    sigma = $1
    lower_threshold = $2
    upper_threshold = $3
```
## Définition des variables
(Note) : Locate image edges using canny edge detector
* **`Sigma` ($1)** (float) : défaut = **1**  (0,10)
* **`Lower Threshold` ($2)** (float) : défaut = **0.05**  (0,1)
* **`Upper Threshold` ($3)** (float) : défaut = **0.15**  (0,1)
(Note) : Author : Garagecoder.      Latest update : 2023/12/04.
