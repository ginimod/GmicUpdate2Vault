---
tags: [gmic, filter]
command: fx_rectexture
---

# Filtre G'MIC : fx_rectexture

## Structure de la commande
```text
fx_rectexture:
    iterations = $2
    colours = $3
    warp_multiplier = $4
    warp_boundary = $5
    channel_s = $6
    value_action = $7
```
## Définition des variables
(Note) : Generates textures from rectangles, difference blending and warping.
* **`Iterations` ($1)** (int) : défaut = **10**  (0,500)
* **`Colours` ($2)** (choice) : choix possibles => Random Colours (Difference Blending), Random Colours (Diffblend + Sine Mapping), Random Colours (Diffblend + Sinemap + Random HSV Mixing), Black and White
* **`Warp Multiplier` ($3)** (float) : défaut = **1**  (0,5)
* **`Warp Boundary` ($4)** (choice) : choix possibles => Random, Random [non-Transparent], Transparent, Nearest, Periodic, Mirror
* **`Channel(s)` ($5)** (choice) : choix possibles => All, RGBA [all], RGB [all], RGB [red], RGB [green], RGB [blue], RGBA [alpha], Linear RGB [all], Linear RGB [red], Linear RGB [green], Linear RGB [blue], YCbCr [luminance], YCbCr [blue-Red Chrominances], YCbCr [blue Chrominance], YCbCr [red Chrominance], YCbCr [green Chrominance], Lab [lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [hue], HSV [saturation], HSV [value], HSI [intensity], HSL [lightness], CMYK [cyan], CMYK [magenta], CMYK [yellow], CMYK [key], YIQ [luma], YIQ [chromas]
* **`Value Action` ($6)** (choice) : choix possibles => None, Cut, Normalize
