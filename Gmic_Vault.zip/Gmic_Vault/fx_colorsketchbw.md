---
tags: [gmic, filter]
command: fx_colorsketchbw
---

# Filtre G'MIC : fx_colorsketchbw

## Structure de la commande
```text
fx_colorsketchbw:
    amplitude = $1
    density = $2
    smoothness = $3
    opacity = $4
    edge = $5
    fast_approximation = $6
    negative = $7
    quantize_colors = $8
    color_smoothness = $9
    mixer_mode = $10
    color_intensity = $11
    preview_type = $12
```
## Définition des variables
* **`Amplitude` ($1)** (float) : défaut = **300**  (0,4000)
* **`Density` ($2)** (float) : défaut = **50**  (0,100)
* **`Smoothness` ($3)** (float) : défaut = **1**  (0,10)
* **`Opacity` ($4)** (float) : défaut = **0.1**  (0,1)
* **`Edge` ($5)** (float) : défaut = **20**  (0,100)
* **`Fast Approximation` ($6)** (bool) : par défaut = Faux (0)
* **`Negative` ($7)** (bool) : par défaut = Faux (0)
* **`Quantize Colors` ($8)** (int) : défaut = **20**  (2,255)
* **`Color Smoothness` ($9)** (float) : défaut = **2**  (0.50,30)
* **`Mixer Mode` ($10)** (choice) : choix possibles => Color Doping, Darken, Hard Light, Grain Merge, Lightness, Multiply, Value
* **`Color Intensity` ($11)** (float) : défaut = **1**  (0,1)
* **`Preview Type` ($12)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author: PhotoComiX.      Latest update : 2010/29/12.
