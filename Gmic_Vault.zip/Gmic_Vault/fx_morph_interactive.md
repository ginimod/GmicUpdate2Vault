---
tags: [gmic, filter]
command: fx_morph_interactive
---

# Filtre G'MIC : fx_morph_interactive

## Structure de la commande
```text
fx_morph_interactive:
    number_of_frames = $1
    preview_precision = $2
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Interactively warps two layers using control points. 
* **`Number of Frames` ($1)** (int) : défaut = **16**  (3,1024)
* **`Preview Precision` ($2)** (choice) : choix possibles => Coarsest (faster), Coarse, Normal, Fine, Finest (slower)
(Note) : Instructions:
(Note) :  Use mouse buttons to add/move/remove correspondence keypoints over the interactive window that will appear, in order to create the morphing.

 <span color="#EE5500">Source/target window:</span>

 - Left mouse button: Add new keypoint on current image and move it on the other one.
 - Right mouse button: Add/move keypoint on current image.
 - Key DELETE or middle mouse button: Delete keypoint.
 - Key SPACE or mouse wheel: Toggle source/target.

 <span color="#EE5500">In-between window:</span>

 - Mouse wheel: Change morphing time, from 0 to 1.
 - Left mouse button: Reset morphing time to 0.5.

 <span color="#EE5500">Both windows:</span>

 - Key TAB: Change keypoint radius.
 - Key RETURN: Play/stop in-between animation.
 - Key R: Reset keypoints.
 - Key K: Show/hide keypoints.
 - Keys ESC or Q: Process fullres and exit. 
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2019/04/16.
