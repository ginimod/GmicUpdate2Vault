---
tags: [gmic, filter]
command: cl_tangentialCircle
---

# Filtre G'MIC : cl_tangentialCircle

## Structure de la commande
```text
cl_tangentialCircle:
    draw_big_circle = $1
    big_circle_radius = $2
    dimensions = $3
    stroke_width = $4
    number_of_small_circles = $5
    number_of_levels = $6
    effect = $13
```
## Définition des variables
(Note) : Warning: This is a slow filter and it might consume too much RAM.
(Note) : Drawing:
* **`Draw Big Circle` ($1)** (bool) : par défaut = Faux (0)
* **`Big Circle Radius` ($2)** (float) : défaut = **100**  (10,1000)
* **`Dimensions` ($3)** (choice) : choix possibles => According to Radius, According to Layer, According to Layer (Proportionate), According to Layer (Scaling)
(Note) : If you choose "proportionate" or "Scaling", the Big Circle Radius is a percentage of 1/3 of the smaller dimension of the layer. Otherwise, it is a number of pixels.
* **`Stroke Width` ($4)** (float) : défaut = **1**  (0.5,10)
* **`Number of Small Circles` ($5)** (int) : défaut = **5**  (2,100)
* **`Number of Levels` ($6)** (int) : défaut = **1**  (1,4)
(Note) : Colors:
* **`Background Color` ($7)** (color) : défaut = 255,255,255
* **`Foreground Color` ($8)** (color) : défaut = 0,0,0
(Note) : Effects:
* **`Effect` ($9)** (choice) : choix possibles => None, Transparent Background, Strange Polygons, Multicolored, Rainbow, Double, Colored Tube, Red-Yellow Halo, Blue-Cyan Halo
(Note) : Note: The preview might be much more aliased than the final result and some effects ignore colors.
(Note) : Author: Claude Lion. Latest Update: 2022/11/14.
(Note) : It uses filters of David Tschumperlé and Rod/GimpChat and an algorithm of Reptorian.
