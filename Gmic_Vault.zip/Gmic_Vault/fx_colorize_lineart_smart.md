---
tags: [gmic, filter]
command: fx_colorize_lineart_smart
---

# Filtre G'MIC : fx_colorize_lineart_smart

## Structure de la commande
```text
fx_colorize_lineart_smart:
    colorize_mode = $1
    contour_detection = $2
    discard_contour_guides = $3
    output_region_delimiters = $4
    make_hue_depends_on_region_size = $5
    maximal_color_saturation = $6
    minimal_color_intensity = $7
    color_shading = $8
    end_point_rate = $9
    end_point_connectivity = $10
    spline_max_length_px = $11
    segment_max_length_px = $12
    spline_max_angle_deg = $13
    spline_roundness = $14
    minimal_region_area = $15
    allow_self_intersections = $16
    preview_type = $17
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> An advanced assisted coloring tool for line art. 
* **`Colorize Mode` ($1)** (choice) : choix possibles => Generate Random-Colors Layer, Extrapolate Color Spots on Transparent Top Layer, Auto-Clean Bottom Color Layer
(Note) : Global geometry parameters:
* **`Contour Detection (%)` ($2)** (float) : défaut = **95**  (0,100)
* **`Discard Contour Guides` ($3)** (bool) : par défaut = Faux (0)
(Note) : Add strokes with a saturated color having value 255 (e.g. pure red) on your lineart can be used to guide the colorization algorithm with virtual contours.
* **`Output Region Delimiters` ($4)** (bool) : par défaut = Faux (0)
(Note) : For Random colors mode only:
* **`Make Hue Depends on Region Size` ($5)** (float) : défaut = **1**  (0,1)
* **`Maximal Color Saturation` ($6)** (int) : défaut = **24**  (0,255)
* **`Minimal Color Intensity` ($7)** (int) : défaut = **200**  (0,255)
(Note) : For color spots mode only:
* **`Color Shading (%)` ($8)** (int) : défaut = **0**  (0,100)
(Note) : Connection parameters:
* **`End Point Rate (%)` ($9)** (float) : défaut = **75**  (0,100)
* **`End Point Connectivity` ($10)** (int) : défaut = **2**  (1,5)
* **`Spline Max Length (px)` ($11)** (float) : défaut = **60**  (0,256)
* **`Segment Max Length (px)` ($12)** (float) : défaut = **20**  (0,256)
* **`Spline Max Angle (deg)` ($13)** (float) : défaut = **90**  (0,180)
* **`Spline Roundness` ($14)** (float) : défaut = **1**  (0,2)
* **`Minimal Region Area` ($15)** (float) : défaut = **10**  (0,100)
* **`Allow Self Intersections` ($16)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($17)** (choice) : choix possibles => Colored Geometry, Colored Regions, Colored Lineart
(Note) : Authors: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>, Sébastien Fourey and David Revoy.      Latest Update: 2018/11/09.
