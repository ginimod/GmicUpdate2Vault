---
tags: [gmic, filter]
command: fx_frame_round
---

# Filtre G'MIC : fx_frame_round

## Structure de la commande
```text
fx_frame_round:
    x_size = $1
    y_size = $2
    radius = $3
    smoothness = $4
    anti_alias = $9
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Adds rounded corners or a circular frame. 
* **`X-Size (%)` ($1)** (float) : défaut = **10**  (0,100)
* **`Y-Size (%)` ($2)** (float) : défaut = **10**  (0,100)
* **`Radius (%)` ($3)** (float) : défaut = **20**  (0,100)
* **`Smoothness` ($4)** (float) : défaut = **0.1**  (0,15)
* **`Color` ($5)** (color) : défaut = 0,0,0,255
* **`Anti-Alias` ($6)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2026/05/03.
