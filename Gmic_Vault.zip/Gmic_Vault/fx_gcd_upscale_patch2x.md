---
tags: [gmic, filter]
command: fx_gcd_upscale_patch2x
---

# Filtre G'MIC : fx_gcd_upscale_patch2x

## Structure de la commande
```text
fx_gcd_upscale_patch2x:
    type = $1
    smoothing = $2
```
## Définition des variables
* **`Type` ($1)** (choice) : choix possibles => Patch2x, Tile2x, Patch4x, Tile4x
* **`Smoothing` ($2)** (bool) : par défaut = Faux (0)
(Note) : Author : Garagecoder.      Latest update : 2025/01/10.
(Note) : Note: Results are partially random.
