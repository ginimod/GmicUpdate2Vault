---
tags: [gmic, filter]
command: fx_emboss_relief
---

# Filtre G'MIC : fx_emboss_relief

## Structure de la commande
```text
fx_emboss_relief:
    radius = $1
    angle = $2
    sigma = $3
    value_scale = $4
    output = $5
    output_color = $6
    preserve_alpha = $7
    preview_type = $8
    preview_split_x = $9
    preview_split_y = $10
```
## Définition des variables
* **`Radius` ($1)** (int) : défaut = **5**  (5,100)
* **`Angle` ($2)** (float) : défaut = **0**  (-180,180)
* **`Sigma` ($3)** (float) : défaut = **.5**  (.05,4)
* **`Value Scale` ($4)** (float) : défaut = **2**  (.5,10)
* **`Output` ($5)** (choice) : choix possibles => Emboss, Relief
* **`Output Color` ($6)** (bool) : par défaut = Faux (0)
* **`Preserve Alpha?` ($7)** (bool) : par défaut = Faux (0)
* **`Preview Type` ($8)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($9)** (point) : position = 0,0
(Note) : Author: Reptorian. Latest Update: 2021/12/07.
