---
tags: [gmic, filter]
command: fx_hard_painting
---

# Filtre G'MIC : fx_hard_painting

## Structure de la commande
```text
fx_hard_painting:
    1_abstraction = $1
    2_details_scale = $2
    3_color = $3
    4_smoothness = $4
    5_sharpen_shades = $5
    6_graphic_novel_iterations = $6
    7_skip_this_step = $7
    8_ln_amplititude = $8
    9_ln_size = $9
    10_ln_neightborhood_smoothness = $10
    11_ln_average_smoothness = $11
    12_skip_all_other_steps = $12
    13_pencil_size = $13
    14_pencil_amplitude = $14
    15_skip_all_other_steps = $15
    16_activate_pencil_smoother = $16
    17_pencil_smoother_sharpness = $17
    18_pencil_smoother_edge_protection = $18
    19_pencil_smoother_smoothness = $19
    20_skip_all_other_steps = $20
    21_swap_layers = $21
    22_mixer = $22
    23_opacity = $23
    24_intensity = $24
    25_add_painter_s_touch = $25
    26_painter_s_touch_sharpness = $26
    27_painter_s_edge_protection_flow = $27
    28_painter_s_smoothness = $28
    29_31_preview_type = $29
    preview_split_x = $30
    preview_split_y = $31
```
## Définition des variables
(Note) : Modular filter which can be used to apply an extremely-glossy paint effect.
(Note) : Painting authors: Lyle Kroll, Angelo Lama and <a href="https://goo.gl/Ryf7Cv">David Tschumperlé</a>.
Latest update: 2011/28/02.
* **`1. Abstraction` ($1)** (int) : défaut = **1**  (0,20)
* **`2. Details Scale` ($2)** (float) : défaut = **2.5**  (0,100)
* **`3. Color` ($3)** (float) : défaut = **4**  (0,25)
* **`4. Smoothness` ($4)** (float) : défaut = **50**  (0,2000)
* **`5. Sharpen Shades` ($5)** (bool) : par défaut = Faux (0)
(Note) : Graphic novel author: PhotoComiX. Latest update : 2011/13/11.
* **`6. Graphic Novel Iterations` ($6)** (int) : défaut = **1**  (0,10)
(Note) : Apply Local Normalization
* **`7. Skip This Step` ($7)** (bool) : par défaut = Faux (0)
(Note) : Local Normalization Controls
* **`8. Ln Amplititude` ($8)** (float) : défaut = **2**  (0,60)
* **`9. Ln Size` ($9)** (float) : défaut = **6**  (0,64)
* **`10. Ln Neightborhood-Smoothness` ($10)** (float) : défaut = **5**  (0,40)
* **`11. Ln Average-Smoothness` ($11)** (float) : défaut = **20**  (0,40)
* **`12. Skip All Other Steps` ($12)** (bool) : par défaut = Faux (0)
(Note) :  Pencil Options
* **`13. Pencil Size` ($13)** (float) : défaut = **0.62**  (0,4)
* **`14. Pencil Amplitude` ($14)** (float) : défaut = **14**  (0,200)
* **`15. Skip All Other Steps` ($15)** (bool) : par défaut = Faux (0)
* **`16. Activate "Pencil Smoother"` ($16)** (bool) : par défaut = Faux (0)
(Note) :  If unchecked the 3 sliders below are disabled 
* **`17. Pencil Smoother Sharpness` ($17)** (float) : défaut = **0.5**  (0,2)
* **`18. Pencil Smoother Edge Protection` ($18)** (float) : défaut = **0.78**  (0,1)
* **`19. Pencil Smoother Smoothness` ($19)** (float) : défaut = **1.92**  (0,10)
* **`20. Skip All Other Steps` ($20)** (bool) : par défaut = Faux (0)
(Note) : Boost Merging Options
* **`21. Swap Layers` ($21)** (bool) : par défaut = Faux (0)
* **`22. Mixer` ($22)** (choice) : choix possibles => Overlay, Multiply, Soft Light, Color Burn, Darken, Stamp, Hard Light, Value, Grain Merge, Freeze, Lightness, Luminance, *Colors Doping, *Comix Colors*, Graphic Colours, *Graphix Colors, *Vivid Edges*, *Dark Edges*, *Dark Screen*, *Vivid Screen*, Interpolate
* **`23. Opacity` ($23)** (float) : défaut = **1**  (0,1)
* **`24. Intensity` ($24)** (float) : défaut = **1**  (0,1)
* **`25. Add Painter's Touch` ($25)** (bool) : par défaut = Faux (0)
* **`26. Painter's Touch Sharpness` ($26)** (float) : défaut = **0.5**  (0,2)
* **`27. Painter's Edge Protection Flow` ($27)** (float) : défaut = **0.8**  (0,1)
* **`28. Painter's Smoothness` ($28)** (float) : défaut = **1.28**  (0,10)
* **`29-31. Preview Type` ($29)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($30)** (point) : position = 0,0
