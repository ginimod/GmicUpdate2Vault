---
tags: [gmic, filter]
command: fx_freaky_details
---

# Filtre G'MIC : fx_freaky_details

## Structure de la commande
```text
fx_freaky_details:
    amplitude = $1
    scale = $2
    iterations = $3
    channel_s = $4
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Strongly enhances local contrast for a "HDR-like" gritty look. 
* **`Amplitude` ($1)** (int) : défaut = **2**  (1,5)
* **`Scale` ($2)** (float) : défaut = **10**  (0,100)
* **`Iterations` ($3)** (int) : défaut = **1**  (1,4)
* **`Channel(s)` ($4)** (choice) : choix possibles => All, RGBA [All], RGBA [Red-Green-Blue], RGBA [Red], RGBA [Green], RGBA [Blue], RGBA [Alpha], Linear RGB [All], Linear RGB [Red], Linear RGB [Green], Linear RGB [Blue], YCbCr [All], YCbCr [Luminance], YCbCr [Blue-Red Chrominances], YCbCr [Blue Chrominance], YCbCr [Red Chrominance], YCbCr [Green Chrominance], Lab [All], Lab [Lightness], Lab [ab-Chrominances], Lab [a-Chrominance], Lab [b-Chrominance], Lch [All], Lch [ch-Chrominances], Lch [c-Chrominance], Lch [h-Chrominance], HSV [All], HSV [Hue], HSV [Saturation], HSV [Value], HSI [All], HSI [Intensity], HSL [All], HSL [Lightness], CMYK [All], CMYK [Cyan-Magenta-Yellow], CMYK [Cyan], CMYK [Magenta], CMYK [Yellow], CMYK [Key], YIQ [All], YIQ [Luma], YIQ [Chromas], RYB [All], RYB [Red], RYB [Yellow], RYB [Blue]
(Note) : Authors: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a> and Patrick David.       Latest Update: 2013/02/27.
(Note) : This effect has been done following:
