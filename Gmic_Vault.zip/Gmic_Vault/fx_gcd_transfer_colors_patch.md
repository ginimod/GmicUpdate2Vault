---
tags: [gmic, filter]
command: fx_gcd_transfer_colors_patch
---

# Filtre G'MIC : fx_gcd_transfer_colors_patch

## Structure de la commande
```text
fx_gcd_transfer_colors_patch:
    resolution = $1
    smooth = $2
    iters = $3
    random = $4
    reference = $5
    output_clut = $6
```
## Définition des variables
(Note) : Generate a CLUT and apply it to other images.
(Note) : 
Input Options
* **`Resolution` ($1)** (int) : défaut = **6**  (2,8)
* **`Smooth` ($2)** (float) : défaut = **3**  (0,10)
* **`Iters` ($3)** (int) : défaut = **5**  (0,20)
* **`Random` ($4)** (int) : défaut = **5**  (0,20)
(Note) : 
Output Options
* **`Reference` ($5)** (choice) : choix possibles => Top Layer, Bottom Layer
* **`Output CLUT` ($6)** (choice) : choix possibles => Disable, 512x512 Layer, 4096x4096 Layer
(Note) : 

(Note) : Author : Garagecoder.      Latest update : 2017/08/17.
(Note) : 
<u>Notes</u>
(Note) : Set the Input layers option to transfer colors to other layers.
(Note) : If only one input layer is selected a CLUT is always output.
(Note) : Higher resolution, iters, or random generally produce better results - at the cost of processing time.
(Note) : Results are not necessarily the same every time due to the random based algorithm.
