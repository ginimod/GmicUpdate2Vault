---
tags: [gmic, filter]
command: fx_array_color
---

# Filtre G'MIC : fx_array_color

## Structure de la commande
```text
fx_array_color:
    x_tiles = $1
    y_tiles = $2
    opacity = $3
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Overlays a grid of randomized colored tiles. 
* **`X-Tiles` ($1)** (int) : défaut = **5**  (1,20)
* **`Y-Tiles` ($2)** (int) : défaut = **5**  (1,20)
* **`Opacity` ($3)** (float) : défaut = **0.5**  (0,1)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
