---
tags: [gmic, filter]
command: fx_frame_mirror
---

# Filtre G'MIC : fx_frame_mirror

## Structure de la commande
```text
fx_frame_mirror:
    horizontal = $1
    vertical = $2
    horizontal = $3
    vertical = $4
    left = $5
    right = $6
    up = $7
    bottom = $8
    preview_opacity = $9
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Creates a border by mirroring the image edges. 
(Note) : Frame size:
* **`Horizontal (%)` ($1)** (float) : défaut = **10**  (0,100)
* **`Vertical (%)` ($2)** (float) : défaut = **10**  (0,100)
(Note) : Image alignment:
* **`Horizontal (%)` ($3)** (float) : défaut = **50**  (0,100)
* **`Vertical (%)` ($4)** (float) : défaut = **50**  (0,100)
(Note) : Frame dilation/shrinking:
* **`Left` ($5)** (float) : défaut = **0**  (-5,5)
* **`Right` ($6)** (float) : défaut = **0**  (-5,5)
* **`Up` ($7)** (float) : défaut = **0**  (-5,5)
* **`Bottom` ($8)** (float) : défaut = **0**  (-5,5)
* **`Preview Opacity (%)` ($9)** (float) : défaut = **0.75**  (0,1)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2018/08/20.
