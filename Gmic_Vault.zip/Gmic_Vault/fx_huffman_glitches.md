---
tags: [gmic, filter]
command: fx_huffman_glitches
---

# Filtre G'MIC : fx_huffman_glitches

## Structure de la commande
```text
fx_huffman_glitches:
    noise_level = $1
    split_mode = $2
    block_size = $3
    patch_overlap = $4
    color_space = $5
    quantization = $6
    random_seed = $7
    preview_type = $8
    preview_split_x = $9
    preview_split_y = $10
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Simulates data corruption (glitch art) based on Huffman coding. 
* **`Noise Level (%)` ($1)** (float) : défaut = **30**  (0,100)
* **`Split Mode` ($2)** (choice) : choix possibles => None, Horizontal Blocks, Vertical Blocks, Patches
* **`Block Size (%)` ($3)** (int) : défaut = **25**  (0,100)
* **`Patch Overlap (%)` ($4)** (float) : défaut = **0**  (0,50)
* **`Color Space` ($5)** (choice) : choix possibles => RGB, CMYK, HCY, HSI, HSL, HSV, Jzazbz, Lab, Lch, OKLab, YCbCr, YIQ
* **`Quantization` ($6)** (int) : défaut = **0**  (0,64)
(Note) : (Set to 0 to turn quantization off)
* **`Random Seed` ($7)** (int) : défaut = **0**  (0,65536)
* **`Preview Type` ($8)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
* **`Preview Split` ($9)** (point) : position = 0,0
(Note) : <span color="#EE5500">Beware:</span>

- The preview does not perfectly reflect what the resulting image will be. It just gives an idea on the kind of effects the filter produces with the specified parameters.

- The filter is slow to compute on large images.
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2023/04/26.
