---
tags: [gmic, filter]
command: fx_lathing3d
---

# Filtre G'MIC : fx_lathing3d

## Structure de la commande
```text
fx_lathing3d:
    resolution = $1
    smoothness = $2
    max_angle = $3
    width = $4
    height = $5
    size = $6
    x_angle = $7
    y_angle = $8
    z_angle = $9
    fov = $10
    x_light = $11
    y_light = $12
    z_light = $13
    specular_lightness = $14
    specular_shininess = $15
    rendering = $16
    antialiasing = $17
    top_layer_defines_object_texture = $18
```
## Définition des variables
(Note) : <span color="#EE5500">Description:</span> Creates a 3D object by rotating a profile curve (lathe). 
* **`Resolution` ($1)** (int) : défaut = **76**  (1,1024)
* **`Smoothness` ($2)** (float) : défaut = **2**  (0,5)
* **`Max Angle` ($3)** (float) : défaut = **361**  (0,361)
* **`Width` ($4)** (int) : défaut = **1024**  (1,4096)
* **`Height` ($5)** (int) : défaut = **1024**  (1,4096)
* **`Size` ($6)** (float) : défaut = **0.5**  (0,3)
* **`X-Angle` ($7)** (float) : défaut = **0**  (0,360)
* **`Y-Angle` ($8)** (float) : défaut = **0**  (0,360)
* **`Z-Angle` ($9)** (float) : défaut = **0**  (0,360)
* **`FOV` ($10)** (float) : défaut = **45**  (1,90)
* **`X-Light` ($11)** (float) : défaut = **0**  (-100,100)
* **`Y-Light` ($12)** (float) : défaut = **0**  (-100,100)
* **`Z-Light` ($13)** (float) : défaut = **-100**  (-100,0)
* **`Specular Lightness` ($14)** (float) : défaut = **0.5**  (0,1)
* **`Specular Shininess` ($15)** (float) : défaut = **0.7**  (0,3)
* **`Rendering` ($16)** (choice) : choix possibles => Dots, Wireframe, Flat, Flat-Shaded, Gouraud, Phong
* **`Antialiasing` ($17)** (bool) : par défaut = Faux (0)
* **`Top Layer Defines Object Texture` ($18)** (bool) : par défaut = Faux (0)
(Note) : Author: <a href="https://tinyurl.com/3d9w4j3s">David Tschumperlé</a>.      Latest Update: 2010/12/29.
