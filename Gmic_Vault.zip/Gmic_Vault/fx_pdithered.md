---
tags: [gmic, filter]
command: fx_pdithered
---

# Filtre G'MIC : fx_pdithered

## Structure de la commande
```text
fx_pdithered:
    gamma = $1
    contrast = $2
    brightness = $3
    smoothness = $4
    quantize_colors = $5
    smooth_colors = $6
    mixer_mode = $7
    color_intensity = $8
    preview_type = $9
```
## Définition des variables
* **`Gamma` ($1)** (float) : défaut = **1**  (0.01,5)
* **`Contrast` ($2)** (float) : défaut = **1**  (0,4)
* **`Brightness` ($3)** (float) : défaut = **0**  (-255,255)
* **`Smoothness` ($4)** (float) : défaut = **0**  (0,10)
* **`Quantize Colors` ($5)** (int) : défaut = **20**  (2,255)
* **`Smooth Colors` ($6)** (float) : défaut = **1**  (0,30)
* **`Mixer Mode` ($7)** (choice) : choix possibles => Color Doping, Darken, Soft Light, Grain Merge, Multiply, Value
* **`Color Intensity` ($8)** (float) : défaut = **1**  (0,1)
* **`Preview Type` ($9)** (choice) : choix possibles => Full, Forward Horizontal, Forward Vertical, Backward Horizontal, Backward Vertical, Duplicate Top, Duplicate Left, Duplicate Bottom, Duplicate Right, Duplicate Horizontal, Duplicate Vertical, Checkered, Checkered Inverse
(Note) : Author: PhotoComiX.      Latest update : 2010/29/12.
